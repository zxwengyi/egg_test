## 结构

- 登陆        mine_toLogin

    > 找回账号          mine_forgetLoginAccout

    > 忘记密码          mine_forgetLoginPassword

    > 去注册          mine_toRegister


- 我的        my_manager

    > 商家折扣    my_return

    >- 历史记录       my_bean

    > 基本信息    my_information

    > 我的交易    mine_trading

    > 我的收益    mine_myWallet

    >- 新增银行卡       mine_addBankCard

    > 员工管理    staff_manage

    >- 新增员工        staff_manage_add

    > 账号与安全  mine_accountSafety

    >- 修改密码        mine_modifyLoginPassword

    > 帮助与反馈  my_getting

    >- 意见反馈         my_feedBack

    >- 交易款结算       my_gathering

    >- 新增和管理员工    my_regulate

    >- 如何收款         my_wallet

    >- 如何查账对账      my_checking

    >- 收益体现         my_card

    >- 如何修改折扣      my_consumption


    > 设置       setting

    > 关于       mine_aboutGL

    >- 给乐条款         mine_merchantServiceTerms

    > 设置       setting

- 账单        tab_bill

- 首页        index_new
    > 交易通知    msg_pay

    > 本店综合评价   index_comVereview

    > 员工评价   index_employees
    
    > 消费笔数   index_fans_number
    
    > 系统消息   tab_msg
    
    > 消费笔数   index_fans_number
    
    > 消费笔数   index_fans_number



```
var aaa = 。。。
1231231231
| 111 | 222 | 222 | 222 |
|2222|222|222|222|
```

| 111 | 222 | 222 | 222 |
|2222|222|222|222|

### 我的
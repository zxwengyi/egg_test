var my_basic_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_basic', {
        url: '/my_basic',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_basic/my_basic.html',
                controller: 'my_basicCtrl'
            }
        }
    });
};
myapp.config(my_basic_myConfig);

angular.module('starter.my_basic',[])
.controller('my_basicCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

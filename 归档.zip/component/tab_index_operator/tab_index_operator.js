var tab_index_operator_myConfig = function($stateProvider) {
    $stateProvider
        .state('tab.tab_index_operator', {
            url: '/tab_index_operator',
            views: {
                'tab-index': {
                    templateUrl: 'component/tab_index_operator/tab_index_operator.html',
                    controller: 'tab_index_operatorCtrl'
                }
            }
        });
};
myapp.config(tab_index_operator_myConfig);

angular.module('starter.tab_index_operator', [])
    .controller('tab_index_operatorCtrl', function($scope, Common, $http, $state, $rootScope, $ionicHistory, cordovaPlug, $timeout, toast) {
        $scope.$on('$ionicView.beforeEnter', function() {
            var nativeBroadcastMsg = null;
            window.broadcastMsgNum = function(obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
                if (typeof(obj) == "object") {
                    nativeBroadcastMsg = obj.data;
                } else {
                    nativeBroadcastMsg = angular.fromJson(obj).data;
                }
                $scope.$emit('msgNum',nativeBroadcastMsg);
            };
            $scope.token = Common.getCache('Token');
            $scope.operatorId = $scope.token.operatorId;
            var myCacheTime = new Date(new Date().format(1)).getTime() - new Date().getTime();
            //激活粉丝数量
            if (Common.getCache('inviteSum') == null) {
                Common.get("merchantAPI/merchant/invite/sum", {
                    "buy": 1
                }, function(data) {
                    $scope.inviteSum = data.data;
                    Common.setCache("inviteSum", data.data, myCacheTime)
                }, function() {})
            } else {
                $scope.inviteSum = Common.getCache('inviteSum');
            }
            //获取收益
            if (Common.getCache('yesterdayProfit') == null) {
                Common.get("merchantAPI/order/yesterdayProfit", {}, function(data) {
                    $scope.profitAmt = data.data.profitAmt;
                    Common.setCache("yesterdayProfit", data.data.profitAmt, myCacheTime)
                }, function() {})
            } else {
                $scope.profitAmt = Common.getCache('yesterdayProfit');
            }
            //累计粉丝数量
            if (Common.getCache('inviteSumAll') == null) {
                Common.get("merchantAPI/merchant/invite/sum", {
                    "buy": 0
                }, function(data) {
                    $scope.inviteSumAll = data.data;
                    Common.setCache("inviteSumAll", data.data, myCacheTime)
                }, function() {})
            } else {
                $scope.inviteSumAll = Common.getCache('inviteSumAll');
            }
            //本店综合评论
            $scope.myArr = [{}, {}, {}, {}, {}];
            if ($scope.token.role != 4) {
                if (Common.getCache('commentScore') == null) {
                    Common.get("merchantAPI/merchant/comment/score", {}, function(data) {
                        $scope.myScore = data.data.getCommentScore;
                        Common.setCache("commentScore", data.data.getCommentScore, myCacheTime)
                    }, function() {})
                } else {
                    $scope.myScore = Common.getCache('commentScore');
                }
            } else {
                $scope.myScore = 0;
            }

            $scope.gotoScore = function() {
                    if ($rootScope.role == 4) {
                        Common.showAlert('离职提醒', '您目前已经离职，无法查看更多信息！');
                        return;
                    }
                    $state.go("tab.index_comVereview", {
                        'score': $scope.myScore,
                        'type': '0'
                    });
                }
                //员工服务评论
            if (Common.getCache('operatorScoreOnly') == null) {
                Common.get("merchantAPI/merchant/comment/operator/score", {
                    "operatorId": Common.getCache('Token').operatorId
                }, function(data) {
                    if (data.data == null) return;
                    $scope.operatorScore = data.data[0].commentScore;
                    Common.setCache("operatorScoreOnly", data.data[0].commentScore, myCacheTime);
                }, function() {})
            } else {
                $scope.operatorScore = Common.getCache('operatorScoreOnly');
            }


            //抽奖次数
            //   $scope.count = function(){
            //         Common.get("merchantAPI/redenvelope/operateSum",{},function(data){
            //             $scope.countNum = data.data.operateSum;
            //         },{})
            //   }
            // $scope.count();
            //极光推送红包入口判断
            $timeout(function() {
                //每次进首页获取红包列表
                // $scope.bonusArr = [{},{}];
                // $scope.bonusShow = true;
                cordovaPlug.CommonPL(function(res) {
                    var resList = res.data.list || [];
                    var delArr = [];
                    $scope.bonusArr = [];
                    var now = new Date().getTime();
                    if (resList.length > 0) {
                        resList.forEach(function(ele) {
                            if (now > ele.effectiveExpireTime) {
                                delArr.push(ele.id);
                            } else {
                                $scope.bonusArr.push(ele);
                            }
                        });


                        if ($scope.bonusArr.length > 0) {
                            $scope.bonusShow = true;

                        }
                        //删除过期红包
                        if (delArr.length > 0) {
                            cordovaPlug.CommonPL(function(res) {

                            }, 'deleteMessageByBatch', ['redenvelope_app', delArr.join(',')]);
                        }

                    }


                }, 'getMessageList', ['redenvelope_app', 1, 10]);
            }, 500);


            //红包模态框
            $scope.moddle_show = false;

            $scope.getBonus = function(type, id, effectiveExpireTime) {
                //$scope.bonusArr.splice(0, 1);
                if (new Date().getTime() > effectiveExpireTime) {
                    toast.show('该红包已经过期');
                    $scope.bonusArr.splice(0, 1);
                    if ($scope.bonusArr.length === 0) {
                        $scope.bonusShow = false;
                    }
                    cordovaPlug.CommonPL(function() {

                    }, 'deleteMessageByBatch', ['redenvelope_app', id.toString()]);
                } else {
                    Common.get('merchantAPI/redenvelope/distribute', {
                        accountType: type
                    }, function(res) {
                        $scope.bonus = res.data.operateAmount;
                        $scope.bonusArr.splice(0, 1);
                        if ($scope.bonusArr.length == 0) {
                            console.log($scope.bonusArr.length);
                            $scope.bonusShow = false;
                        }
                        cordovaPlug.CommonPL(function() {

                        }, 'deleteMessageByBatch', ['redenvelope_app', id.toString()]);

                        $scope.moddle_show = true;

                    });
                }
            };

            $scope.closeBonus = function() {
                $scope.moddle_show = false;
                //$scope.bonusShow = false;
            };



        });
    });

var mine_toRegister_myConfig = function ($stateProvider) {
  $stateProvider
    .state('tab.mine_toRegister', {
      url: '/mine_toRegister/:tel',
      views: {
        'tab-index': {
          templateUrl: 'component/mine_toRegister/mine_toRegister.html',
          controller: 'mine_toRegisterCtrl'
        }
      }
    });
};
myapp.config(mine_toRegister_myConfig);

angular.module('starter.mine_toRegister', [])
  .controller('mine_toRegisterCtrl', function ($scope, Common, toast, $interval, $state, $ionicHistory, $timeout, $stateParams, $ionicScrollDelegate,cordovaPlug) {
    $scope.check_phone_focus = false;
    $scope.check_code_focus = false;
    $scope.isCounting = false;
    //发送验证码按钮是否点亮
    $scope.checkPhone = false;
    $scope.hasInput = false;
    $scope.isAgree = true;


    var myClickBoo = true,
      regPhone = /^1(3|4|5|7|8)\d{9}$/,
      timer;
    // $scope.inputData={check_phone:'',check_code:''};
    $scope.showTel = function () {
      Common.showConfirm('', '确定拨打电话：4000-200-365 吗？', function () {
        cordovaPlug.CommonPL(function () {}, "telephone", ['4000-200-365'])
      }, {}, '确认', '取消')
    };
    $scope.checkPhoneFocus = function () {
      //input获得焦点时点亮手机图标
      $scope.check_phone_focus = true;
    }

    $scope.checkCodeFocus = function () {
      //input获得焦点时点亮密码图标
      $scope.check_code_focus = true;
    }

    $scope.checkPhoneBlur = function () {
      //input失去焦点时变暗手机图标
      $scope.check_phone_focus = false;
    }

    $scope.checkCodeBlur = function () {
      //input失去焦点时变暗密码图标
      $scope.check_code_focus = false;
    }
    $scope.clearPhone = function () {
      $scope.inputData.phone = ''
    }
    $scope.clearVCode = function () {
      $scope.inputData.vCode = ''
      console.log(22222222)
    }

    //获取焦点动态
    $scope.slideBottom = function () {
      $timeout(function () {
        $ionicScrollDelegate.scrollBottom(true)
      }, 300)
    }

    $scope.$watch('inputData.phone', function () {
      if (regPhone.test($scope.inputData.phone)) {
        $scope.isCounting = false;
      } else {
        $scope.isCounting = true;
      }
    })

    //短信倒计时
    $scope.count = function () {
      $scope.btnText = "59S";
      timer = $interval(function () {
        $scope.seconds--;
        if ($scope.seconds != 0) {
          $scope.seconds = $scope.seconds >= 10 ? $scope.seconds : "0" + $scope.seconds;
          $scope.btnText = $scope.seconds + "S";
        } else {
          // $scope.isCounting = false;
          $interval.cancel(timer);
          $scope.seconds = 59;
          $scope.btnText = "重新发送";
          if (regPhone.test($scope.inputData.phone)) {
            $scope.isCounting = false;
          } else {
            $scope.isCounting = true;
          }
        }
      }, 1000)
    }

    //IOS计时缓慢问题
    var hiddenTime, visibleTime;
    document.addEventListener("pause", function () {
      if (!$scope.isCounting) return;
      hiddenTime = new Date().getTime();
      visibleTime = $scope.seconds;
    }, false);
    document.addEventListener("resume", function () {
      if (!$scope.isCounting) return;
      var timemax = visibleTime - ((new Date().getTime() - hiddenTime) / 1000 | 0)
      if (timemax > 0) {
        $scope.seconds = timemax;
      } else {
        $scope.isCounting = false;
        $interval.cancel(timer);
        $scope.seconds = 59;
        $scope.btnText = "重新发送";
      }
    }, false);

    //获取短信验证码
    $scope.getCode = function () {
      var tel = $scope.inputData.phone;
      if ($scope.btnText == "发送验证码" || $scope.btnText == "重新发送") {
        if (tel.length != 11) {
          toast.show('请输入正确的手机号码');
          return
        } 
        $scope.count();
        $scope.isCounting = true;
        Common.sendMessage(tel, "0", function () {})
        // if (regPhone.test(tel)) {
        //   $scope.count();
        //   $scope.isCounting = true;
        //   Common.sendMessage(tel, "0", function() {})
        // } else {
        //   toast.show('请输入正确的手机号码');
        // }
      }
    }

    $scope.$watch("inputData.phone", function () {
      $scope.$watch("inputData.vCode", function () {
        // if (regPhone.test($scope.inputData.phone) && /^\d{6}$/.test($scope.inputData.vCode)) {
        if ($scope.inputData.phone || $scope.inputData.vCode) {
          $scope.hasInput = true;
        } else {
          $scope.hasInput = false;
        }
      })
    })

    // 注册下一步
    $scope.next = function () {
      var tel = $scope.inputData.phone;
      var vCode = $scope.inputData.vCode;
      if (tel || vCode) {
        if (tel) {
          if (tel.length === 11) {
            if (vCode) {
              if ($scope.hasInput) {
                Common.get('merchantAPI/regToken', {
                  "username": tel,
                  "vCode": vCode
                }, function (data) {
                  $state.go('tab.mine_setPassword', {
                    "tel": tel,
                    "regToken": data.data.regToken
                  });
                  $interval.cancel(timer);
                  $scope.seconds = 59;
                  $scope.inputData.vCode = '';
                }, {})
              }
            } else {
              toast.show("请输入手机验证码")
            }
          } else {
            toast.show("请输入正确格式的手机号")
          }
        } else {
          toast.show("请输入您的手机号")
        }
      }
    }

    $scope.$on('$ionicView.beforeEnter', function () {
      //初始化数据
      $scope.inputData = {
        phone: $stateParams.tel ? $stateParams.tel : '',
        vCode: ''
      };
      $scope.btnText = "发送验证码";
      $scope.seconds = 59;

    });
  });
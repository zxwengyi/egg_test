var tabs_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab', {
            url: '/tab',
            cache: false,
            abstract: true,
            views: {
                'tab': {
                    templateUrl: "component/tabs/tabs.html",
                    controller: "tabCtrl"
                }
            }
        });
};
myapp.config(tabs_myConfig);

angular.module('starter.tabs', [])
    .controller('tabCtrl', function ($scope, $location, Common, $rootScope, $timeout, $state, cordovaPlug, $ionicHistory) {      
        $rootScope.showListBoo = false;
        $scope.indexClick = function () {
            window.newsUpdate();
            if ($rootScope.billModal) {
                $rootScope.billModal.remove()
            }
            window.location.href = "#/tab/index_new";
        }
        $scope.indexopClick = function () {
            window.newsUpdate();
            window.location.href = "#/tab/tab_index_operator";
        }

        if(Common.getCache('BottomSafeAreaHeight')){
            $timeout(function () {
                document.querySelector('.tabs').style.height = 1.05 + Common.getCache('BottomSafeAreaHeight') +'rem';
            },100)
        }

        $scope.merchantsClick = function () {
            window.location.href = "#/tab/store_nearby";
        }
        $scope.mineClick = function () {
            if ($rootScope.billModal) {
                $rootScope.billModal.remove()
            }
            window.location.href = "#/tab/my_manager";
        }
        $scope.promoteClick = function () {
            if ($rootScope.billModal) {
                $rootScope.billModal.remove()
            }
            window.location.href = "#/tab/tab_promote";
        }
        $scope.cashierClick = function () {
            if ($rootScope.billModal) {
                $rootScope.billModal.remove()
            }
            if ($rootScope.role == 4) {
                Common.showAlert('离职提醒', '您目前已经离职，无法查看更多信息！');
                return;
            }
            window.location.href = "#/tab/counter_pay";
        }

        $scope.billClick = function () {

            /*            if ($rootScope.role == 4) {
                            Common.showAlert('离职提醒', '您目前已经离职，无法查看更多信息！');
                            return;
                        }*/
            Common.clearCache('statisticalDate')
            if (location.hash.indexOf('/tab/tab_bill') > 0) {
                return
            } else {
                window.location.href = "#/tab/tab_bill?random=" + new Date().getTime();
            }
        }
        $scope.financialClick = function () {
            window.location.href = "#/tab/account_list/0"
        }
        $scope.gotoBill = function () {
            if ($rootScope.role == 4) {
                Common.showAlert('离职提醒', '您目前已经离职，无法查看更多信息！');
                return;
            }
            $state.go("tab.tab_bill", {
                random: new Date().getTime()
            });
        }
        $scope.gotoMsg = function () {
            //console.log($ionicHistory.currentView())
            var time = new Date().format() + ' ' + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
            Common.setCache('msgTime', time);
            $scope.unRead = false;
            $state.go("tab.tab_msg", {
                random: Math.random()
            });
        }

        $timeout(function () {
            Common.checkDevice();
        }, 1000);
        //隐藏tip
        $scope.hideTabTip = function () {
            $rootScope.tabShowTip = false;
        }
        $scope.$on('$ionicView.beforeEnter', function () {

        });

        $timeout(function () {
            if (Common.getCache('Token') != null) {
                if ($state.current.name === 'tab.index_new' || $state.current.name === 'tab.account_list'
                    || $state.current.name === 'tab.tab_fans' || $state.current.name === 'tab.counter_pay'
                    || $state.current.name === 'tab.counter_pay' || $state.current.name === 'tab.my_manager') {
                    Common.post('merchantAPI/msg/getMsg', {
                        "curPage": 1,
                        "pageSize": 1
                    }, function (res) {
                        if (Common.getCache('msgTime') < res.data.updateTime) {
                            $scope.unRead = true;
                        } else {
                            $scope.unRead = false;
                        }
                    })
                }
            }
        }, 1000);

        $scope.$on('msgNum', function (d, data) {
            $scope.nativeBroadcastMsg = data;
            $scope.unRead = true;
            $scope.$apply();
        });
        window.broadcastLogout = function (res) {
            $rootScope.showListBoo = false;
            Common.get('merchantAPI/isLogin', function (resp) {
                console.log(resp)
            })
        };
        window.newsUpdate = function () {
            Common.get('merchantAPI/merchant/basics', {}, function (data) {
                console.log(111, data)
                var newData = Common.getCache('Token');
                newData.cashierBoo = data.data.cashierBoo;
                newData.staffmanagementBoo = data.data.staffmanagementBoo;
                newData.merchantShortName = data.data.merchantShortName;
                newData.onLinePay = data.data.onLinePay;
                newData.saleRate = data.data.saleRate;
                newData.discountRate = data.data.discountRate;
                newData.maxSaleRate = data.data.maxSaleRate;
                newData.minSaleRate = data.data.minSaleRate;
                newData.noBenefit = data.data.noBenefit;
                if (data.data.role && newData.role != 5 && newData.role != 6) newData.role = data.data.role;
                Common.setCache('Token', newData);
                $rootScope.role = newData.role;
                $rootScope.onLinePay = newData.onLinePay;
                $rootScope.saleRate = newData.saleRate;
                $rootScope.discountRate = newData.discountRate
                $rootScope.information = Common.getCache('Token');
                Common.setCache('onLinePay', data.data.onLinePay, 8640000);
                $scope.$broadcast('jpush');
            }, {})
        }
        if (Common.getCache('Token') != null) {
            $rootScope.onLinePay = Common.getCache('Token').onLinePay;
            $rootScope.role = Common.getCache('Token').role;
        }
        /*        if (!Common.getCache("wxpayMess") && Common.getCache('Token') != null && $rootScope.role == 1) {
                    var accType = Common.getCache('Token').merchantType == 2 && Common.getCache('Token').linkType == 1 ? '1' : '0';
                    Common.post('merchantAPI/wxpay/act/wallet/info', {}, function (data) {
                        if (data.data.status == 3) {
                            Common.setCache('wxpayMess', 1)
                        } else if (data.data.status == 1) {
                            Common.showConfirm('', '请前往“我的-钱包”尽快完善账号信息，以便收益金及时汇入', function () {
                                Common.post('merchantAPI/wxpay/act/wallet/url/get', {
                                    accType: accType
                                }, function (res) {
                                    cordovaPlug.CommonPL(function (data) {
                                    }, "weChatPay", [res.data.authUrl])
                                }, {}, 1)
                            }, {}, "去设置", '取消')
                            Common.setCache('wxpayMess', 1, 1 * 24 * 3600000);
                        } else if (data.data.status == 0) {
                            Common.showConfirm('', '请前往给乐商家APP-我的-钱包页面完成设置以便分润资金及时汇入', function () {
                                $state.go('tab.mine_openAccount')
                            }, {}, "去设置", '取消')
                            Common.setCache('wxpayMess', 1, 1 * 24 * 3600000);
                        }
                    }, {})
                }*/
        if (Common.getCache('Token') != null && $rootScope.role == 1 && !Common.getCache("missMessage")) {
            Common.get('merchantAPI/merchant/info', {}, function (data) {
                for (var o in data.data) {
                    if (data.data[o] == null) {
                        Common.showConfirm('', '恭喜您成为给乐特约商户，请完善商户信息以便带来更多客流量', function () {
                            $state.go('tab.my_information')
                        }, {}, "去完善", '取消');
                        Common.setCache('missMessage', 1, 7 * 24 * 3600000);
                        break;
                    }
                }
            }, {}, 1)
        }
        //upload 20171211 by cheng 
        var myInfor = Common.getCache('Token');
        $rootScope.information = Common.getCache('Token');
        //      $rootScope.onLinePay = Common.getCache('Token').onLinePay;
        if (myInfor != null && (myInfor.role == 5 || myInfor.role == 6)) {
            Common.showLoading();
            $timeout(function () {
                Common.post("merchantAPI/merchant/getChainBusinessList", {}, function (data) {
                    $rootScope.myArr = data.data;
                    var activeNum = 0;
                    if ($rootScope.myArr.merchantList.length > 0) {
                        for (i in $rootScope.myArr.merchantList) {
                            if (myInfor.role == 5 && $rootScope.myArr.merchantList[i].merchantNo === $rootScope.myArr.merchantNo) activeNum = i;

                            $rootScope.myArr.merchantList[i].active = false;
                        }
                        $rootScope.myArr.merchantList[activeNum].active = true;
                        $rootScope.merchantsChooseName = $rootScope.myArr.merchantList[activeNum].merchantName;
                    }

                }, {}, 1)
            }, 2000)


        }
        $scope.showList = function () {
            if (Common.getCache('Token').role != 5 && Common.getCache('Token').role != 6) return;
            $rootScope.showListBoo = !$rootScope.showListBoo;
        }
        $scope.closeshowListBoo = function () {
            $rootScope.showListBoo = false;
        }
        $scope.gotoOther = function (item, num) {
            $rootScope.showListBoo = false;
            $rootScope.merchantsChooseName = item.merchantName;
            for (i in $rootScope.myArr.merchantList) {
                $rootScope.myArr.merchantList[i].active = false;
            }
            $rootScope.myArr.merchantList[num].active = true;
            Common.post('merchantAPI/user/changeChainBusiness', {
                branchMerchantNo: item.merchantNo,
                branchOperatorId: item.operatorId,
                mainOperatorId: $rootScope.myArr.operatorId,
                mainmerchantNo: $rootScope.myArr.merchantNo
            }, function (data) {
                var newData = Common.getCache('Token');
                var resData = data.data.data;
                for (i in resData) {
                    newData[i] = resData[i]
                }
                newData.name = item.name;
                newData.operatorId = item.operatorId;
                if (resData.role) newData.role = resData.role;
                Common.setCache('Token', newData);
                $rootScope.role = newData.role;
                $rootScope.onLinePay = newData.onLinePay;
                $rootScope.information = Common.getCache('Token');
                Common.setCache('onLinePay', data.data.onLinePay, 8640000);
                item.merchantType ? $state.go('tab.my_allmanager') : $state.go('tab.index_new');

            }, {}, 1)
        }
    });
var setting_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.setting', {
            url: '/setting',
            views: {
                'tab-mine': {
                    templateUrl: 'component/setting/setting.html',
                    controller: 'settingCtrl'
                }
            }
        });
};
myapp.config(setting_myConfig);

angular.module('starter.setting', [])
    .controller('settingCtrl', function ($scope, Common,cordovaPlug, $state) {
        $scope.item = {};
        $scope.$watch('item.collectNotice',function (rst) {
            var type = rst?1:0
            $scope.setInfo(type)
        })

        $scope.$watch('item.collectVoice',function (rst) {
            var type = rst?1:0
            $scope.setInfo2(type)
        })

        $scope.setInfo = function(type){
            console.log("设置信息");
            cordovaPlug.CommonPL(function(data){
                if(data.status == 1){
                }else{
                    toast.show("插件调用失败！");
                }
            }, "setNotifySwitch", [type])
        }

        $scope.setInfo2= function(type){
            console.log("设置信息");
            cordovaPlug.CommonPL(function(data){
                if(data.status == 1){
                }else{
                    toast.show("插件调用失败！");
                }
            }, "setReceivingVoice", [type])
        }

        $scope.getInfo = function(success){
            cordovaPlug.CommonPL(function(data){
                if(data.status == 1){
                    success instanceof Function && success(data.data);
                }else{
                    toast.show("插件调用失败！");
                }
            }, "getNotifySwitch", [])
        }

        $scope.getInfo2 = function(success){
            cordovaPlug.CommonPL(function(data){
                if(data.status == 1){
                    success instanceof Function && success(data.data);
                }else{
                    toast.show("插件调用失败！");
                }
            }, "getReceivingVoice", [])
        }
        $scope.merchantShortName = Common.getCache("Token").merchantShortName;//关联商户
        //解除关联商户
        $scope.unBundle = function () {
            Common.showConfirm('', '你确定要解除关联商户？', function () {
                var operatorId = Common.getCache("Token").operatorId;
                Common.post('merchantAPI/operator/updateStatus', {operatorId: operatorId}, function (data) {
                    //解除关联商户成功
                    Common.logout();
                    Common.showAlert('温馨提醒', '解除关联商户成功，请重新登录！', function() {
                        $state.go("tab.mine_toLogin",{}, { reload: true });
                    });
                }, function (error) {}, {});
            }, function () {
            }, "确定", "取消");
        };
        $scope.logout = function() {
      Common.showConfirm('退出提醒', '<p class="tc">您是否要退出当前账户？</p>', function() {
      	var newUrl = $scope.information.role ==5 || $scope.information.role == 6 ? 'merchantAPI/chainLogout' : 'merchantAPI/logout';
        Common.post(newUrl, {}, function(data) {
          Common.logout();
          $state.go("tab.mine_toLogin",{}, { reload: true });
        }, {}, 1)
      }, {}, '确定', '取消')
    }
        $scope.$on('$ionicView.beforeEnter', function () {
        	$scope.information = Common.getCache('Token');
            $scope.role={
                val:null,
                getInfo:true,
                merchantShortName:false
            }
            $scope.role.val = Common.getCache("Token").role;
            if($scope.role.val == 2 || $scope.role.val == 1){
                $scope.role.getInfo = true
            }
            if($scope.role.val == 2 || $scope.role.val == 3){
                $scope.role.merchantShortName = true
            }
            if($scope.role.getInfo){
                $scope.getInfo(function (data) {
                    if(data&&data.notiSwitch==1){
                        $scope.item.collectNotice = true
                    }else {
                        $scope.item.collectNotice = false
                    }
                });

                $scope.getInfo2(function (data) {
                    if(data&&data.notiSwitch==1){
                        $scope.item.collectVoice = true
                    }else {
                        $scope.item.collectVoice = false
                    }
                });
            }
        });
    });

var account_list_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.account_list', {
        url: '/account_list/:random',
        // hideHeader:true,
        views: {
            'tab-financial': {
                templateUrl: 'component/account_list/account_list.html',
                controller: 'account_listCtrl'
            }
        }
    });
};
myapp.config(account_list_myConfig);
myapp.run(['$rootScope','$state',function ($rootScope,$state,$document) {
    // $rootScope.$on('$stateChangeStart',function (e,toState,toParams,fromState,fromParams) {
    //     var hideTab = toState.hideHeader ? toState.hideHeader : false;
    //     if(hideTab){
    //         angular.element(document.querySelectorAll('#tab_header')).addClass('change_common_hide_header');
    //     }else {
    //         angular.element(document.querySelectorAll('#tab_header')).removeClass('change_common_hide_header');
    //     }
    // })
    var locationChangeStartOff = $rootScope.$on('$ionicView.beforeEnter', function () {
        var hideHeader = $state.current.hideHeader ? $state.current.hideHeader : false;
        var hideTabs = $state.current.hideTabs ? $state.current.hideTabs : false;
        if(angular.element(document.querySelectorAll('#tab_store_action-sheet-container'))){
            angular.element(document.querySelectorAll('#tab_store_action-sheet-container')).remove();
        }
        
        if(hideHeader){
            angular.element(document.querySelectorAll('#tab_header')).addClass('change_common_hide_header');
        }else {
            angular.element(document.querySelectorAll('#tab_header')).removeClass('change_common_hide_header');
        }

        if(hideTabs){
            angular.element(document.querySelectorAll('#iontabs')).addClass('change_common_hide_tabs');
        }else {
            angular.element(document.querySelectorAll('#iontabs')).removeClass('change_common_hide_tabs');
        }
    });

}])
angular.module('starter.account_list',[])
.controller('account_listCtrl', function($scope,Common,$timeout,$ionicScrollDelegate,$state,actionSheetItem,debugLocalCommon) {
    $scope.$on('$ionicView.beforeEnter', function() {
        angular.element(document.querySelectorAll('#tab_header')).addClass('change_common_hide_header');
        var timeChoose=null;
	    $scope.chooseDate = function () {
	        if(timeChoose){
	            timeChoose.close();
	            timeChoose=null;
	            return;
	        }
	        timeChoose=actionSheetItem.chooseTimeList({
	            scope:$scope,
	            top:"3.24rem"   ,
	            type:$scope.search.type,
	            startDate:'2000-05-21',
	            endDate:new Date().format(),
	            currentDate: new Date().format(),
	            success:function (data) {
	                timeChoose=null;
	                $scope.search.time = data.time
	                $scope.search.type = data.type
	                $scope.search.endDate = data.end
	                $scope.search.beginDate = data.start
	                $scope.doRefresh();
	                $ionicScrollDelegate.scrollTop();
	            },
	            cancel:function () {
	                timeChoose=null;
	            }
	        })
	    }
	    $scope.isHasMore=false;
	    $scope.list=[];
	
	    $scope.selectSettlement = function (isSettlement) {
	        $scope.isHasMore =false;
	        $scope.list=[];
	        $scope.search.isSettlement= isSettlement;
	        if(isSettlement == 1){
	            // $scope.search.beginDate=new Date().format(-1)
	            // $scope.search.endDate=new Date().format(-1)
	            // $scope.search.time=new Date().format(-1)
	        }else {
	            // $scope.search.beginDate=new Date().format()
	            // $scope.search.endDate=new Date().format()
	            // $scope.search.time=new Date().format()
	        }
	        $scope.doRefresh();
	        $ionicScrollDelegate.scrollTop();
	    }
	    
	    $scope.selectTime = function () {
	        $scope.doRefresh();
	        $ionicScrollDelegate.scrollTop();
	    }
	    $scope.totalPage=1
	    $scope.doRefresh=function () {
	        $scope.search.index = 1;
	        $scope.totalPage=1
	        getList()
	    }
	    $scope.search={}
	    $scope.loadMore = function () {
	        $scope.search.index++;
	        getList()
	    }
	
	
	    $scope.showDetail=function (item) {
	        Common.setCache("account_detail_info_"+item.date,item.detail,100000000);
	        $state.go("tab.account_detail",{time:item.date});
	    }
	
	
	    function getList() {
	        if($scope.search.index> $scope.totalPage ){
	            $scope.isHasMore =false;
	            $scope.$broadcast('scroll.infiniteScrollComplete');
	            return
	        }
	        var data= {
	            curPage:$scope.search.index,
	            pageSize:$scope.search.pageSize,
	            status:$scope.search.isSettlement,
	        }
	        if($scope.search.endDate){ data.endDate = $scope.search.endDate}
	        if($scope.search.beginDate){ data.beginDate = $scope.search.beginDate}
	        debugLocalCommon.post('merchantAPI/order/finanStatis',data,function (rst) {
	            var list = rst.data.list ? rst.data.list:[]
	            if($scope.search.index == 1) $scope.list = list
	            else $scope.list =$scope.list.concat(list)
	            $timeout(function () {
	                $scope.isHasMore = true;
	                $scope.totalPage = rst.data.totalPage
	                if(!rst.data.totalPage<$scope.search.index) $scope.isHasMore =false;
	                $scope.$broadcast('scroll.infiniteScrollComplete');
	                $scope.$broadcast('scroll.refreshComplete');
	            },500)
	        },function () {})
	    }
	    $scope.search={
	        time:new Date().format(),
	        index:0,
	        isSettlement:2,
	        pageSize:10,
	        beginDate:new Date().format(),
	        endDate:new Date().format(),
	        type:3
	    }
	    $ionicScrollDelegate.scrollTop();
	    $scope.loadMore()
    });
}).filter('dataFormatFilter',function () {
    return function (input,type) {
        var inputs = input.split(' ')[0].split('-');
        if(!type) return input;
        return type.replace('YY',inputs[0]).replace('mm',inputs[1]).replace('dd',inputs[2])
    };
}).directive('touchDct', function() {
    return {
        restrict: 'AE',
        scope:{
            current:'=',
            typeName:'@'
        },
        link:function (scope, element, attrs, accordionController) {
            var s_y,m_y,e_m_y,loop;

            element[0].addEventListener('touchstart',function (e) {
                e.preventDefault()
                var touch = event.targetTouches[0];
                s_y=touch.pageY
            })
            element[0].addEventListener('touchmove',function (e) {
                e.preventDefault()
                var touch = event.targetTouches[0],index,fontSize,top
                e_m_y = element.find('ul').css('top');
                if(parseFloat(e_m_y)>55) e_m_y=55;
                else if(parseFloat(e_m_y)< 30-(element.find('li').length-1)*50) e_m_y=30-(element.find('li').length-1)*50;
                m_y = touch.pageY
                top =-(parseFloat(e_m_y)+5)
                index = Math.round(top/50)
                fontSize = 15+(25-Math.abs((top-index*50)))/25*10
                element.find('ul').find('li').css({color:'#999'})
                element.find('ul').find('li').eq(index+1).css({color:'#2658A6',fontSize:fontSize+'px'})
                element.find('ul').css('top',(parseFloat(e_m_y)+m_y-s_y)+'px')
                s_y = touch.pageY
            })
            element[0].addEventListener('touchend',function (e) {
                var touch = event.targetTouches[0];
                e_m_y = element.find('ul').css('top');
                if(parseFloat(e_m_y)>55) e_m_y=55;
                else if(parseFloat(e_m_y)< 30-(element.find('li').length-1)*50) e_m_y=30-(element.find('li').length-1)*50;
                var top =-(parseFloat(e_m_y)+5),indexs;
                var index = Math.round(top/50)
                element.find('ul').find('li').css({color:'#999'})
                element.find('ul').css('top',(-index*50-5)+'px')
                element.find('ul').find('li').eq(index+1).css({color:'#2658A6',fontSize:'18px'})
                indexs = Math.abs(Math.round((parseFloat(e_m_y)+5)/50)-1);
                if(scope.current || scope.current == 0){
                    scope.current = indexs
                }
                clearTimeout(loop)
                loop = setTimeout(function () {
                   scope.$emit("getWeeksList",scope.typeName,indexs)
               },250)
            })
        }
    };
}).directive('commonBack',function () {
       return {
           restrict: 'A',
           scope:{
               commonBack:'@'
           },
           link:function (scope, element, attrs, accordionController) {
               element.on('click',function () {
                   if(scope.commonBack != ""){
                       history.go(scope.commonBack)
                       return
                   }
                   history.go(-1)
               })
           }
       }
    }).service('debugLocalCommon',function (Common,$http,$state,$rootScope) {
    var app_url = 'http://127.0.0.1:3030/';
    var $return = {
        isDebug:false,
        get:function (url,data,success,error,loading) {
            if(!Common.isnetwork()){
                Common.showAlert('温馨提示', "网络连接错误，请检查网络连接");
                if(loading) Common.hideLoading();
                return
            }
            if(!this.isDebug){
                Common.get(url,data,success,error,loading)
            }else {
                if(loading) Common.showLoading();
                $http({
                    method: 'post',
                    url: app_url+url,
                    data:data,
                }).then(function successCallback(data) {
                    data = data.data;
                    if(loading) Common.hideLoading();
                    if (data.result == 0) success instanceof Function && success(data);
                }, function errorCallback(data) {
                    if(loading) Common.hideLoading();
                });
            }
        },
        post:function (url,data,success,error,loading) {
            if(!Common.isnetwork()){
                Common.showAlert('温馨提示', "网络连接错误，请检查网络连接");
                if(loading) Common.hideLoading();
                return
            }
            if(!this.isDebug){
                Common.post(url,data,success,error,loading)
            }else {
                if(loading) Common.showLoading();
                $http({
                    method: 'post',
                    url: app_url+url,
                    data:data,
                }).then(function successCallback(data) {
                    data = data.data;
                    if(loading) Common.hideLoading();
                    if (data.result == 0) success instanceof Function && success(data);
                }, function errorCallback(data) {
                    if(loading) Common.hideLoading();
                });
            }
        },
        reloadPage:function (bak) {
            if(!$rootScope.no_comment_list_is_reload_page){
                bak()
            }
            $rootScope.no_comment_list_is_reload_page = false;
        },
        setNoReloadPage:function () {
            $rootScope.no_comment_list_is_reload_page = true;
        },
        getUserInfo:function (userIds,operatorIds,bak) {
            $return.post("merchantAPI/order/userInfoList",
                {userIds:userIds,operatorIds:operatorIds},
                function (data) {
                    bak(data)
                },function () {

                })
        }
    }
    return $return;
}).directive('hoverDct',function () {
    return {
        restrict: 'AE',
        scope:{
            hoverDct:'@'
        },
        link:function (scope, element, attrs, accordionController) {
            var s_y,m_y,e_m_y,loop;
            element[0].addEventListener('touchstart',function (e) {
                e.preventDefault()
                element[0].classList.add(scope.hoverDct)
            })
            element[0].addEventListener('touchend',function (e) {
                e.preventDefault()
                element[0].classList.remove(scope.hoverDct)
            })
        }
    };
})
.directive('touchHb',function () {
    return {
        restrict: 'A',
        scope:{
            indexCurrent:'='
        },
        link:function (scope, element, attrs) {
            var s_y,s_x,e_y,e_x,top,right,
                w_w = document.body.offsetWidth ,
                w_h = element.parent('#tab_index_operator')[0].clientHeight,
                f_s = parseFloat(document.querySelector('html').style.fontSize)
            element.css({
                top:'300px',
                right:(.26*f_s)+'px',
            })
            element[0].addEventListener('touchstart',function (e) {
                e.preventDefault()
                var touch = event.targetTouches[0];
                s_y=touch.pageY
                s_x=touch.pageX
            })
            element[0].addEventListener('touchmove',function (e) {
                e.preventDefault()
                var touch = event.targetTouches[0]
                right = element.css('right')
                top = element.css('top')

                element.css('top',parseFloat(top)+(touch.pageY-s_y)+'px')
                if(parseFloat(top)+(touch.pageY-s_y)<0) {
                    element.css('top',0+'px')
                }else if(parseFloat(top)+(touch.pageY-s_y)>w_h-(1.34+1.15+1.04)*f_s){
                    element.css('top',w_h-(1.34+1.15+1.04)*f_s+'px')
                }
                element.css('right',parseFloat(right)-(touch.pageX-s_x)+'px')
                s_y = touch.pageY,s_x=touch.pageX
            })
            element[0].addEventListener('touchend',function (e) {
                var touch = event.targetTouches[0];
                right = parseFloat(element.css('right'))
                console.log(w_w)
                if(right>w_w/2){
                    element.css('right',w_w-(.26+.95)*f_s+'px')
                }else {
                    element.css('right',(.26*f_s)+'px')
                }
            })
        }
    }
})

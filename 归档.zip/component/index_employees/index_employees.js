var index_employees_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.index_employees', {
        url: '/index_employees',
        views: {
            'tab-index': {
                templateUrl: 'component/index_employees/index_employees.html',
                controller: 'index_employeesCtrl'
            }
        }
    });
};
myapp.config(index_employees_myConfig);

angular.module('starter.index_employees',[])
.controller('index_employeesCtrl', function($scope,Common,$rootScope,$state) {
    $scope.active = 0;
    $scope.myArr = [{},{},{},{},{}];
    $scope.onClick = function(data){
        $scope.active = data;
        if(data == 1) gotoConsume();
    };
    $scope.gotoIndex = function(){
        $state.go('tab.index_new');
    };
    function gotoConsume(){
        //激活粉丝列表
        if (Common.getCache('inviteConsume') == null) {
            Common.get("merchantAPI/merchant/invite/consume", {}, function(data) {
                $scope.inviteConsume = data.data;
                Common.setCache("inviteConsume", data.data, 86400000)
            }, function() {},1)
        } else {
            $scope.inviteConsume = Common.getCache('inviteConsume');
        }
    }
    $scope.$on('$ionicView.beforeEnter', function() {
        //员工评价列表
        Common.get("merchantAPI/merchant/comment/operator/score", {}, function(data) {
                $scope.myArr = [{},{},{},{},{}];
                $scope.operatorScore = data.data;
                Common.setCache("operatorScore", data.data, 86400000)
            }, function() {},1)
        console.log($scope.operatorScore)
    });
});

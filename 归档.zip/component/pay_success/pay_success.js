var pay_success_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.pay_success', {
        url: '/pay_success',
        views: {
            'tab-cashier': {
                templateUrl: 'component/pay_success/pay_success.html',
                controller: 'pay_successCtrl'
            }
        }
    })
    .state('tab.scan_success', {
        url: '/scan_success',
        views: {
            'tab-cashier': {
                templateUrl: 'component/pay_success/scan_success.html',
                controller: 'scan_successCtrl'
            }
        }
    });
};
myapp.config(pay_success_myConfig);

angular.module('starter.pay_success',[])
.controller('pay_successCtrl', function($scope,$stateParams,Common,$rootScope) {
    $scope.item={}
    $scope.$on('$ionicView.beforeEnter', function() {
        window.broadcastMsgNum = function(obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
            if (typeof(obj) == "object") {
                nativeBroadcastMsg = obj.data;
            } else {
                nativeBroadcastMsg = angular.fromJson(obj).data;
            }
            $scope.$emit('msgNum',nativeBroadcastMsg);
        };
        $scope.item = Common.getCache('pay_success_first_message_info');
    });
})
.controller('scan_successCtrl', function($scope,$stateParams,Common,$rootScope) {
    $scope.$on('$ionicView.beforeEnter', function() {
       $scope.item = Common.getCache('palyMessage');
    });
});

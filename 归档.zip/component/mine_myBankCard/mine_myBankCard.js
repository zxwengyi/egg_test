var mine_myBankCard_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_myBankCard', {
      url: '/mine_myBankCard?{:hasAddCard,:bankName,:icon,:cardNo,:color}',
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_myBankCard/mine_myBankCard.html',
          controller: 'mine_myBankCardCtrl'
        }
      }
    });
};
myapp.config(mine_myBankCard_myConfig);

angular.module('starter.mine_myBankCard', [])
  .controller('mine_myBankCardCtrl', function($scope, $http, Common, $state, $stateParams, toast) {

    $scope.listCanSwipe = true;

    $scope.setBankCard = function() {
      $state.go('tab.mine_addBankCard');
    }

    $scope.goBack = function() {
    	if($scope.hasCard &&$stateParams.hasAddCard){
    		$state.go('tab.mine_withdrawal');
    	}else{
    		$state.go('tab.mine_myWallet')
    	}
    }

    //删除银行卡
    $scope.deleteCard = function(index) {
      console.log("delete bankCard....");
      Common.showConfirm("温馨提示", "<h3 style='text-align:center;'>是否删除该银行卡</h3>", function() {
        console.log('ok...')
        Common.post("merchantAPI/operator/bank/accountno/delete", {}, function() {
          //取消
          $scope.hasCard = false;
          $scope.bankList = [{}];
          //清除银行卡缓存
          Common.clearCache("user_bankCardName");
          Common.clearCache("user_bankCardNo");
          Common.clearCache("user_bankCardIcon");
          Common.clearCache("user_bankCardColor");
          Common.clearCache("setParam");
            Common.showConfirm('', "<span>银行卡已删除,请重新绑定</span>", function() {
              //去绑卡
              $state.go('tab.mine_addBankCard');
              Common.setCache('cjc_gotoAdd',1);
            }, {}, "去绑卡", "取消")
        }, {})
      }, {}, "确认", "取消")
    };

    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.shouldShowDelete = false;
      $scope.shouldShowReorder = false;
      $scope.listCanSwipe = true
      $scope.bankList = [{}];

      console.log(Common.getCache("user_bankCardNo"))
      $scope.hasCard = $stateParams.hasAddCard ? true :
        Common.getCache("user_bankCardNo") != null ? true : false;
      
      Common.get('merchantAPI/operator/bank/accountno/query', {}, function(data) {
          console.log(data.data)
          //user_addedCardInfo，后台返回的全部银行卡数据
          Common.setCache("user_addedCardInfo", data.data);
          if (data.data == null) return;
          $scope.hasCard = true;
          $scope.bankList[0].cardNo = data.data.bankAccountNo;
          var flag = data.data.bankNo.substr(0, 3);
          var myData = Common.getCache("allBankInfo");
          $scope.bankList[0].bankName = myData[flag].name;
          $scope.bankList[0].url = myData[flag].icon;
          $scope.bankList[0].color = myData[flag].color;
        }, {});
    });
  });
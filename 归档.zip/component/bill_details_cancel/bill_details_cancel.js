var bill_details_cancel_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.bill_details_cancel', {
            url: '/bill_details_cancel?{idx}{key}',
            hideHeader: true,
            hideTabs: true,
            views: {
                'tab-bill': {
                    templateUrl: 'component/bill_details_cancel/bill_details_cancel.html',
                    controller: 'bill_details_cancelCtrl'
                }
            }
        });
};
myapp.config(bill_details_cancel_myConfig);

angular.module('starter.bill_details_cancel', [])
    .controller('bill_details_cancelCtrl', function ($scope, Common, debugLocalCommon, $rootScope, $stateParams) {
        $scope.goBack = function () {
            debugLocalCommon.setNoReloadPage();
            history.go(-1)
        }
        // $scope.username = Common.getCache('Token').username
        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.list = Common.getCache('bill_details_cancel');
            $scope.userId = Common.getCache('Token').username;
            console.log($scope.list)
            Common.post('/merchantAPI/redeem/queryRedeemOrderDetail', {
                redeemCode: $scope.list.redeemCode,
            }, function (res) {
                 console.log(res.data)
                res = res.data || {};
                $scope.detailData = res
                
            });
        });


        $scope.revoke = function ($event, list) {
            $event.stopPropagation();
            $scope.show = true;
            $scope.refundData = {
                orderId: list.merchantOrderNo,
                payId: list.payId,
                pwd: ""
            };
            // Common.showConfirm('','请确认是否撤单',function () {
            //     $scope.verify()
            // })
        };

        var verifyFlag = true;
        $scope.verify = function () {
            if (!verifyFlag) {
                return;
            }
            verifyFlag = false;
            Common.post('merchantAPI/order/refund', {
                orderId: $scope.refundData.orderId,
                payId: $scope.refundData.payId,
                password: hex_md5("GL_SALT_MD5_KEY" + $scope.refundData.pwd),
                apiVersion: 'V1.1.0'
            }, function (res) {
                $scope.desc = res.description;
                $scope.show = !$scope.show;
                $scope.list.payStatusDesc = "退款中";
                $rootScope.refundInfo = {
                    idx: $stateParams.idx,
                    key: $stateParams.key
                }; // 返回的时候对应修改账单列表的状态
                $scope.showSuc = true;
            }, {}, 1);
            setTimeout(function () {
                verifyFlag = true;
            }, 3000)
        };
    })
    .filter('organCodeFilter', function () {
        return function (organCode) {
            if (organCode == 10001) {
                return 'POS机'
            } else if (organCode == 10003) {
                return '给乐商家端APP'
            } else if (organCode == 10004) {
                return '中付'
            } else {
                return organCode
            }
        };
    })

;
var mine_withdrawal_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.mine_withdrawal', {
            url: '/mine_withdrawal',
            views: {
                'tab-mine': {
                    templateUrl: 'component/mine_withdrawal/withdraw.html',
                    controller: 'mine_withdrawalCtrl'
                }
            }
        });
};
myapp.config(mine_withdrawal_myConfig);

angular.module('starter.mine_withdrawal', [])
    .controller('mine_withdrawalCtrl', function ($scope, $state, Common, $ionicHistory, toast,$rootScope) {
        if ($rootScope.role == 1) {
            $scope.tips='*亲，每月1-10号可提现一次哦';
        } else {
            $scope.tips='*亲，每周二可提现一次哦';
        }
        $scope.data = {
            "price": null
        }
        Common.post('merchantAPI/withdraw/query/balance', {}, function (data) {
            $scope.amount = data.data;
            $scope.$watch('data.price', function (n) {
                if (new Date().getDay() !==2 && $rootScope.role != 1) {
                    $scope.allowBtn = false;
                    return;
                } else if ($rootScope.role == 1 && new Date().getDate() > 10) {
                    $scope.allowBtn = false;
                    return;
                }
                if (n) {
                    $scope.allowBtn = true;
                } else {
                    $scope.allowBtn = false;
                }
            });
        }, {})
        $scope.allMoney = function () {
            $scope.data.price = Number($scope.amount.balance);
        }
        $scope.deletePrice = function () {
            $scope.data.price = ''
        }
        $scope.showDesc = false;
        $scope.showme = function ($event) {
            $event.stopPropagation()
            $scope.showDesc = !$scope.showDesc;
        }
        $scope.gotoSubmit = function () {
            if (!$scope.allowBtn) return;
            var regexp = /^(([1-9][0-9]*)|(([0]\.\d{0,2}|[1-9][0-9]*\.\d{0,2})))$/;
            if (regexp.test($scope.data.price)) {
                if ($scope.data.price > $scope.amount.balance) {
                    toast.show('可提现金额不足！');
                    return
                } else {
                    Common.post('merchantAPI/withdraw/apply', {
                        "cashMoney": $scope.data.price
                    }, function () {
                        Common.showAlert('温馨提示', '您的提现申请已提交', function () {
                            window.history.go(-1);
                        })
                    }, function () {
                        $scope.allowBtn = true;
                    }, 1)
                }
            } else {
                toast.show('请输入正确金额');
            }
        }
        $scope.goBack = function () {
            window.history.back();
        }
        $scope.$on('$ionicView.beforeEnter', function () {
            var myData = Common.getCache("allBankInfo");
            $scope.bankList = {}
            Common.get('merchantAPI/operator/bank/accountno/query', {}, function (data) {
                if (data.data == null || data.data.length == 0) {
                    Common.showConfirm('绑卡提醒', '<p class="tc">请先绑定银行卡!</p>', function () {
                        $state.go("tab.mine_myBankCard")
                    }, function () {
                        window.history.go(-1);
                    }, '立即绑定', '暂不绑定')
                } else {
                    $scope.bankList.cardNo = data.data.bankAccountNo;
                    Common.setCache('bankAccountNo', data.data.bankAccountNo);
                    var flag = data.data.bankNo.substr(0, 3);
                    var myData = Common.getCache("allBankInfo");
                    $scope.bankList.bankName = myData[flag].name;
                    $scope.bankList.url = 'img/bank/' + myData[flag].icon;
                    Common.setCache('myBankList', data.data)
                }
            }, {})
        });
    });

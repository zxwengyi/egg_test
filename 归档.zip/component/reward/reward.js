var reward_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.reward', {
        url: '/reward',
        views: {
            'tab-mine': {
                templateUrl: 'component/reward/reward.html',
                controller: 'rewardCtrl'
            }
        }
    }).state('tab.reward_target', {
        url: '/reward_target',
        views: {
            'tab-mine': {
                templateUrl: 'component/reward/target.html',
                controller: 'reward_targetCtrl'
            }
        }
    });
};
myapp.config(reward_myConfig);

angular.module('starter.reward',[])
.controller('rewardCtrl', function($scope,Common,debugLocalCommon,$state,actionSheetItem,$timeout,$ionicScrollDelegate) {
    var timeChoose=null;

    $scope.chooseDate = function () {
    	console.log($scope.timeChoose)
//      if(timeChoose){
//          timeChoose.close();
//          timeChoose=null;
//          return;
//      }
        $scope.hideWeek =true
        $scope.hideDay =true
        timeChoose=actionSheetItem.chooseTimeList({
            scope:$scope,
            top:"1.24rem"   ,
            type:'1',
            startDate:'2000-05-21',
            endDate:new Date().format(),
            currentDate: new Date().format(),
            success:function (data) {
                timeChoose=null;
                $scope.search.time = data.time
                $scope.search.type = data.type
                $scope.search.endDate = data.end
                $scope.search.beginDate = data.start
                $scope.search.index = 0
                $scope.totalPage=1
                $ionicScrollDelegate.scrollTop();
                $scope.loadMore()
            },
            cancel:function () {
                timeChoose=null;
            }
        })
    }
    $scope.isHasMore=false;
    $scope.list=[];
    $scope.loadMore=function () {
        $scope.search.index++
        getList()
    }
    function getList() {
        if($scope.search.index> $scope.totalPage ){
            $scope.isHasMore =false;
            $scope.$broadcast('scroll.infiniteScrollComplete');
            return
        }
        var data= {
            pageNum:$scope.search.index,
            numPerPage :$scope.search.pageSize,
            isPage:1,
            status:$scope.search.isSettlement,
        }
        if($scope.search.endDate){ data.toDate  = $scope.search.endDate}
        if($scope.search.beginDate){ data.fromDate = $scope.search.beginDate}
        debugLocalCommon.post('merchantAPI/operator/cashierAward/list',data,function (rst) {
            var list = rst.data.data  ? rst.data.data :[]
            if($scope.search.index == 1) $scope.list = list
            else $scope.list =$scope.list.concat(list)
            $timeout(function () {
                $scope.isHasMore = true;
                $scope.totalPage = rst.data.totalPages
                if(!rst.data.totalPages<$scope.search.index) $scope.isHasMore = false;
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.$broadcast('scroll.refreshComplete');
            },500)
        },function () {})
    }
    $scope.$on('$ionicView.beforeEnter', function() {
    	console.log(new Date().getPreMonth())
        $scope.search={
            time:new Date().format(),
            index:0,
            isSettlement:2,
            pageSize:10,
            beginDate:new Date(new Date().getPreMonth()).getMonthFirst(),
            endDate:new Date(new Date().getPreMonth()).getMonthEnd(),
            type:1
        }
        $scope.loadMore()
    });
}).controller('reward_targetCtrl', function($scope,Common,debugLocalCommon,$state) {

    $scope.goList=function () {
        $state.go('tab.reward')
    }

    $scope.$on('$ionicView.beforeEnter', function() {
        $scope.targetInfo={}
        debugLocalCommon.post('merchantAPI/operator/cashierAward/info',{},function (rst) {
            if(rst.data){
                $scope.targetInfo = rst.data
            }
        },function () {})
    });
});

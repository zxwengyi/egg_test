var mine_accountSafety_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_accountSafety', {
      url: '/mine_accountSafety',
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_accountSafety/mine_accountSafety.html',
          controller: 'mine_accountSafetyCtrl'
        }
      }
    });
};
myapp.config(mine_accountSafety_myConfig);

angular.module('starter.mine_accountSafety', [])
  .controller('mine_accountSafetyCtrl', function($scope, $http, $rootScope, $timeout, actionSheetItem, $ionicModal, $state, toast, Common, $interval, $stateParams) {


    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.information = Common.getCache('Token');
    });
  });
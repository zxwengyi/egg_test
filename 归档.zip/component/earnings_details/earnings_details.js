var earnings_details_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.earnings_details', {
        url: '/earnings_details/:id/:type',
        views: {
            'tab-mine': {
                templateUrl: 'component/earnings_details/earnings_details.html',
                controller: 'earnings_detailsCtrl'
            }
        }
    });
};
myapp.config(earnings_details_myConfig);

angular.module('starter.earnings_details',[])
.controller('earnings_detailsCtrl', function($scope,$stateParams,Common) {

    $scope.$on('$ionicView.beforeEnter', function() {
        $scope.myBankMessage = Common.getCache('myBankList');
        console.log($scope.myBankMessage)
        $scope.list = Common.getCache('earningsList')[0];
        $scope.type = $stateParams.type;
        Common.get('merchantAPI/withdraw/query/payer',{
            "voucherId":$stateParams.id
        },function(data){
            $scope.lists = data.data
        },{})
    });
});

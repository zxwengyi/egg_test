var msg_pay_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.msg_pay', {
            url: '/msg_pay',
            views: {
                'tab-index': {
                    templateUrl: 'component/msg_pay/msg_pay.html',
                    controller: 'msg_payCtrl'
                }
            }
        }).state('tab.msg_reward', {
            url: '/msg_reward',
            views: {
                'tab-index': {
                    templateUrl: 'component/msg_pay/msg_reward.html',
                    controller: 'msg_payCtrl'
                }
            }
        }).state('tab.msg_profit', {
            url: '/msg_profit?{:profit}{:payId}',
            views: {
                'tab-index': {
                    templateUrl: 'component/msg_pay/msg_profit.html',
                    controller: 'msg_profitCtrl'
                }
            }
        }).state('tab.msg_system', {
            url: '/msg_system/:messageRead',
            views: {
                'tab-index': {
                    templateUrl: 'component/msg_pay/msg_system.html',
                    controller: 'msg_systemCtrl'
                }
            }
        });
};
myapp.config(msg_pay_myConfig);

angular.module('starter.msg_pay', [])
    .controller('msg_payCtrl', function ($scope, $ionicHistory, Common, debugLocalCommon, $state, toast, $rootScope) {
        $scope.goBack = function () {
            // $ionicHistory.goBack(-1);
            window.history.back();
        }
        // $scope.gotoAward = function () {
        //     $state.go('tab.my_award1')
        // }
        //      $scope.gotoEarning = function () {
        //          if ($rootScope.role == 1 ||$rootScope.role == 5 || $rootScope.role == 6) {
        //              $state.go("tab.index_fans_number", {
        //                  userid: 2,
        //                  date: $scope.list.tranTime.split(' ')[0]
        //              })
        //          } else {
        //              $state.go("tab.index_earnings", {
        //                  type: 5,
        //                  date: $scope.list.tranTime.split(' ')[0]
        //              })
        //          }
        //          ;
        //      }
        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.information = Common.getCache('Token');
            $scope.list = Common.getCache('msg_pay');
        });
    })
    .controller('msg_profitCtrl', function ($scope, $ionicHistory, Common, $stateParams) {
        $scope.goBack = function () {
            // $ionicHistory.goBack(-1);
            window.history.back();
        }


        $scope.$on('$ionicView.beforeEnter', function () {
            Common.post('merchantAPI/withdraw/query/getPayDetail/' + $stateParams.payId, null, function (res) {
                $scope.list = res.data;
            });
            $scope.profit = $stateParams.profit;
        });
    }).controller('msg_systemCtrl', function ($scope, $ionicHistory, Common, toast, $stateParams, $state) {
        $scope.discountRate = 8.5
        var user = Common.getCache('Token')
        console.log($scope.onLinePay)

        $scope.goBack = function () {
            // $ionicHistory.goBack(-1);
            window.history.back();
        }
 
        $scope.$on('$ionicView.beforeEnter', function () {
         
        });
    })
    .filter('cashAmt', function () {
        return function (type) {
            switch (type) {
                case '1000':
                    return '银行卡支付';
                case '1001':
                    return '冲正银行卡支付';
                case '1100':
                    return '银行卡支付';
                case '1101':
                    return '冲正银行卡支付';
                case '2000':
                    return '银行卡支付';
                case '2001':
                    return '冲正银行卡支付';
                case '2100':
                    return '现金支付';
                case '2101':
                    return '冲正银行卡支付';
                case '3000':
                    return '退回银行卡支付';
                case '3100':
                    return '退回银行卡支付';
                case '3200':
                    return '退回银行卡支付';
                case '3300':
                    return '退回银行卡支付';
                case '4100':
                    return '银行卡支付';
                case '4101':
                    return '冲正银行卡支付';
            }
        };
    })
    .filter('paytime', function () {
        return function (type) {
            switch (type) {
                case '3000':
                    return '退款时间';
                case '3100':
                    return '退款时间';
                case '3200':
                    return '退款时间';
                case '3300':
                    return '退款时间';
                default:
                    return '收款时间';
            }
        };
    })
    .filter('beanAmt', function () {
        return function (type) {
            switch (type) {
                case '1000':
                    return '乐豆抵扣';
                case '1001':
                    return '冲正乐豆抵扣';
                case '1100':
                    return '乐豆抵扣';
                case '1101':
                    return '冲正乐豆抵扣';
                case '2000':
                    return '乐豆抵扣';
                case '2001':
                    return '冲正乐豆抵扣';
                case '2100':
                    return '乐豆抵扣';
                case '2101':
                    return '冲正乐豆抵扣';
                case '3000':
                    return '退回乐豆抵扣';
                case '3100':
                    return '退回乐豆抵扣';
                case '3200':
                    return '退回乐豆抵扣';
                case '3300':
                    return '退回银行卡支付';
                case '4100':
                    return '乐豆抵扣';
                default:
                    return '乐豆抵扣';
            }
        };
    })
    .filter('giftAmt', function () {
        return function (type) {
            switch (type) {
                case '1000':
                    return '赠送乐豆';
                case '1001':
                    return '冲正赠送乐豆';
                case '1100':
                    return '赠送乐豆';
                case '1101':
                    return '冲正赠送乐豆';
                case '2000':
                    return '赠送乐豆';
                case '2001':
                    return '冲正赠送乐豆';
                case '2100':
                    return '赠送乐豆';
                case '2101':
                    return '冲正赠送乐豆';
                case '3000':
                    return '收回赠送乐豆';
                case '3100':
                    return '收回赠送乐豆';
                case '3200':
                    return '收回赠送乐豆';
                case '3300':
                    return '收回赠送乐豆';
                case '4100':
                    return '赠送乐豆';
                case '4101':
                    return '收回赠送乐豆';
            }
        };
    })
    .filter('payTitle', function () {
        return function (type) {
            switch (type) {
                case '1000':
                    return '交易单号';
                case '1001':
                    return '冲正单号';
                case '1100':
                    return '交易单号';
                case '1101':
                    return '冲正单号';
                case '2000':
                    return '撤单单号';
                case '2001':
                    return '冲正单号';
                case '2100':
                    return '撤单单号';
                case '2101':
                    return '冲正单号';
                case '3000':
                    return '退款交易单号';
                case '3100':
                    return '退款交易单号';
                case '3200':
                    return '退款交易单号';
                case '3300':
                    return '退款交易单号';
                case '4100':
                    return '交易单号';
                case '4101':
                    return '冲正单号';
            }
        };
    })
    .filter('payTypeFilter', function () {
        return function (type) {
            if (type == 0) {
                return '快捷支付';
            } else if (type == 1) {
                return '付款码收款';
            } else if (type == 2) {
                return 'C扫B支付';
            } else if (type == 3) {
                return 'POS支付';
            }
        };
    })
    .filter('moneyFilter', function () {
        return function (input) {
            if (input) {
                return parseFloat(input).toFixed(2);
            } else {
                return '0.00';
            }
        };
    });

var tab_bill_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.tab_bill', {
            url: '/tab_bill?{random}{date}{navNum}', // date: 0是当天，1是昨天， 7是近七天; random: 时间戳; navNum: 0是第一个tab，1是第二个tab
            views: {
                'tab-bill': {
                    templateUrl: 'component/tab_bill/tab_bill_new.html',
                    controller: 'tab_billCtrl'
                }
            }
        });
};
myapp.config(tab_bill_myConfig);

angular.module('starter.tab_bill', [])
    .controller('tab_billCtrl', function ($scope, $stateParams, $ionicScrollDelegate, $http, Common, actionSheetItem, $timeout, $state, $ionicListDelegate, $rootScope, $ionicModal, toast) {
        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.isSelectIndex = 0
            $scope.isSelectPosIndex = 0
            $scope.qrCodeList = []
            $scope.posCodeList = []
            if ($rootScope.refundInfo) {
                $scope.tradeList[$rootScope.refundInfo.key][$rootScope.refundInfo.idx]['payStatusDesc'] = '退款中';
                $scope.tradeList[$rootScope.refundInfo.key][$rootScope.refundInfo.idx]['settleFlag'] = "P";
                $rootScope.refundInfo = null;
            }
            var statisticalDate = Common.getCache('statisticalDate')
            if (statisticalDate) {
                // $scope.toDate = statisticalDate.split('至')[1];
                // $scope.fromDate = statisticalDate.split('至')[0];
                // $scope.endTime = statisticalDate.split('至')[1];
                // $scope.startTime = statisticalDate.split('至')[0];
                $scope.isShowTotal = true
                $scope.statisticalDate = statisticalDate
            } else {
                if (Common.getCache('bill_details')) {
                    $scope.isShowTotal = true
                } else {
                    $scope.isShowTotal = false
                }
                var date_ = new Date();
                var year = date_.getFullYear();
                var month = date_.getMonth() + 1;
                var curMonth;
                if (month < 10) {
                    curMonth = '0' + month; //当月第一天  
                } else {
                    curMonth = month
                }
                $scope.fromDate = year + '-' + curMonth + '-01'; //当月第一天 
                $scope.startTime = year + '-' + curMonth + '-01'
                var day = new Date(year, month, 0);
                $scope.toDate = year + '-' + curMonth + '-' + day.getDate(); //当月最后一天
                $scope.endTime = year + '-' + curMonth + '-' + day.getDate();
                var time = year + '-' + curMonth
                // 更新数据
                $scope.statisticalDate = time
                Common.setCache('statisticalDate', $scope.statisticalDate)
            }

            getList()
            if ($stateParams.date) {
                getTotalData();
            }

            $scope.moveModel = false;


        });
        $scope.$on('$ionicView.beforeLeave', function () {
            if ($scope.moveModel) {
                if ($scope.modal) {
                    $scope.modal.remove();
                }
            }
            if ($scope.detailModal) {
                $scope.detailModal.remove()
            }
            $rootScope.tabShowBg = false;
        });
        $scope.show = false;
        $scope.username = Common.getCache('Token').username;
        $scope.selectNav = function (num) {
            $scope.$broadcast('$removeClone', true)
            if ($scope.navNum === num) {
                return;
            }
            Common.clearCache('statisticalDate')
            $scope.postTime = '';
            $scope.payId = '';
            $scope.profitType = '';

            $scope.isShowTotal = false
            $scope.navNum = num;
            $scope.xhrParams = {
                settleFlag: '',
                organCode: '',
                returnStatus: '',
                payType: '',
                orderType: ''
            };
            $scope.selectPosCode = ''
            $scope.selectQrCode = ''
            var date_ = new Date();
            var year = date_.getFullYear();
            var month = date_.getMonth() + 1;
            var curMonth;
            if (month < 10) {
                curMonth = '0' + month; //当月第一天  
            } else {
                curMonth = month
            }
            $scope.fromDate = year + '-' + curMonth + '-01'; //当月第一天  
            $scope.startTime = year + '-' + curMonth + '-01'
            var day = new Date(year, month, 0);
            $scope.toDate = year + '-' + curMonth + '-' + day.getDate(); //当月最后一天
            $scope.endTime = year + '-' + curMonth + '-' + day.getDate();
            var time = year + '-' + curMonth
            // 更新数据
            $scope.statisticalDate = time
            $scope.doRefresh();
            if ($scope.statisticalDate) {
                getTotalData()
            }
            $scope.tradeList = ''
        };

        // 初始化选中选项卡
        if ($stateParams.navNum) {
            $scope.navNum = Number($stateParams.navNum);
        } else {
            $scope.navNum = 0;
        }

        $scope.localDate = {}; // 初始化时间选择插件对象
        $scope.blockFlag = false;
        $scope.hasDate = false;


        $scope.xhrParams = {
            settleFlag: '',
            organCode: '',
            returnStatus: '',
            payType: '',
            orderType: ''
        };
        $scope.postTime = '';
        $scope.payId = '';

        $ionicModal.fromTemplateUrl('my-modal.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function (modal) {
            $rootScope.billModal = $scope.modal = modal;
        });

        $scope.openModal = function () {
            $rootScope.tabShowBg = true;
            $scope.moveModel = true;
            // $rootScope.posBlockFlag = false
            // $rootScope.blockFlag = false
            // $scope.isShowPosCode = false
            // $scope.isShowQrcode = false
            $scope.modal.show();
            $timeout(function () {
                $scope.$broadcast('initPicker', true);
            }, 300)
        };
        $scope.openModal2 = function () {
            $ionicModal.fromTemplateUrl('detail-modal.html', {
                scope: $scope,
                animation: 'slide-in-left'
            }).then(function (modal) {
                $scope.detailModal = modal;
                $scope.detailModal.show();
            });
        };
        $scope.$on("selectPosCode", function (e, data) {
            $scope.selectPosCode = data
        })
        $scope.$on("selectQrCode", function (e, data) {
            $scope.selectQrCode = data
        })
        $scope.confirmModel = function () {
            if ($scope.localDate.startYear && !$scope.localDate.endYear) {
                toast.show('请选择结束日期')
                return;
            }
            $rootScope.tabShowBg = false;
            $scope.modal.hide();
            $scope.moveModel = false;
            Common.showLoading();
            $timeout(function () {
                $scope.doRefresh();
                getTotalData();
                Common.hideLoading();
            }, 1000);
            $scope.isShowTotal = true
            if ($scope.localDate.startYear) {

                var beginDate = '{0}-{1}-{2}'.format($scope.localDate.startYear, $scope.localDate.startMonth, $scope.localDate.startDay);
                var endDate = '{0}-{1}-{2}'.format($scope.localDate.endYear, $scope.localDate.endMonth, $scope.localDate.endDay);
                $scope.statisticalDate = beginDate + '至' + endDate;
                $scope.fromDate = beginDate
                $scope.toDate = endDate
                $scope.startTime = beginDate
                $scope.endTime = endDate

                Common.setCache('statisticalDate', $scope.statisticalDate)
            } else {
                var date_ = new Date();
                var year = date_.getFullYear();
                var month = date_.getMonth() + 1;
                var curMonth;
                if (month < 10) {
                    curMonth = '0' + month; //当月第一天  
                } else {
                    curMonth = month
                }
                $scope.fromDate = year + '-' + curMonth + '-01'; //当月第一天 
                $scope.startTime = year + '-' + curMonth + '-01'
                var day = new Date(year, month, 0);
                $scope.toDate = year + '-' + curMonth + '-' + day.getDate(); //当月最后一天
                $scope.endTime = year + '-' + curMonth + '-' + day.getDate();
                var time = year + '-' + curMonth
                // 更新数据
                $scope.statisticalDate = time
                Common.setCache('statisticalDate', $scope.statisticalDate)
            }

        };
        $scope.closeModel = function () {
            $rootScope.tabShowBg = false;
            $scope.moveModel = false;
            $scope.modal.hide();
        };
        $scope.closeModel2 = function ($event) {
            $event.stopPropagation();
            $scope.detailModal.remove();
        };

        $scope.reset = function () {
            $scope.xhrParams.payType = '';
            $scope.xhrParams.settleFlag = '';
            $scope.xhrParams.returnStatus = '';
            $scope.xhrParams.orderType = '';
            $rootScope.posBlockFlag = false
            $rootScope.blockFlag = false
            $scope.isShowPosCode = false
            $scope.isShowQrcode = false
            $scope.blockFlag =false
            $scope.localDate = {}
            $scope.$broadcast('initPicker', false);
        };

        $scope.noMoreMsg = false;
        $scope.lists = [];

        $scope.loadMore = function () {
            console.log(111)

            getList();

        };

        $scope.revoke = function ($event, list, idx, key) {
            $event.stopPropagation();
            $scope.idx = idx;
            $scope.key = key;
            $scope.refundData = {
                orderId: list.merchantOrderNo,
                payId: list.payId,
                pwd: ""
            };
            $scope.show = true;
        };

        var verifyFlag = true;
        $scope.verify = function ($event) {
            $event.stopPropagation();
            if (!verifyFlag) {
                return;
            }
            verifyFlag = false;
            $ionicListDelegate.closeOptionButtons();
            Common.post('merchantAPI/order/refund', {
                orderId: $scope.refundData.orderId,
                payId: $scope.refundData.payId,
                password: hex_md5("GL_SALT_MD5_KEY" + $scope.refundData.pwd),
                apiVersion: 'V1.1.0'
            }, function (res) {
                $scope.desc = res.description;
                $scope.show = !$scope.show;
                $scope.tradeList[$scope.key][$scope.idx]['settleFlag'] = "P";
                $scope.tradeList[$scope.key][$scope.idx]['payStatusDesc'] = '退款中';
                $scope.showSuc = true;
                $ionicListDelegate.closeOptionButtons();
            }, {}, 1);
            setTimeout(function () {
                verifyFlag = true;
            }, 3000)
        };
        if ($scope.showSuc) {
            $timeout(function () {
                $scope.showSuc = false
            }, 3000)
        }
        var curPage = 1;

        $scope.startPage = 1
        $scope.doRefresh = function () {
            $ionicScrollDelegate.$getByHandle('bill-handle').scrollTop();
            $scope.payId = '';
            $scope.postTime = '';
            $scope.profitType = '';
            $scope.noMoreMsg = false;
            curPage = 1;
            $scope.startPage = 1
            $scope.tradeList = {}
            getList();
        };
        $scope.linkDetails = function (list, idx, key) {

            Common.setCache('bill_details', list);
            $state.go('tab.bill_details', {
                idx: idx,
                key: key
            });
        };
        $scope.linkDetailsCancel = function (list, idx, key) {
            Common.setCache('bill_details_cancel', list);
            $state.go('tab.bill_details_cancel', {
                idx: idx,
                key: key
            });
        };

        $scope.linkProfit = function (target) {
            if (target.parentProfitType == 1 || target.parentProfitType == 5 || target.parentProfitType == 3) {
                $state.go('tab.profit_bill_details', {
                    payId: target.payId,
                    profit: target.ownerProfitAmount,
                    profitType: target.parentProfitType,
                    saleType: target.saleType,
                    settleFlag: target.settleFlag
                });
            }
        };

        $scope.choseReturnStatus = function () {
            if ($scope.xhrParams.returnStatus === 1) {
                $scope.xhrParams.returnStatus = ''
            } else {
                $scope.xhrParams.returnStatus = 1;
            }
        };
        $scope.changeType = function (type) {
            $scope.xhrParams.payType = type
            console.log(type)
            $rootScope.posBlockFlag = false
            $rootScope.blockFlag = false
            $scope.isShowPosCode = false
            $scope.isShowQrcode = false
        }
        $scope.changeCode = function (type) {
            if (type == '01') {
                $scope.isShowPosCode = false
                $scope.isShowQrcode = true
                $scope.posCodeList = []
                $scope.selectPosCode = ''
                Common.post('merchantAPI/merchant/getBarCodeList', {}, function (res) {
                    if (res.data.length > 0) {
                        $rootScope.posBlockFlag = false
                        $rootScope.blockFlag = true
                        $scope.qrCodeList = res.data
                        $scope.selectQrCode = $scope.qrCodeList[0].barCode
                    }


                }, {}, 1);

            } else if (type == '03') {
                $scope.isShowQrcode = false
                $scope.isShowPosCode = true
                $scope.qrCodeList = []
                $scope.selectQrCode = ''
                Common.post('merchantAPI/merchant/getPosList', {}, function (res) {
                    if (res.data.length > 0) {
                        $rootScope.blockFlag = false
                        $rootScope.posBlockFlag = true
                        $scope.posCodeList = res.data
                        $scope.selectPosCode = $scope.posCodeList[0].posDeviceId
                    }

                }, {}, 1);

            } else {
                $rootScope.blockFlag = false
                $scope.xhrParams.payType = '';
                $scope.isShowQrcode = false
                $scope.isShowPosCode = false
                $rootScope.posBlockFlag = false
                $scope.qrCodeList = []
                $scope.selectQrCode = ''
                $scope.posCodeList = []
                $scope.selectPosCode = ''
            }
        };





        function getList() {
            var selectCode;
            if ($scope.isShowQrcode) {
                selectCode = $scope.selectQrCode
            } else {
                selectCode = $scope.selectPosCode
            }
            var data = {
                "payId": $scope.payId,
                "settleFlag": $scope.xhrParams.settleFlag,
                "payType": $scope.xhrParams.payType,
                "orderType": $scope.xhrParams.orderType,
                "terminalId": selectCode
            };
            var heXiaoData = {
                merchantNo: Common.getCache('Token').merchantNo
            }
            //   debugger
            data.fromDate = $scope.fromDate
            data.toDate = $scope.toDate
            heXiaoData.startTime = $scope.startTime
            heXiaoData.endTime = $scope.endTime
            if ($scope.navNum === 0) {
                // data.organCode = $scope.xhrParams.organCode;
                data.scene = $scope.xhrParams.organCode;
                data.organPayTime = $scope.postTime;
                data.returnStatus = $scope.xhrParams.returnStatus;
                getList4Nav0(data)
            } else if ($scope.navNum === 2) {
                heXiaoData.startPage = $scope.startPage;
                getList4Nav2(heXiaoData)
            } else {
                data.payTime = $scope.postTime;
                data.saleType = $scope.xhrParams.returnStatus;
                data.profitType = $scope.profitType;
                getList4Nav1(data)
            }
        }


        function getList4Nav0(data) {
            if ($rootScope.role == 4) {
                $scope.tradeList = ''
                $timeout(function () {
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $scope.$apply()
                })
                return;
            }

            Common.post('merchantAPI/homePage/bill/detail', data, function (res) {
                console.log(res.data)
                var list = res.data || [];
               
                var lenth = list.length;
                if (list.length !== 0 && $scope.payId) {
                    for (var i = 0; i < list.length; i++) {
                        if (list[i]['payId'] === $scope.payId) {
                            list = list.slice(i + 1, 10);
                            break;
                        }
                    }
                }
              
                if (curPage === 1 && list.length === 0) {
                    $scope.tradeList = ''
                } else if (curPage === 1) {
                    $scope.tradeList = {};
                }
                if (list.length !== 0) {
                    $scope.postTime = list[list.length - 1].organPayTime;
                    $scope.payId = list[list.length - 1].payId;
                    $scope.profitType = list[list.length - 1].profitType
                }

                list.forEach(function (item) {
                    // item.discountRate = (item.discountRate / 10).toFixed(1)
                    if (!$scope.tradeList[getYearAndMonth(item.organPayTime)]) {
                        $scope.tradeList[getYearAndMonth(item.organPayTime)] = [];
                        $scope.tradeList[getYearAndMonth(item.organPayTime)].push(item)
                    } else {
                        $scope.tradeList[getYearAndMonth(item.organPayTime)].push(item)
                    }
                });
             
                curPage++;
                $timeout(function () {
                    $scope.noMoreMsg = true;
                    if (lenth < 10) {
                        $scope.noMoreMsg = false;
                    }
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                }, 500);
            }, function () {
                $scope.tradeList = {};
            }, 1);
        }

        function getList4Nav1(data) {
            Common.post('merchantAPI/homePage/profit/detail', data, function (res) {
                var list = res.data || [];
              
                var lenth = list.length;
                if (list.length !== 0 && $scope.payId) {
                    for (var i = 0; i < list.length; i++) {
                        if (list[i]['payId'] === $scope.payId && list[i]['profitType'] === $scope.profitType) {
                            list = list.slice(i + 1, 10);
                            break;
                        }
                    }
                }
                if (curPage === 1 && list.length === 0) {
                    $scope.tradeList = ''
                } else if (curPage === 1) {
                    $scope.tradeList = {};
                }
                if (list.length !== 0) {
                    $scope.postTime = list[list.length - 1].payTime;
                    $scope.payId = list[list.length - 1].payId;
                    $scope.profitType = list[list.length - 1].profitType;
                }

                list.forEach(function (item) {
                    if (!$scope.tradeList[getYearAndMonth(item.payTime)]) {
                        $scope.tradeList[getYearAndMonth(item.payTime)] = [];
                        $scope.tradeList[getYearAndMonth(item.payTime)].push(item)
                    } else {
                        $scope.tradeList[getYearAndMonth(item.payTime)].push(item)
                    }
                });

                curPage++;
                $timeout(function () {
                    $scope.noMoreMsg = true;
                    if (lenth < 10) {
                        $scope.noMoreMsg = false;
                    }
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                }, 500);
            }, function () {
                $scope.tradeList = {};
            }, 1);
        }

        function getList4Nav2(data) {
            Common.post('merchantAPI/redeem/getRedeemOrderListByMerchantNo', data, function (res) {
                var list = res.data.list || [];
     
                var lenth = list.length;
                if (list.length !== 0 && $scope.payId) {
                    for (var i = 0; i < list.length; i++) {
                        if (list[i]['payId'] === $scope.payId && list[i]['profitType'] === $scope.profitType) {
                            list = list.slice(i + 1, 10);
                            break;
                        }
                    }
                }
                if ($scope.startPage === 1 && list.length === 0) {
                    $scope.tradeList = ''
                } else if ($scope.startPage === 1) {
                    $scope.tradeList = {};
                }
                if (list.length !== 0) {
                    $scope.postTime = list[list.length - 1].payTime;
                    $scope.payId = list[list.length - 1].payId;
                    $scope.profitType = list[list.length - 1].profitType;
                }

                list.forEach(function (item) {
                    if (!$scope.tradeList[getYearAndMonth(item.payTime)]) {
                        $scope.tradeList[getYearAndMonth(item.payTime)] = [];
                        $scope.tradeList[getYearAndMonth(item.payTime)].push(item)
                    } else {
                        $scope.tradeList[getYearAndMonth(item.payTime)].push(item)
                    }
                });
                // curPage++;
                $scope.startPage++
                $timeout(function () {
                    $scope.noMoreMsg = true;
                    if (lenth < 10) {
                        $scope.noMoreMsg = false;
                    }
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                }, 500);
            }, function () {
                $scope.tradeList = {};
            }, 1);
        }

        function getTotalData() {
            var data = {
                "returnStatus": $scope.xhrParams.returnStatus,
                "settleFlag": $scope.xhrParams.settleFlag,
                "payType": $scope.xhrParams.payType,
                "orderType": $scope.xhrParams.orderType
            };
            // if ($scope.localDate.endYear) {
            //     data.toDate = '{0}-{1}-{2}'.format($scope.localDate.endYear, $scope.localDate.endMonth, $scope.localDate.endDay);
            // } else if (Number($stateParams.date) === 1) {
            //     data.toDate = new Date().format(-1);
            // } else {
            //     data.toDate = new Date().format();
            // }
            // if ($scope.localDate.startYear) {
            //     data.fromDate = '{0}-{1}-{2}'.format($scope.localDate.startYear, $scope.localDate.startMonth, $scope.localDate.startDay);
            // } else if (Number($stateParams.date) === 1) {
            //     data.fromDate = new Date().format(-1);
            // } else if (Number($stateParams.date) === 7) {
            //     data.fromDate = new Date().format(-6);
            // } else if (Number($stateParams.date) === 0) {
            //     data.fromDate = new Date().format();
            // } else {
            //     data.fromDate = new Date().format(-365);
            // }
            data.fromDate = $scope.fromDate
            data.toDate = $scope.toDate
            var selectCode1;
            if ($scope.isShowQrcode) {
                selectCode1 = $scope.selectQrCode
            } else {
                selectCode1 = $scope.selectPosCode
            }
            data.terminalId = selectCode1
            if ($scope.navNum === 0) {
                // data.organCode = $scope.xhrParams.organCode;
                data.scene = $scope.xhrParams.organCode;
                if ($rootScope.role == 4) {
                    return;
                }
                Common.post('merchantAPI/homePage/bill/sumDetail', data, function (res) {
                    $scope.totalData = res.data;
                })
            } else {
                Common.post('merchantAPI/homePage/profit/sumDetail', data, function (res) {
                    $scope.totalData = res.data;
                })
            }
        }


        $scope.isSelect = function (index) {
            $scope.isSelectIndex = index
        }
        $scope.isSelectPos = function (index) {
            $scope.isSelectPosIndex = index
        }
        $scope.chooseCode = function () {
            $('.select-value3').mPicker({
                level: 1,
                dataJson: dataJson,
                Linkage: false,
                rows: 6,
                idDefault: true,
                confirm: function (json) {
                    console.info('当前选中json：', json);
                },
                cancel: function (json) {
                    console.info('当前选中json：', json);
                }
            })
        }


        // $scope.tradeList = {2017: [1, 2, 3, 4]}
        function getYearAndMonth(date) {
            if (!date) {
                return;
            }
            return date.split(' ')[0].substr(0, 7)
        }
    })
    .filter('hideRevoke', function () {
        return function (status, date, organScene, scene) {
            if (status) {
                if (status == '已支付') { // 判断订单是否是已付款状态，不是不让撤单
                    if (date) {
                        var newDate = date.split(' ')[0];
                        if (newDate == new Date().format()) { // 判断订单是否是当天，不是不让撤单 10001付费通  10003融脉  10004中付
                            if (organScene == 10003 || organScene == 10004 || (organScene == 10001 && scene == '06')) { // 判断订单是否是微信支付，不是不让撤单,scene=06 是微信B扫C
                                return true;
                            } else {
                                return false;
                            }
                        } else {
                            return false;
                        }
                    }
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        };
    })
    .filter('positiveFilter', function () {
        return function (num) {
            if (num <= 0) {
                return num.toFixed(2)
            } else {
                return '+' + num.toFixed(2);
            }
        };
    })
    .filter('negativeFilter', function () {
        return function (num) {
            if (num <= 0) {
                return Math.abs(num).toFixed(2)
            } else {
                return '-' + num.toFixed(2);
            }
        };
    })
    .filter('billDateFilter', function () {
        return function (date) {
            date = date.replace(/-/g, "/");
            var today = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
            var yesterday = new Date(new Date().format(-1).replace(/-/g, "/")).getTime()
            var targetDay = new Date(date).getTime();
            var nowYear = new Date().getFullYear();

            var hour = new Date(date).getHours();
            var minutes = new Date(date).getMinutes();
            var month = new Date(date).getMonth() + 1;
            var year = new Date(date).getFullYear();
            var day = new Date(date).getDate();
            if (hour < 10) {
                hour = '0' + hour
            }
            if (minutes < 10) {
                minutes = '0' + minutes
            }
            if (month < 10) {
                month = '0' + month
            }
            if (day < 10) {
                day = '0' + day
            }
            if (targetDay > today && targetDay - today < 86400000) {
                return '今日 {0}:{1}'.format(hour, minutes)
            } else if (targetDay > yesterday && targetDay < today) {
                return '昨日 {0}:{1}'.format(hour, minutes)
            } else if (nowYear === year) {
                return '{0}-{1} {2}:{3}'.format(month, day, hour, minutes)
            } else if (nowYear > year) {
                return '{0}-{1}-{2} {3}:{4}'.format(year, month, day, hour, minutes)
            } else {
                return date;
            }
        };
    })
    .filter('billDateFilter1', function () {
        return function (date) {
            date = date.replace(/-/g, "/");
            var today = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
            var yesterday = new Date(new Date().format(-1).replace(/-/g, "/")).getTime()
            var targetDay = new Date(date).getTime();
            var nowYear = new Date().getFullYear();

            var hour = new Date(date).getHours();
            var minutes = new Date(date).getMinutes();
            var month = new Date(date).getMonth() + 1;
            var year = new Date(date).getFullYear();
            var day = new Date(date).getDate();
            if (hour < 10) {
                hour = '0' + hour
            }
            if (minutes < 10) {
                minutes = '0' + minutes
            }
            if (month < 10) {
                month = '0' + month
            }
            if (day < 10) {
                day = '0' + day
            }
            if (targetDay > today && targetDay - today < 86400000) {
                return '今日'
            } else if (targetDay > yesterday && targetDay < today) {
                return '昨日 {0}:{1}'.format(hour, minutes)
            } else if (nowYear === year) {
                return '{0}-{1} {2}:{3}'.format(month, day, hour, minutes)
            } else if (nowYear > year) {
                return '{0}-{1}-{2} {3}:{4}'.format(year, month, day, hour, minutes)
            } else {
                return date;
            }
        };
    });
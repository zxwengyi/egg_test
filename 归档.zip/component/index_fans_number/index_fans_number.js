var index_fans_number_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.index_fans_number', {
            url: '/index_fans_number/:userid/:timeType',
            views: {
                'tab-index': {
                    templateUrl: 'component/index_fans_number/index_fans_number.html',
                    controller: 'index_fans_numberCtrl'
                }
            }
        });
};
myapp.config(index_fans_number_myConfig);

angular.module('starter.index_fans_number', [])
    .controller('index_fans_numberCtrl', function ($scope, $state, $stateParams, $rootScope, Common, $timeout, $ionicScrollDelegate, $ionicHistory, $ionicModal) {
//		时间选择控件
        $scope.localDate = {};
        $scope.$on('$ionicView.beforeLeave', function () {
            if ($scope.modal) {
                $scope.modal.remove();
            }
            $rootScope.tabShowBg = false;
        });
        $ionicModal.fromTemplateUrl('my-modal.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function (modal) {
            $scope.modal = modal;
        });
        $scope.openModal = function () {
            $scope.modal.show();
            $rootScope.tabShowBg = true;
            if (!$scope.hasChange) $scope.$broadcast('initPicker', true);
        };
        $scope.closeModel = function () {
            $rootScope.tabShowBg = false;
            $scope.modal.hide();
        };
        $scope.reset = function () {
            $scope.$broadcast('initPicker', false);
            $scope.data.operatorName = null;
        };
        $scope.sureModel = function () {
            $scope.closeModel();
            $scope.startTime0 = $scope.localDate.startYear + '-' + $scope.localDate.startMonth + '-' + $scope.localDate.startDay;
            $scope.endTime0 = $scope.localDate.endYear + '-' + $scope.localDate.endMonth + '-' + $scope.localDate.endDay;
            if($scope.localDate.startYear == '' || !$scope.localDate.startYear){
//          	$scope.startTime0 = new Date().getFullYear()+'-01-01';
                $scope.startTime0 = '2017-01-01';
                $scope.endTime0 = new Date().format();
            }
            $scope.changeTime = $scope.startTime0 + " ~ " + $scope.endTime0;
            $scope.curPage = 1;
            $scope.hasChange = true;
            $scope.consumeList = {
                list: []
            };
            Common.showLoading();
            $timeout(function () {
                $scope.selectLoad();
                Common.hideLoading();
            }, 1000)
        }
        function gotoChangeList2(_start, _end) {
            if ($rootScope.role == 4) {
                return;
            }
            Common.post('merchantAPI/homePage/consumePage', {
                "fromDate": _start,
                "toDate": _end,
                "pageNum": $scope.curPage,
                "totalFlag": "1",
                "numPerPage": 20
            }, function (data) {
                $scope.consumeList.list = $scope.consumeList.list.concat(data.data);
                $scope.showTotal = data.sum;
                $timeout(function () {
                    if (data.data.totalPage >= $scope.curPage) $scope.hasMore = true;
                    else $scope.hasMore = false;
                }, 1000)
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.curPage++;
            }, {}, 1)
        }

        function gotoChangeList0(_start, _end) {
            var operatorId = $stateParams.timeType.length > 2 ? $stateParams.timeType : null
            Common.post('merchantAPI/merchant/invite/queryActiveUserDto', {
                "beginTime": _start,
                "endTime": _end,
                "curPage": $scope.curPage,
                "pageSize": 20,
                "operatorId": operatorId,
                "operatorName": $scope.data.operatorName
            }, function (data) {
                var length = $scope.consumeList.list.length;
                var myMock = data.data;
                if (length > 0) {
                    if ($scope.consumeList.list[length - 1].month == myMock.list[0].month) {
                        $scope.consumeList.list[length - 1].data = $scope.consumeList.list[length - 1].data.concat(myMock.list[0].data);
                        myMock.list.shift();
                        $scope.consumeList.list = $scope.consumeList.list.concat(myMock.list);
                    } else $scope.consumeList.list = $scope.consumeList.list.concat(myMock.list);
                } else {
                    $scope.consumeList.list = $scope.consumeList.list.concat(myMock.list);
                }
                var fontSize = document.documentElement.clientWidth / 7.5
                $scope.ListArr = []
                for (var i = 0; i < $scope.consumeList.list.length; i++) {
                    if (i == 0) $scope.ListArr.push($scope.consumeList.list[i].data.length * 1.6 * fontSize)
                    else $scope.ListArr.push(($scope.consumeList.list[i].data.length * 1.6 + 0.6) * fontSize + $scope.ListArr[i - 1])
                }
                console.log($scope.ListArr)
                if ($scope.curPage == 1 && !$scope.hasChange) $scope.changeTime = $scope.consumeList.list.length > 0 ? $scope.consumeList.list[0].month : '';
                $timeout(function () {
                    if (data.data.totalPage >= $scope.curPage) $scope.hasMore = true;
                    else $scope.hasMore = false;
                }, 1000)
                console.log($scope.consumeList.list)
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.curPage++;
            }, {}, 1)
        }

        function gotoChangeList1(_start, _end) {
            Common.post('merchantAPI/merchant/invite/queryInviteUserDto', {
                "beginTime": _start,
                "endTime": _end,
                "curPage": $scope.curPage,
                "pageSize": 20,
                "operatorName": $scope.data.operatorName
            }, function (data) {
                var length = $scope.consumeList.list.length;
                var myMock = data.data;
                if (length > 0) {
                    if ($scope.consumeList.list[length - 1].month == myMock.list[0].month) {
                        $scope.consumeList.list[length - 1].data = $scope.consumeList.list[length - 1].data.concat(myMock.list[0].data);
                        myMock.list.shift();
                        $scope.consumeList.list = $scope.consumeList.list.concat(myMock.list);
                    } else $scope.consumeList.list = $scope.consumeList.list.concat(myMock.list);
                } else {
                    $scope.consumeList.list = $scope.consumeList.list.concat(myMock.list);
                }
                var fontSize = document.documentElement.clientWidth / 7.5
                $scope.ListArr = []
                for (var i = 0; i < $scope.consumeList.list.length; i++) {
                    if (i == 0) $scope.ListArr.push($scope.consumeList.list[i].data.length * 1.6 * fontSize)
                    else $scope.ListArr.push(($scope.consumeList.list[i].data.length * 1.6 + 0.6) * fontSize + $scope.ListArr[i - 1])
                }
                console.log($scope.ListArr)
                if ($scope.curPage == 1 && !$scope.hasChange) {
                    $scope.changeTime = $scope.consumeList.list.length > 0 ? $scope.consumeList.list[0].month : ''
                }
                $timeout(function () {
                    if (data.data.totalPage >= $scope.curPage) $scope.hasMore = true;
                    else $scope.hasMore = false;
                }, 1000)
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.curPage++;
            }, {}, 1)
        }

        $scope.doRefresh = function () {
            $scope.curPage = 1;
            $scope.consumeList = {
                list: []
            };
            $scope.ListArr = []
            $scope.selectLoad();
            $scope.$broadcast('scroll.refreshComplete');
        }
        $scope.loadMore = function () {
            if (!$scope.hasMore) return;
            $scope.hasMore = false;
            $scope.selectLoad();
        }
        $scope.selectLoad = function () {
            if ($scope.showDiff == 0) gotoChangeList0($scope.startTime0, $scope.endTime0);
            else if ($scope.showDiff == 1) gotoChangeList1($scope.startTime0, $scope.endTime0);
            else if ($scope.showDiff == 2) gotoChangeList2($scope.startTime0, $scope.endTime0);
        }
        $scope.goBack = function () {
            window.history.back();
        }
        $scope.listScroll = function () {
            if ($scope.hasChange) return;
            if ($ionicScrollDelegate.$getByHandle('mainScroll').getScrollPosition().top > $scope.ListArr[$scope.scrollNum]) {
                $scope.scrollNum++;
                $scope.changeTime = $scope.consumeList.list[$scope.scrollNum].month;
                $scope.$apply();
            }
            if ($ionicScrollDelegate.$getByHandle('mainScroll').getScrollPosition().top < $scope.ListArr[$scope.scrollNum - 1]) {
                $scope.scrollNum--;
                $scope.changeTime = $scope.consumeList.list[$scope.scrollNum].month;
                $scope.$apply();
            }
        }
        $scope.$on('$ionicView.beforeEnter', function () {
//      $scope.changeTime =$scope.endTime0=$scope.startTime0 = $stateParams.date || new Date().format(-1);
            $scope.hasChange = false;
            $scope.showDiff = $stateParams.userid;
            $scope.hasMore = false;
            $scope.reloadBoo = false;
            $scope.curPage = 1;
            $scope.scrollNum = 0;
            $scope.consumeList = {
                list: []
            };
            $scope.data = {
                operatorName: null
            }
            $scope.role = Common.getCache('Token').role;
            console.log($scope.role)
            $scope.ListArr = [];
            if ($stateParams.timeType === '0') $scope.changeTime = $scope.endTime0 = $scope.startTime0 = new Date().format(-1);
            else if ($stateParams.timeType == 1) $scope.changeTime = $scope.endTime0 = $scope.startTime0 = new Date().format();
            else if ($stateParams.timeType == 2) {
                $scope.startTime0 = new Date().format(-6);
                $scope.endTime0 = new Date().format();
                $scope.changeTime = $scope.startTime0 + " ~ " + $scope.endTime0
            } else {
//      	$scope.startTime0 = new Date().getFullYear()+'-01-01';
                $scope.startTime0 = '2017-01-01';
                $scope.endTime0 = new Date().format();
            }
            $scope.selectLoad();
        });
    })
    .filter('timeFormat', function () {
        return function (input) {
            console.log(input)
            if (!input) return '本月';
            var inputYear = input.toString().substring(0, 4);
            var inputMonth = input.toString().substring(4);
            var year = new Date().getFullYear();
            var month = new Date().getMonth() + 1;
            if (Number(inputYear) === year && Number(inputMonth)===month) {
                return '本月'
            }
            if(input.length > 6) return input;
            var array = inputYear + '年' + inputMonth + '月';
            return array;
        }
    })
;

var index_earnings_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.index_earnings', {
        url: '/index_earnings/:type?{date}',
        views: {
            'tab-index': {
                templateUrl: 'component/index_earnings/index_earnings.html',
                controller: 'index_earningsCtrl'
            }
        }
    });
};
myapp.config(index_earnings_myConfig);

angular.module('starter.index_earnings',[])
.controller('index_earningsCtrl', function($scope,$filter,actionSheetItem,Common,$timeout,$stateParams,$filter,$state,$rootScope,$ionicScrollDelegate) {
    $scope.newData = {};
    var choosedateing = null;
    $scope.chooseDate = function () {
        if(choosedateing){
            choosedateing.close();
            choosedateing=null;
            return;
        }
        choosedateing = actionSheetItem.chooseTimeList({
            scope:$scope,
            top:"2.8rem",
            type:$scope.search.type,
            startDate:'2000-05-21',
            endDate:new Date().format(-1),
            currentDate: $scope.search.time,
            success:function (data) {
                choosedateing = false;
                $scope.search.time = data.time;
                $scope.search.type = data.type;
                $scope.newData = data;
                console.log(data);
                if(data.type == 1) $scope.changeTime =data.year+"-"+data.month;
                else if(data.type == 3) $scope.changeTime =data.time;
                else $scope.changeTime =data.week;
                $ionicScrollDelegate.$getByHandle('mainScroll').scrollTop();
                gotoChangeList(data.start,data.end,$stateParams.type);
                //$scope.hasMore = true;
            },
            cancel:function () {
                choosedateing = null;
            }
        })
    }
    $scope.gotoIndex = function(){
        $state.go('tab.index_new');
    }
    //某月天数
    function DayNumOfMonth(Year,Month) {
        Month--;
        var d = new Date(Year,Month,1);
        d.setDate(d.getDate()+32-d.getDate());
        return (32-d.getDate());
    }
    $scope.previousClick = function(){
        if($scope.search.type == 3){
            $scope.changeTime = new Date($scope.changeTime).format(-1);
            $scope.search.time = $scope.changeTime;
            gotoChangeList($scope.changeTime,$scope.changeTime)
        }
        if($scope.search.type == 2){
            var _start = new Date($scope.newData.start).format(-7),
                _end = new Date($scope.newData.end).format(-7);
            $scope.newData.start = _start
            $scope.newData.end = _end;
            $scope.changeTime = $filter('date')(_start,'MM.dd') +'-'+ $filter('date')(_end,'MM.dd');
            gotoChangeList(_start,_end);
        }
        if($scope.search.type == 1){
            var newTime = new Date($scope.newData.start).format(-2),
                _time = $filter('date')(newTime,'yyyy-MM'),
                _start = _time+'-01';
                _end = _time + '-'+DayNumOfMonth($filter('date')(newTime,'yyyy'),$filter('date')(newTime,'MM'));
            $scope.newData.start = _start
            $scope.newData.end = _end;
            $scope.changeTime = _time;
            gotoChangeList(_start,_end);
        }
    }
    $scope.nextClick =function(){
        if($scope.search.type == 3){
            var nextTime = new Date($scope.changeTime).format(2);
            if(new Date().getTime()<new Date(nextTime).getTime() ) return;
            $scope.changeTime = new Date($scope.changeTime).format(1);
            $scope.search.time = $scope.changeTime;
            gotoChangeList($scope.changeTime,$scope.changeTime)
        }
        if($scope.search.type == 2){
            var _start = new Date($scope.newData.start).format(7),
                _end = new Date($scope.newData.end).format(7);
            if(new Date().getTime()<new Date(_start).getTime()) return;
            $scope.newData.start = _start
            $scope.newData.end = _end;
            $scope.changeTime = $filter('date')(_start,'MM.dd') +'-'+ $filter('date')(_end,'MM.dd');
            gotoChangeList(_start,_end);
        }
        if($scope.search.type == 1){
            var newTime = new Date($scope.newData.end).format(1),
                _time = $filter('date')(newTime,'yyyy-MM'),
                _start = _time+'-01';
                _end = _time + '-'+DayNumOfMonth($filter('date')(newTime,'yyyy'),$filter('date')(newTime,'MM'));
            if(new Date().getTime() < new Date(newTime).getTime()) return;
            $scope.newData.start = _start
            $scope.newData.end = _end;
            $scope.changeTime = _time;
            gotoChangeList(_start,_end);
        }
    }
    function gotoChangeList(_start,_end){
        $scope.newStart = _start;
        $scope.newEnd = _end;
        Common.post('merchantAPI/order/operationProfitList',{
            "beginDate":_start,
            "endDate":_end,
            "curPage":1,
            "pageSize":$scope.pageSize,
            "status":$scope.newType,
            "totalFlag":1
        },function(data){
            $scope.operationProfitList = data.data;
            $scope.showTotal = data.data;
            $timeout(function(){
                if(data.data.totalPage >= $scope.curPage) $scope.hasMore = true;
                else $scope.hasMore = false;
            },1500)
            $scope.$broadcast('scroll.refreshComplete');
        },{},1)
    }
    $scope.doRefresh = function(){
    	$scope.curPage = 2;
        gotoChangeList($scope.newStart,$scope.newEnd,$scope.newType);
    }
    $scope.hasMore = false;
    $scope.curPage = 2; //当前页数
    $scope.pageSize = 10; // 一次加载多少条
    $scope.operationProfitList = [];
    $scope.loadMore = function() {
        if(!$scope.hasMore) return;
        $scope.hasMore = false;
        Common.post('merchantAPI/order/operationProfitList',{
            "beginDate":$scope.newStart,
            "endDate":$scope.newEnd,
            "curPage":$scope.curPage,
            "pageSize":$scope.pageSize,
            "status":$scope.newType,
            "totalFlag":0
        },function(data){
            $scope.operationProfitList.list = $scope.operationProfitList.list.concat(data.data.list);
            $timeout(function(){
                if(data.data.totalPage >= $scope.curPage) $scope.hasMore = true;
                else $scope.hasMore = false;
            },3000)
            $scope.$broadcast('scroll.infiniteScrollComplete');
            console.log(data.data.totalPage+"@!##!@#@!#!"+ $scope.curPage)
            $scope.curPage++;
        }, {});
    }
    var myOptionName = $rootScope.role == 2 ? '分润收益' : '红包收益';
    $scope.option = {
        templateUrl : 'template/classification.html',
        scope:$scope,
        title:'请选择收益类型',
        items:[{text:"全部",value:0},
            {text:"粉丝激活收益",value:3},
            {text:myOptionName,value:1},
            {text:"打赏收益",value:5},
//          {text:"抽奖收益",value:4},
            {text:"收银奖励",value:6}],
        classify:0,
        success:function() {
            $scope.newType = $scope.option.classify
            gotoChangeList($scope.newStart,$scope.newEnd);
            $ionicScrollDelegate.$getByHandle('mainScroll').scrollTop();
            console.log($scope.option.classify)
            $scope.curPage = 2;
            // $state.go('tab.index_earnings',{type:$scope.option.classify})
            // console.log($scope.option.classify)
        }
    };
    $scope.showAction = function(){
        actionSheetItem.showAction($scope.option);
    };
    $scope.$on('$ionicView.beforeEnter', function() {
        $scope.newType = $stateParams.type;
        $timeout(function(){
            gotoChangeList($scope.changeTime,$scope.changeTime)

        },0)
        $scope.changeTime = $stateParams.date || new Date().format(-1);
        $scope.search={
            time:$stateParams.date || new Date().format(-1),
            index:0,
            isSettlement:2,
            pageSize:10,
            beginDate:'',
            endDate:'',
            type:3
        }
    });
});
var mine_versionUpdate_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.mine_versionUpdate', {
        url: '/mine_versionUpdate',
        views: {
            'tab-mine': {
                templateUrl: 'component/mine_versionUpdate/mine_versionUpdate.html',
                controller: 'mine_versionUpdateCtrl'
            }
        }
    });
};
myapp.config(mine_versionUpdate_myConfig);

angular.module('starter.mine_versionUpdate',[])
.controller('mine_versionUpdateCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

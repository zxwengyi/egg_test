var index_server_evaluation_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.index_server_evaluation', {
        url: '/index_server_evaluation/:id/:score/:type/:avatarUrl/:username',
        views: {
            'tab-index': {
                templateUrl: 'component/index_server_evaluation/index_server_evaluation.html',
                controller: 'index_server_evaluationCtrl'
            }
        }
    });
};
myapp.config(index_server_evaluation_myConfig);

angular.module('starter.index_server_evaluation',[])
.controller('index_server_evaluationCtrl', function($scope,$timeout,$stateParams,Common,$rootScope,$state,$ionicScrollDelegate) {
    $scope.myArr = [{},{},{},{},{}];
    $scope.myScore = $stateParams.score;
    $scope.myStar = 2.1-((5 - $scope.myScore )/5 * 2.1) +"rem";
    $scope.type = $stateParams.type;
    $scope.operatorId = $stateParams.id;
    $scope.avatarUrl = $stateParams.avatarUrl || null;
    console.log($stateParams.avatarUrl)
    /*if (Common.getCache('Token').role == 3 || Common.getCache('Token').role == 4) {
        console.log(angular.toJson(Common.getCache('Token')));
        $scope.avatarUrl = Common.getCache('Token').photo || null;
    } else {
        $scope.avatarUrl = $stateParams.avatarUrl || null;
    }*/
    $scope.username = $stateParams.username || Common.getCache('Token').name;
    $scope.gotoEmployess = function(){
        $state.go('tab.index_new');
    };
    var myCurPage = 1;
    $scope.showDiff = function(_num){
        myCurPage = 1;
        $ionicScrollDelegate.$getByHandle('mainScroll').scrollTop();
        Common.post("merchantAPI/merchant/comment/operator/scoreDetailed", {
            "commentType": _num,
            "curPage": myCurPage,
            "pageSize": "20",
            "operatorId": $stateParams.id
        }, function (data) {
            $scope.scoreDetailed = data.data;
            $scope.noMoreMsg = true;
            $scope.type = _num;
            $scope.allCount = Number(data.data.dataMap.goodCount) + Number(data.data.dataMap.mediumCount) + Number(data.data.dataMap.differenceCount);
        }, function () {
        }, 1);
    };
    $scope.showDiff(0);
    $scope.loadMore = function(){
        myCurPage++;
        $scope.noMoreMsg = false;
        Common.post("merchantAPI/merchant/comment/operator/scoreDetailed", {
            "commentType": $scope.type,
            "curPage": myCurPage,
            "pageSize": "20",
            "operatorId": $stateParams.id
        }, function (data) {
            if(data.data.totalPage > myCurPage){
                $scope.scoreDetailed.list = $scope.scoreDetailed.list.concat(data.data.list);
                $timeout(function(){
                     $scope.noMoreMsg = true;
                },2000)
            }
        },{}, 1);
    }
    $scope.getComments = function (_int) {
        return Number(_int) <= 1 && "差评" || Number(_int) > 3 && "好评" || "中评";
    };
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

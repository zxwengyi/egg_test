var profit_bill_details_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.profit_bill_details', {
            url: '/profit_bill_details/{payId}/{profit}/{profitType}{saleType}{settleFlag}',
            views: {
                'tab-bill': {
                    templateUrl: 'component/profit_bill_details/profit_bill_details.html',
                    controller: 'profit_bill_detailsCtrl'
                }
            }
        });
};
myapp.config(profit_bill_details_myConfig);

angular.module('starter.profit_bill_details', [])
    .controller('profit_bill_detailsCtrl', function ($scope, Common, $stateParams,$rootScope) {
        $scope.$on('$ionicView.beforeEnter', function () {
            // $rootScope.statusBarHeight =0.44
        });
        $scope.profitType = $stateParams.profitType;
        $scope.profit = $stateParams.profit;
        $scope.payId = $stateParams.payId;
        switch ($stateParams.profitType) {
            case '1':
                $scope.desc = '分润';
                break;
            case '3':
                $scope.desc = '激活粉丝奖励';
                break;
            case '5':
                $scope.desc = '打赏';
                break;
        }
        Common.post('merchantAPI/homePage/payProfitDetail', {
            payId: $stateParams.payId,
            saleType: $stateParams.saleType,
            settleFlag: $stateParams.settleFlag
        }, function (res) {
            $scope.profitData = res.data;
        })
    });

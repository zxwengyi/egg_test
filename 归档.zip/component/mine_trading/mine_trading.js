var mine_trading_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.mine_trading', {
        url: '/mine_trading',
        views: {
            'tab-mine': {
                templateUrl: 'component/mine_trading/mine_trading.html',
                controller: 'mine_tradingCtrl'
            }
        }
    });
};
myapp.config(mine_trading_myConfig);

angular.module('starter.mine_trading',[])
.controller('mine_tradingCtrl', function($scope,Common,$filter,$timeout) {
    $scope.$on('$ionicView.beforeEnter', function() {
    	$scope.listData = [];
    	$scope.pageNum = 1;
		$scope.getData();
    });
    $scope.getData = function(){
    	Common.post('merchantAPI/withdraw/merchantSettle/daily',{
			'fromDate':'2017-01-01',
			'toDate': $filter('date')(new Date(),'yyyy-MM-dd'),
			'isPage':1,
			'numPerPage':20,
			'pageNum':$scope.pageNum
		},function(data){
			$scope.listData = $scope.listData.concat(data.data);
			$scope.pageNum++;
			$timeout(function(){
                if(data.data.length == 0) $scope.hasMore = false;
                else $scope.hasMore = true;
            },1000)
		})
    }
    $scope.loadMore = function() {
        if(!$scope.hasMore) return;
        $scope.hasMore = false;
        $scope.getData();
        $scope.$broadcast('scroll.infiniteScrollComplete');
    }
});

var my_revoke_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_revoke', {
        url: '/my_revoke',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_revoke/my_revoke.html',
                controller: 'my_revokeCtrl'
            }
        }
    });
};
myapp.config(my_revoke_myConfig);

angular.module('starter.my_revoke',[])
.controller('my_revokeCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

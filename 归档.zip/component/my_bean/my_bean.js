var my_bean_myConfig = function($stateProvider) {
    $stateProvider
        .state('tab.my_bean', {
            url: '/my_bean',
            views: {
                'tab-mine': {
                    templateUrl: 'component/my_bean/my_bean.html',
                    controller: 'my_beanCtrl'
                }
            }
        });
};
myapp.config(my_bean_myConfig);

angular.module('starter.my_bean', [])
    .controller('my_beanCtrl', function($scope, Common, $http,$ionicHistory) {

        $scope.hasMore = false;
        $scope.curPage = 1; //当前页数
        $scope.pageSize = 10; // 一次加载多少条
        $scope.dangerList = [];
        $scope.doRefresh = function() {
            $scope.hasMore = false;
            $scope.curPage = 1;
            Common.get("merchantAPI/merchant/glfeerate/info", {
                "curPage": 1,
                "pageSize": $scope.pageSize
            }, function(data) {

                $scope.dangerList = data.data.list;
                if (data.data.totalPage > $scope.curPage) $scope.hasMore = true;
                else $scope.hasMore = false;
                $scope.curPage++;
                $scope.$broadcast('scroll.refreshComplete');
            }, {});
        };
        //$scope.loadMore();
    
        $scope.goBack=function(){
            window.history.back()
        }
        
       
        $scope.$on('$ionicView.beforeEnter', function() {
            Common.get('merchantAPI/merchant/info', {}, function (data) {
                $scope.discountRate = data.data.discountRate / 10;
            })
             $scope.loadMore = function() {
                $scope.hasMore = false;
                Common.get("merchantAPI/merchant/glfeerate/info", {
                    "curPage": $scope.curPage,
                    "pageSize": $scope.pageSize
                }, function(data) {
                    $scope.dangerList = $scope.dangerList.concat(data.data.list);
                    if (data.data.totalPage > $scope.curPage) $scope.hasMore = true;
                    else $scope.hasMore = false;
                    console.log(data.data.totalPage + '@#$@$' + $scope.curPage);
                    $scope.$broadcast('scroll.infiniteScrollComplete');
                    $scope.curPage++;
                }, {});

            };
            $scope.loadMore();
        });
    });

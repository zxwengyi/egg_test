var fans_push_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.fans_push', {
        url: '/fans_push',
        hideHeader:true,
        views: {
            'tab-fans': {
                templateUrl: 'component/fans_push/fans_push.html',
                controller: 'fans_pushCtrl'
            }
        }
    });
};
myapp.config(fans_push_myConfig);

angular.module('starter.fans_push',[])
.controller('fans_pushCtrl', function($scope,$ionicHistory) {
    $scope.items = [{},{}]
    $scope.goBack = function() {
        window.history.back();
    };
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

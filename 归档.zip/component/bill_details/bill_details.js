var bill_details_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.bill_details', {
            url: '/bill_details?{idx}{key}',
            hideHeader: true,
            hideTabs: true,
            views: {
                'tab-bill': {
                    templateUrl: 'component/bill_details/bill_details.html',
                    controller: 'bill_detailsCtrl'
                }
            }
        });
};
myapp.config(bill_details_myConfig);

angular.module('starter.bill_details', [])
    .controller('bill_detailsCtrl', function ($scope, Common, debugLocalCommon, $rootScope, $stateParams) {
        $scope.goBack = function () {
            debugLocalCommon.setNoReloadPage();
            // Common.clearSessionStorage('statisticalDate')
            history.go(-1)
        }
        // $scope.username = Common.getCache('Token').username
        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.list = Common.getCache('bill_details');
            $scope.userId = Common.getCache('Token').username;
            console.log($scope.list)
            Common.post('/merchantAPI/order/userInfoList', {
                userIds: $scope.list.userId,
                operatorIds: $scope.list.operator
            }, function (res) {
                res = res.data || {};
                operatorList = res.operatorList || [];
                userList = res.userList || [];
                if (operatorList.length > 0) {
                    $scope.list.operatorName = operatorList[0].operatorName;
                }
                if (userList.length > 0) {
                    $scope.list.imgUrl = userList[0].imgUrl;
                }
            });
        });


        $scope.revoke = function ($event, list) {
            $event.stopPropagation();
            $scope.show = true;
            $scope.refundData = {
                orderId: list.merchantOrderNo,
                payId: list.payId,
                pwd: ""
            };
            // Common.showConfirm('','请确认是否撤单',function () {
            //     $scope.verify()
            // })
        };

        var verifyFlag = true;
        $scope.verify = function () {
            if (!verifyFlag) {
                return;
            }
            verifyFlag = false;
            Common.post('merchantAPI/order/refund', {
                orderId: $scope.refundData.orderId,
                payId: $scope.refundData.payId,
                password: hex_md5("GL_SALT_MD5_KEY" + $scope.refundData.pwd),
                apiVersion: 'V1.1.0'
            }, function (res) {
                $scope.desc = res.description;
                $scope.show = !$scope.show;
                $scope.list.payStatusDesc = "退款中";
                $rootScope.refundInfo = {
                    idx: $stateParams.idx,
                    key: $stateParams.key
                }; // 返回的时候对应修改账单列表的状态
                $scope.showSuc = true;
            }, {}, 1);
            setTimeout(function () {
                verifyFlag = true;
            }, 3000)
        };
    })
    .filter('organCodeFilter', function () {
        return function (organCode) {
            if (organCode == 10001) {
                return 'POS机'
            } else if (organCode == 10003) {
                return '给乐商家端APP'
            } else if (organCode == 10004) {
                return '中付'
            }else {
                return organCode
            }
        };
    })

;

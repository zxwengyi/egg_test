var wallet_details_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.wallet_details', {
        url: '/wallet_details',
        views: {
            'tab-mine': {
                templateUrl: 'component/wallet_details/wallet_details.html',
                controller: 'wallet_detailsCtrl'
            }
        }
    });
};
myapp.config(wallet_details_myConfig);

angular.module('starter.wallet_details',[])
.controller('wallet_detailsCtrl', function($scope,Common,$stateParams) {
    $scope.$on('$ionicView.beforeEnter', function() {
    	$scope.cacheList = Common.getCache('wallet_detail');
		Common.get('merchantAPI/withdraw/query/payer',{
            "voucherId":$scope.cacheList.voucherId
        },function(data){
            $scope.lists = data.data
        },{})
    });
});

var my_regulate_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_regulate', {
        url: '/my_regulate',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_regulate/my_regulate.html',
                controller: 'my_regulateCtrl'
            }
        }
    });
};
myapp.config(my_regulate_myConfig);

angular.module('starter.my_regulate',[])
.controller('my_regulateCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

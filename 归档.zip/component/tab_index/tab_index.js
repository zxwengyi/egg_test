var tab_index_myConfig = function($stateProvider) {
    $stateProvider
        .state('tab.index', {
            url: '/index',
            views: {
                'tab-index': {
                    templateUrl: 'component/tab_index/tab_index.html',
                    controller: 'IndexCtrl'
                }
            }
        });
};
myapp.config(tab_index_myConfig);
angular.module('starter.tab_index', [])
    .controller('IndexCtrl', function($state, $scope, Common, $rootScope, $ionicSlideBoxDelegate, $ionicModal, $sce, $http,$ionicHistory,$timeout) {
        $scope.$on('$ionicView.beforeEnter', function() {
        	$rootScope.hideHeader = false;
            var nativeBroadcastMsg = null;
            window.broadcastMsgNum = function(obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
                if (typeof(obj) == "object") {
                    nativeBroadcastMsg = obj.data;
                } else {
                    nativeBroadcastMsg = angular.fromJson(obj).data;
                }
                $scope.$emit('msgNum',nativeBroadcastMsg);
            };
            //首页banner广告位
            $scope.getBanner = function(){
                Common.get("merchantAPI/ad/banner", {}, function(data) {
                        $scope.bannerImg = data.data;
                        Common.setCache("bannerImg", data.data, myCacheTime)
                        $ionicSlideBoxDelegate.$getByHandle('my-handle').update();
                        $ionicSlideBoxDelegate.$getByHandle('my-handle').loop(true);
                    }, function() {})
            }
            var myClearCacheTime = new Date().getTime;
            console.log(Common.getCache('bannerImg') == null)
            if (Common.getCache('bannerImg') == null) {
                if(Common.getCache('getDeviceIdAndClientId') == null){
                    $timeout(function(){
                        $scope.getBanner();
                    },1500);
                }else{
                    $scope.getBanner();
                }
            } else {
                $scope.bannerImg = Common.getCache('bannerImg');
                $ionicSlideBoxDelegate.$getByHandle('my-handle').update();
                $ionicSlideBoxDelegate.$getByHandle('my-handle').loop(true);
            }
            //实时刷新的数据
            var myCacheTime = new Date(new Date().format(1)).getTime() - new Date().getTime();
            
            //获取收益
            if (Common.getCache('dayResult') == null) {
                Common.get("merchantAPI/order/dayResult", {}, function(data) {
                    $scope.dayResult = data.data;
                    Common.setCache("dayResult", data.data, myCacheTime)
                }, function() {})
            } else {
                $scope.dayResult = Common.getCache('dayResult');
            }
            //本店综合评论
            $scope.myArr = [{}, {}, {}, {}, {}];
            if (Common.getCache('commentScore') == null) {
                Common.get("merchantAPI/merchant/comment/score", {}, function(data) {
                    $scope.myScore = data.data.getCommentScore;
                    Common.setCache("commentScore", data.data.getCommentScore, myCacheTime)
                }, function() {})
            } else {
                $scope.myScore = Common.getCache('commentScore');
            }
            //粉丝数量
            Common.get("merchantAPI/merchant/invite/sum", {
                    "buy": 1
                }, function(data) {
                    $scope.inviteSum = data.data;
                    Common.setCache("inviteSum", data.data, myCacheTime)
                }, function() {})
                //显示广告
            $ionicModal.fromTemplateUrl('my-modal.html', {
                scope: $scope,
                animation: 'slide-in-up'
            }).then(function(modal) {
                $scope.modal = modal;
            });
            $scope.openModal = function() {
                $scope.modal.show();
            }
            $scope.closeModal = function() {
                $scope.modal.hide();
            }
            //查看广告位
            $scope.gotoDetail = function(_data) {
//              console.log(_data)
//              $scope.myUrl = $sce.trustAsResourceUrl(_data.url);
//              $scope.title = _data.title;
//              $scope.openModal();
            }
            $scope.gotoEarning = function() {
                if ($rootScope.role == 1 || $rootScope.role == 5 || $rootScope.role == 6) $state.go("tab.index_fans_number", {
                    userid: 2
                });
                else $state.go("tab.index_earnings", {
                    type: 0
                });
            }
        });
    })
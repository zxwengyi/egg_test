var my_gathering_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_gathering', {
        url: '/my_gathering',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_gathering/my_gathering.html',
                controller: 'my_gatheringCtrl'
            }
        }
    });
};
myapp.config(my_gathering_myConfig);

angular.module('starter.my_gathering',[])
.controller('my_gatheringCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

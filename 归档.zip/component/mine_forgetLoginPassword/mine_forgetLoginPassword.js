var mine_forgetLoginPassword_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_forgetLoginPassword', {
      url: '/mine_forgetLoginPassword?{:getPhone}',
      views: {
        'tab-index': {
          templateUrl: 'component/mine_forgetLoginPassword/mine_forgetLoginPassword.html',
          controller: 'mine_forgetLoginPasswordCtrl'
        }
      }
    });
};
myapp.config(mine_forgetLoginPassword_myConfig);

angular.module('starter.mine_forgetLoginPassword', [])
  .controller('mine_forgetLoginPasswordCtrl', function($scope, $http, $rootScope, $timeout, actionSheetItem, $ionicModal, $state, toast, Common, $interval, $stateParams) {
    var timer;
    $scope.phoneCodeOK = false;
    $scope.setPasswordOK = false;
    $scope.verifyIdOK = false;

    var regIdCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;


    var regPhone = /^1(3|4|5|7|8)\d{9}$/;
    $scope.seconds = 59;
    $scope.btnText = "获取验证码";

    $scope.submit = false;
    $scope.isCounting = false;

    $ionicModal.fromTemplateUrl('verifyId.html', {
      scope: $scope,
      animation: 'slide-in-right'
    }).then(function(modal) {
      //$scope.modalIdCard = modal;
    });

    $ionicModal.fromTemplateUrl('verifyPhoneCode.html', {
      scope: $scope,
      animation: 'slide-in-right'
    }).then(function(modal) {
      $scope.modalPhoneCode = modal;
    });

    //选择要找回密码的商户
    $ionicModal.fromTemplateUrl('retrievePassword.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modal) {
      $scope.modalRetrievePassword = modal;
    });

    $ionicModal.fromTemplateUrl('setPassword.html', {
      scope: $scope,
      animation: 'slide-in-right'
    }).then(function(modal) {
      $scope.modalSetPassword = modal;
    });

    $scope.isAdmin = function(index) {
      $scope.choosedIndex = index;
    }


    //取消选择
    $scope.cancel = function() {
      $scope.modalRetrievePassword.hide()
    }


    $scope.$watch('inputData.phone', function() {
      $scope.$watch('inputData.vCode', function() {
        // if (/^\d{6}$/.test($scope.inputData.vCode) && /^1(3|4|5|7|8)\d{9}$/.test($scope.inputData.phone)) {
        if ($scope.inputData.vCode || $scope.inputData.phone) {
          $scope.phoneCodeOK = true;
        } else {
          $scope.phoneCodeOK = false;
        }
      })
    })

    //IOS计时缓慢问题
    var hiddenTime, visibleTime;
    document.addEventListener("pause", function() {
      if (!$scope.isCounting) return;
      hiddenTime = new Date().getTime();
      visibleTime = $scope.seconds;
    }, false);
    document.addEventListener("resume", function() {
      if (!$scope.isCounting) return;
      var timemax = visibleTime - ((new Date().getTime() - hiddenTime) / 1000 | 0)
      if (timemax > 0) {
        $scope.seconds = timemax;
      } else {
        $interval.cancel(timer);
        $scope.seconds = 59;
        $scope.isCounting = false;
        $scope.btnText = "重新发送";
      }
    }, false);

    $scope.$watch('inputData.pwd', function() {
      $scope.$watch('inputData.pwdConfirm', function() {
        var pwd = $scope.inputData.pwd;
        var pwdConfirm = $scope.inputData.pwdConfirm;
        if (pwd.length >= 8 && (pwd == pwdConfirm)) {
          $scope.setPasswordOK = true;
        } else {
          $scope.setPasswordOK = false;
        }
      })
    })

    $scope.$watch('inputData.idNo', function() {
      if (regIdCard.test($scope.inputData.idNo)) {
        $scope.verifyIdOK = true;
      } else {
        $scope.verifyIdOK = false;
      }
    })

    //角色选择后,下一步
    $scope.chooseRole = function() {
      if ($scope.choosedIndex) {
        $scope.modalPhoneCode.show();
        if ($scope.choosedIndex == 1) $scope.inputData.phone = '';
      } else {
        toast.show("请先选择您的角色")
      }
    }

    //获取手机验证码
    $scope.getCode = function() {
      if ($scope.btnText == "获取验证码" || $scope.btnText == "重新发送") {
        if (regPhone.test($scope.inputData.phone)) {
          $scope.isCounting = true;
          $scope.count();
          //向后台发送请求
          Common.get("merchantAPI/user/forgotPwdSendSmsCode", {
            "mobile": $scope.inputData.phone,
            "isAdmin": $scope.choosedIndex == 1 ? "1" : "0"
          }, function(data) {
            console.log('发送验证码成功...')
          }, {})
        } else {
          toast.show("请输入正确的手机号")
        }
      }
    }

    //短信倒计时
    $scope.count = function() {
      $scope.btnText = "59S";
      timer = $interval(function() {
        $scope.seconds--;
        if ($scope.seconds != 0) {
          $scope.seconds = $scope.seconds >= 10 ? $scope.seconds : "0" + $scope.seconds;
          $scope.btnText = $scope.seconds + "S";
        } else {
          $interval.cancel(timer);
          $scope.seconds = 59;
          $scope.isCounting = false;
          $scope.btnText = "重新发送";
        }
      }, 1000)
    }

    //返回,隐藏手机验证modal
    $scope.closePhoneCodeModal = function() {
      $scope.modalPhoneCode.hide();
    }

    //返回，隐藏身份证模态框
    $scope.closeModal = function() {
      //$scope.modalIdCard.hide();
    };

    //返回，隐藏密码设置模态框
    $scope.closePasswordModal = function() {
      $scope.modalSetPassword.hide();
    };

    //返回登录
    $scope.goBack = function() {
      $state.go('tab.mine_toLogin')
    }


    //选择要找找回密码的商户
    $scope.chooseMerchant = function(index, e, obj) {
      angular.element(e.target.parentElement).children().removeClass('icon_checked')
      angular.element(e.target).addClass('icon_checked')
      $scope.operatorId = obj.operatorId;
    }

    //【确认】，选择找回密码商户
    $scope.sure = function() {
      console.log('operatorId:' + $scope.operatorId)
      if (!$scope.operatorId) {
        toast.show('请选择要找回密码的商户')
      } else {
        if ($scope.choosedIndex == 1) {
          $scope.modalSetPassword.show();
        } else {
          // 如果是用户,必须进行身份证验证
          //$scope.modalIdCard.show();
        }
      }
    }

    //完成手机验证，【下一步】,判断是否一个手机绑定多个商户
    $scope.verifyPhoneComplete = function() {
        /*  $http({
              method: 'get',
              url: '/data/aaa.json'
            }).then(function(res) {
              console.log(res)
              if (res.data.data.length == 1) {
                $scope.operatorId = res.data.data[0].operatorId; //operaterId需最后一步传给后台
                //判断是否是商户，然后跳转下一步
              } else {
                if ($scope.choosedIndex == 1) {
                  $scope.modalRetrievePassword.show();
                }
                $scope.merchantLists = res.data.data;
              }
            })
            */
        if (regPhone.test($scope.inputData.phone)) {
          if (/^\d{6}$/.test($scope.inputData.vCode)) {
            if (!$scope.canClick) return;
            $scope.canClick = false; //防止用户双击
            $scope.doubleClick_timer()
            Common.post("merchantAPI/user/forgotPwdVerifySmsCode", {
              "mobilePhone": $scope.inputData.phone,
              "isAdmin": $scope.choosedIndex == 1 ? "1" : "0", //1:管理员 0：非管理员
              "verifyCode": $scope.inputData.vCode
            }, function(res1) {
              //token
              token = res1.data.token;
              $scope.inputData.vCode = '';
              if ($scope.choosedIndex == 1) { //如果是【管理员】才查询是否一个手机对应多个商户
                Common.post("merchantAPI/user/getAdminByMobile", {
                  "mobilePhone": $scope.inputData.phone,
                  "token": token
                }, function(res2) {
                  if (res2.data.length == 1) { //如果返回数据长度为1，则不弹出商户选择框
                    $scope.operatorId = res2.data[0].operatorId; //operaterId需最后一步传给后台
                    $scope.modalSetPassword.show();
                  } else if (res2.data.length > 1) { //如果返回数据长度 > 1
                    $scope.modalRetrievePassword.show();
                    $scope.merchantLists = res2.data;
                  }
                }, {})
              } else if ($scope.choosedIndex == 2) { //如果是用户直接跳转下一步
                //$scope.modalIdCard.show();
                  $scope.modalSetPassword.show();
              }
            }, {})
          } else {
            toast.show("请输入正确格式的验证码")
          }
        } else {
          toast.show("请输入正确格式的手机号")
        }
      }
      // $scope.verifyPhoneComplete = function() {
      //   if (regPhone.test($scope.inputData.phone)) {
      //     if (/^\d{6}$/.test($scope.inputData.vCode)) {
      //       Common.post("merchantAPI/user/forgotPwdVerifySmsCode", {
      //         "mobilePhone": $scope.inputData.phone,
      //         "isAdmin": $scope.choosedIndex == 1 ? "1" : "0",
      //         "verifyCode": $scope.inputData.vCode
      //       }, function(data) {
      //         //token
      //         token = data.data.token;
      //         //如果是管理员,无需id验证
      //         if ($scope.choosedIndex == 1) {
      //           $scope.modalSetPassword.show();
      //         } else {
      //           //如果是用户,必须进行身份证验证
      //           $scope.modalIdCard.show();
      //         }
      //       }, {})
      //     } else {
      //       toast.show("请输入正确格式的验证码")
      //     }
      //   } else {
      //     toast.show("请输入正确格式的手机号")
      //   }
      // }

    //验证身份证是否输入正确
    var isCardID = function(sId) {
      if (!regIdCard.test(sId)) return "你输入的身份证长度或格式错误";
      return true;
    }

    //下一步，显示设置密码模态框
    $scope.verifyIdComplete = function() {
      var result = isCardID($scope.inputData.idNo);
      if (result === true) {
        if (!$scope.canClick) return;
        $scope.canClick = false; //防止用户双击
        $scope.doubleClick_timer()
          //验证身份证
        Common.post('merchantAPI/user/forgotPassword', {
          "idCard": $scope.inputData.idNo ? $scope.inputData.idNo : '',
          "mobilePhone": $scope.inputData.phone,
          "token": token,
          "isAdmin": $scope.choosedIndex == 1 ? "1" : "0"
        }, {}, {}, 1, function(res) {
          if (res.result === "000000") {
            //$scope.modalIdCard.hide();
            $scope.modalSetPassword.show();
          } else if (res.result == "000009") {
            Common.showAlert('温馨提示', res.description, function() {
              //$scope.modalIdCard.hide();
              $scope.inputData.vCode = "";
            })
          } else {
            Common.showAlert('温馨提示', res.description);
          }
        });
      } else {
        toast.show(result);
      }
    };

    //防双击
    $scope.doubleClick_timer = function() {
      var timer = $timeout(function() {
        $scope.canClick = true;
        $timeout.cancel(timer);
      }, 2000);
    }

    //完成密码修改
    $scope.modifyPasswordComplete = function() {
      console.log('operatorId:' + $scope.operatorId)
      var p1 = $scope.inputData.pwd;
      var p2 = $scope.inputData.pwdConfirm;
      var reg = /^[^/|\\|\s|\u4e00-\u9fa5]{8,16}$/;
      var regAllNum = /^\d{8,16}$/;
      var regAllAlphabet = /^[a-zA-Z]{8,16}$/;
      var regAllSymbol = /^^[!@`~#\*^+-.%&<>()',;_"'=?\$\x22]{8,16}$/;
      if (p1 && p2) {
        if (p1 === p2) {
          if (reg.test(p2)) {
            if (!regAllNum.test(p2) && !regAllAlphabet.test(p2) && !regAllSymbol.test(p2)) {
              $scope.tips = false;
              if (!$scope.canClick) return;
              $scope.canClick = false; //防止用户双击
              $scope.doubleClick_timer()
              Common.checkMd5("GL_SALT_MD5_KEY" + $scope.inputData.pwd.toString(), function(data) {
                  Common.post('merchantAPI/user/forgotPassword', {
                    "mobilePhone": $scope.inputData.phone,
                    "password": data.MD5,
                    "token": token,
                    "isAdmin": $scope.choosedIndex == 1 ? "1" : "0",
                    "operatorId": $scope.operatorId
                  }, {}, {}, 1, function(data) {
                    if (data.result == "000000") {
                      toast.show('密码重置成功！')
                        //隐藏modal才能跳转
                      //$scope.modalIdCard.hide();
                      $scope.modalSetPassword.hide();
                      $scope.modalPhoneCode.hide();
                      $scope.modalRetrievePassword.hide()
                      $timeout(function() {
                          Common.logout();
          				  $state.go("tab.mine_toLogin",{}, { reload: true });
                        }, 0);
                    } else {
                      Common.showAlert('温馨提示', data.description, function() {
                        //请求不成功，清空用户输入，跳转到手机验证码界面
                        $scope.inputData = {
                          phone: '',
                          vCode: '',
                          idNo: '',
                          pwd: '',
                          pwdConfirm: ''
                        }
                        token = '';
                        //$scope.modalIdCard.hide();
                        $scope.modalSetPassword.hide();
                        $scope.modalPhoneCode.hide();
                        $scope.modalRetrievePassword.hide()
                        $scope.tipsContent = '';
                        $scope.choosedIndex = '';
                        $scope.tips = false;
                        $scope.merchantLists = []
                        $scope.operatorId = ''
                      })
                    }
                  }); //noSuccess
                }) //checkMD5
            } else { //完成密码JS校验
              $scope.tips = true;
              $scope.tipsContent = "您的密码过于简单,不能为纯数字、纯字母、纯字符,请重新设置";
            }
          } else {
            $scope.tips = true;
            $scope.tipsContent = "密码为8-16位数字与字符组合,不能含有/,\\等敏感字符";
          }
        } else {
          $scope.tips = true;
          $scope.tipsContent = "两次密码输入不一致";
        }
      } else {
        $scope.tips = true;
        $scope.tipsContent = "请输入密码";
      }
    }
    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.tipsContent = '';
      // $scope.admin = '';
      $scope.choosedIndex = '';
      $scope.tips = false;
      var token = '';
      $scope.inputData = {
        phone: '',
        vCode: '',
        idNo: '',
        pwd: '',
        pwdConfirm: ''
      }

      $scope.merchantLists = []
      $scope.operatorId = ''
      $scope.canClick = true; //防止用户双击
    });
  });
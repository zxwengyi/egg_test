var mine_merchantServiceTerms_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.mine_merchantServiceTerms', {
        url: '/mine_merchantServiceTerms',
        views: {
            'tab-mine': {
                templateUrl: 'component/mine_merchantServiceTerms/mine_merchantServiceTerms.html',
                controller: 'mine_merchantServiceTermsCtrl'
            }
        }
    });
};
myapp.config(mine_merchantServiceTerms_myConfig);

angular.module('starter.mine_merchantServiceTerms',[])
.controller('mine_merchantServiceTermsCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

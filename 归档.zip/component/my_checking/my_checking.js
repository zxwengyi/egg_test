var my_checking_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_checking', {
        url: '/my_checking',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_checking/my_checking.html',
                controller: 'my_checkingCtrl'
            }
        }
    });
};
myapp.config(my_checking_myConfig);

angular.module('starter.my_checking',[])
.controller('my_checkingCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

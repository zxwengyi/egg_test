var discountHistory_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.discountHistory', {
        url: '/discountHistory',
        views: {
            'tab-mine': {
                templateUrl: 'component/discountHistory/discountHistory.html',
                controller: 'discountHistoryCtrl'
            }
        }
    });
};
myapp.config(discountHistory_myConfig);

angular.module('starter.discountHistory',[])
.controller('discountHistoryCtrl', function($scope,Common) {
    $scope.goBack=function(){
        window.history.back()
    }
    Common.get("merchantAPI/merchant/glfeerate/info", {
        "curPage": 1,
        "pageSize": 20
    }, function(data) {
      console.log(data)
    }, {});
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

var staff_manage_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.staff_manage', {
            url: '/staff_manage',
            views: {
                'tab-mine': {
                    templateUrl: 'component/staff_manage/staff_manage.html',
                    controller: 'staff_manageCtrl'
                }
            }
        })
        .state('tab.staff_manage_add', {
            url: '/staff_manage_add',
            views: {
                'tab-mine': {
                    templateUrl: 'component/staff_manage/staff_manage_add.html',
                    controller: 'staff_manage_addCtrl'
                }
            }
        })
        .state('tab.staff_manage_edit', {
            url: '/staff_manage_edit/:operatorId',
            views: {
                'tab-mine': {
                    templateUrl: 'component/staff_manage/staff_manage_edit.html',
                    controller: 'staff_manage_editCtrl'
                }
            }
        });
};
myapp.config(staff_manage_myConfig);

angular.module('starter.staff_manage', [])
    .controller('staff_manageCtrl', function ($scope, $ionicHistory, Common,$state) {
		$scope.goBack = function() {
            $state.go('tab.my_manager')
		};

        $scope.shouldShowDelete = false;
        $scope.listCanSwipe = true;

        $scope.currentIndex = 0;
        //取消关联
        $scope.confirmCancel = function(index){
            console.log("current index = "+index);
            $scope.currentIndex = index;
            Common.showConfirm("信息提示","您确认要取消关联吗，取消后该用户将失去与本店相关的权限？",function(){
                $scope.ok();
            },{},"确定","取消")
        };
        //确认取消
        $scope.ok = function() {
            var operatorId = $scope.items[$scope.currentIndex].operatorId;
            Common.post('merchantAPI/operator/updateStatus', {operatorId:operatorId}, function(data) {
                console.log(data.data);
                $scope.items.splice($scope.currentIndex, 1);
            }, function(error) {
                console.log(error);
            }, {});
        };

        $scope.$on('$ionicView.beforeEnter', function () {
            //查员工列表
            Common.post('merchantAPI/operator/list', {}, function (data) {
                console.log(data.data);
                $scope.items = data.data || [];
            }, function (error) {
                console.log(error);
            }, {});
        });
    })
    
    .controller('staff_manage_addCtrl', function ($scope, $ionicHistory, $ionicPopup, $state, $interval, $ionicModal, Common,toast) {
		$scope.goBack = function() {
			window.history.back();
		};

        $scope.obj = {
            operatorName : "",//
            telphone:'',
//          smsVerify:'',
            idCard : "",
            operatorNo:'',//员工工号
            status:'0',//0正常 1禁用
            roleID:'3',//用户角色(2店长，3操作员)
            parentId:'-1',//店长ID(-1无分配店长,提交后台要置空)
            parentName:'无分配店长',//店长姓名
            authStatus:1,
            userId:'',
            cashierBoo: false,//收银台
            staffmanagementBoo: false//员工管理
        };
        $scope.checkItem = function(_num){
        	$scope.obj.roleID = _num;
        }
        $scope.cashierBooClick = function(){
        	$scope.obj.cashierBoo = !$scope.obj.cashierBoo;
        }
        $scope.staffmanagementBooClick = function(){
        	$scope.obj.staffmanagementBoo = !$scope.obj.staffmanagementBoo;
        }
        var timer;
        //下一步
        $scope.next = function () {
            // if(!$scope.obj.smsVerify || $scope.obj.smsVerify === ''){
            //     toast.show("验证码不能为空");
            //     return;
            // }
            // var params = {
            //     "businessType": 5,
            //     "phoneNo": $scope.obj.telphone,
            //     "verifyCode": $scope.obj.smsVerify
            // };
            // Common.post('merchantAPI/sms/verifySms', params, function(data) {
                userInfoByPhone();
            //     $scope.isSMSVerify = false;
            //     $interval.cancel(timer);
            //     $scope.seconds = 59;
            //     $scope.obj.smsVerify = '';
            // }, function(error) {
            //     console.log(error);
            // });
        };
        
        //根据员工手机号查询员工信息
        function userInfoByPhone() {
            Common.post('merchantAPI/operator/add/check', {phone: $scope.obj.telphone}, function (data) {
                var _data = data.data;
                $scope.obj.operatorName = _data.name;
                $scope.obj.telphone = _data.phone;
                $scope.obj.idCard = _data.idCard;
                $scope.obj.userId = _data.userId;
                $scope.obj.authStatus = _data.authStatus;//是否实名认证(0未实名)
                if (_data.authStatus === 0) {
                    $scope.isReal = false;
                } else {
                    $scope.isReal = true;
                }
                $scope.isSMSVerify = false;
                //查询店长列表
                queryShopowner();
            }, function (error) {
                console.log(error);
            }, {});
        }
        $scope.currentIndex = 0;
        $scope.staffLeaderArr = [{operatorId:'-1',operatorName:'无分配店长'}];
        //查询所有店长
        function queryShopowner (){
            Common.get('merchantAPI/operator/shopowner', {}, function (data) {
                if(data.data){
                    $scope.staffLeaderArr = $scope.staffLeaderArr.concat(data.data);
                }
            }, function (error) {
                console.log(error);
            });
        }
        //打开店长选择框
        $scope.chooseLeader = function () {
            $scope.showConfirmDialog = true;
            $scope.obj.parentId = $scope.staffLeaderArr[$scope.currentIndex].operatorId;
        };
        //选择
        $scope.selected = function(index){
            $scope.currentIndex = index;
        };
        //取消选择店长
        $scope.cancel = function(){
            $scope.showConfirmDialog = false;
        };
        //选择确定按钮
        $scope.ok = function(){
            $scope.obj.parentId = $scope.staffLeaderArr[$scope.currentIndex].operatorId;
            $scope.obj.parentName = $scope.staffLeaderArr[$scope.currentIndex].operatorName;
            $scope.showConfirmDialog = false;
        };
        //保存员工信息
        $scope.save = function(){
            if ($scope.obj.parentId === "-1") { //-1是前端维护的无分配店长状态，提交后台时置空
                $scope.obj.parentId = '';
            }
            if (!$scope.obj.operatorName || $scope.obj.operatorName === '') {
                toast.show("员工姓名不能为空");
                return;
            }
            if (!$scope.obj.idCard || $scope.obj.idCard === '') {
                toast.show("身份号码不能为空");
                return;
            }
            if (!isCardID($scope.obj.idCard)) {
                toast.show("身份证号码格式错误");
                return;
            }
            if (!$scope.obj.operatorNo || $scope.obj.operatorNo === '') {
                toast.show("员工工号不能为空");
                return;
            }
            Common.post('merchantAPI/operator/add', $scope.obj, function (data) {
                $state.go("tab.staff_manage");
            }, function (error) {
                toast.show("新增员工失败");
            });
        };
        //发送短信验证码
        $scope.sendSMS = function() {
            if(!/^1[0-9]{10}$/.test($scope.obj.telphone)){
                Common.showAlert("","请输入正确的手机号");
                return;
            }
            if($scope.btnText === "发送验证码" || $scope.btnText === "重新发送"){
                var params = {
                    "businessType": 5,
                    "phoneNo": $scope.obj.telphone,
                    "sendType": ""
                };
                Common.post('merchantAPI/sms/sendSms', params, function(data) {
                    $scope.count();
                }, function(error) {
                    toast.show("发送短信失败");
                });
            }
        };

        //短信倒计时
        $scope.count = function(){
            $scope.btnText="59s后重发";
            timer = $interval(function(){
                $scope.seconds--;
                if($scope.seconds != 0){
                    $scope.seconds = $scope.seconds >=10 ? $scope.seconds : "0"+$scope.seconds;
                    $scope.btnText=$scope.seconds+"s后重发";
                }else{
                    $interval.cancel(timer);
                    $scope.seconds=59;
                    $scope.btnText="重新发送";
                }
            },1000) 
        };

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.btnText = "发送验证码";
            $scope.seconds = 59;
            //显示发短信界面
            $scope.isSMSVerify = true;
            //B端-新增员工验证后有无姓名身份信息
            $scope.isReal = false;
        });
        //验证身份证号码正确性
        function isCardID(sId) {
            var regIdCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;
            return regIdCard.test(sId);
        }
    })
    .controller('staff_manage_editCtrl', function ($scope, $ionicHistory, $ionicModal, $ionicPopup, $state, $stateParams, Common) {
		$scope.goBack = function() {
			window.history.back();
		};

        $scope.role = Common.getCache("Token").role;
		
        $scope.obj = {
            image:'',//员工头像
            operatorName : "",//用户名称
            telphone:'',
            idCard : "",//身份证
            operatorNo:'',//员工工号
            status:'0',//0正常 1禁用
            roleID:'3',//用户角色(2店长3操作员)
            parentId:'',//店长ID
            parentName:'',//店长姓名
            cashierBoo:false,//收银台
            staffmanagementBoo:false//员工管理
        };
        $scope.checkItem = function(_num){
        	$scope.obj.roleID = _num;
        }
        $scope.cashierBooClick = function(){
        	$scope.obj.cashierBoo = !$scope.obj.cashierBoo;
        }
        $scope.staffmanagementBooClick = function(){
        	$scope.obj.staffmanagementBoo = !$scope.obj.staffmanagementBoo;
        }
        //员工
        var operatorId = $stateParams.operatorId;//员工Id

        $scope.staffLeaderArr = [{operatorId:'-1',operatorName:'无分配店长'}];
        //查询所有店长
        function queryShopowner (){
            Common.showLoading();
            Common.get('merchantAPI/operator/shopowner', {}, function (data) {
                if(data.data){
                    $scope.staffLeaderArr = $scope.staffLeaderArr.concat(data.data);
                }                
                for (var i = 0; i < $scope.staffLeaderArr.length; i++) {
                    if($scope.staffLeaderArr[i].operatorId == $scope.obj.parentId){
                        $scope.currentIndex = i;
                        break;
                    }
                }
                Common.hideLoading();
            }, function (error) {
                console.log(error);
            });
        }
        //打开店长选择框
        $scope.chooseLeader = function () {
            $scope.showConfirmDialog = true;
            console.log($scope.currentIndex)
            $scope.obj.parentId = $scope.staffLeaderArr[$scope.currentIndex].operatorId;
        };

        //选择
        $scope.selected = function(index){
            $scope.currentIndex = index;
        };
        //取消
        $scope.cancel = function(){
            $scope.showConfirmDialog = false;
        };
        //确定
        $scope.ok = function(){
            $scope.obj.parentName = $scope.staffLeaderArr[$scope.currentIndex].operatorName;
            $scope.obj.parentId = $scope.staffLeaderArr[$scope.currentIndex].operatorId;//店长ID
            $scope.showConfirmDialog = false;
        };

        //保存员工信息
        $scope.save = function(){
            if ($scope.obj.parentId == "-1") { //-1是前端维护的无分配店长状态，提交后台时置空
                $scope.obj.parentId = '';
            }
            if ($scope.obj.operatorNo == '') {
                toast.show("员工工号不能为空");
                return;
            }
            Common.post('merchantAPI/operator/update', $scope.obj, function (data) {
                $state.go("tab.staff_manage");
            }, function (error) {
                console.log(error);
            });
        };

        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.currentIndex = 0;
            //员工明细
            Common.showLoading();
            Common.get('merchantAPI/operator/info', {operatorId:operatorId}, function (data) {
                $scope.obj = data.data;
                if (!$scope.obj.parentName || $scope.obj.parentName == '') {
                    $scope.obj.parentName = '无分配店长';
                }
                Common.hideLoading();
                queryShopowner();
            }, function (error) {
                console.log(error);
            });
        });

    });

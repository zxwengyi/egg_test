var my_card_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_card', {
        url: '/my_card',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_card/my_card.html',
                controller: 'my_cardCtrl'
            }
        }
    });
};
myapp.config(my_card_myConfig);

angular.module('starter.my_card',[])
.controller('my_cardCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

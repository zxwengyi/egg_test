var mine_payDetail_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.mine_payDetail', {
        url: '/mine_payDetail',
        views: {
            'tab-mine': {
                templateUrl: 'component/mine_payDetail/mine_payDetail.html',
                controller: 'mine_payDetailCtrl'
            }
        }
    });
};
myapp.config(mine_payDetail_myConfig);

angular.module('starter.mine_payDetail',[])
.controller('mine_payDetailCtrl', function($scope,$timeout) {
    $scope.isHasMore = false;
    $scope.doRefresh = function(){
        console.log("下拉刷新")
         $timeout(function () { 
            $scope.$broadcast('scroll.refreshComplete');
        },500)   
    }

  

    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

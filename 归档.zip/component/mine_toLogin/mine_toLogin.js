var mine_toLogin_myConfig = function ($stateProvider) {
  $stateProvider
    .state('tab.mine_toLogin', {
      url: '/mine_toLogin?{:tel}',
      views: {
        'tab-index': {
          templateUrl: 'component/mine_toLogin/mine_toLogin.html',
          controller: 'mine_toLoginCtrl'
        }
      }
    }).state('tab.agreement', {
      url: '/mine_agreement',
      views: {
          'tab-index': {
              templateUrl: 'component/mine_toLogin/mine_agreement.html',
              controller: 'msg_payCtrl'
          }
      }
  }).state('tab.step', {
    url: '/mine_step',
    views: {
        'tab-index': {
            templateUrl: 'component/mine_toLogin/mine_step.html',
            controller: 'msg_payCtrl'
        }
    }
});
};
myapp.config(mine_toLogin_myConfig);

angular.module('starter.mine_toLogin', [])
  .controller('mine_toLoginCtrl', function ($scope, $http, $state, $stateParams, Common, toast, cordovaPlug, $rootScope, $timeout, $ionicHistory, $ionicScrollDelegate) {
    // 隐私些协议
    // if (Common.getCache('ISAGREEN') == 'ISAGREEN') {
    //   $scope.showConfirmDialog = false
    // } else {
    //   $scope.showConfirmDialog = true
    // }
    $scope.phone_focus = false;
    $scope.pwd_focus = false;
    $scope.show_pwd = false;
    $scope.hasInput = false;
    var regPhone = /^1(3|4|5|7|8)\d{9}$/;
    $scope.showTel = function () {
      Common.showConfirm('', '确定拨打电话：4000-200-365 吗？', function () {
        cordovaPlug.CommonPL(function () {}, "telephone", ['4000-200-365'])
      }, {}, '确认', '取消')
    };
    //获取焦点动态
    $scope.slideBottom = function () {
    	/*$timeout(function(){
    		$ionicScrollDelegate.scrollBottom(true)
    	},300)*/
    }
    $scope.$on('$ionicView.beforeEnter', function () {
      $ionicHistory.clearCache();
      $ionicHistory.clearHistory();
      //实时刷新的数据
      if (Common.getCache('Token') != null) {
        $rootScope.role = Common.getCache('Token').role;
        $rootScope.information = Common.getCache('Token');
        $timeout(function () {
          $state.go('tab.index_new');
        }, 200)

        return;
      }
      var lastUser = Common.getCache('lastUser') || "";
      $scope.inputData = {
        phone: lastUser ? lastUser : $stateParams.tel,
        pwd: '',
        isAgreen: true
      };

      $scope.$watch("inputData.phone", function () {
        $scope.$watch("inputData.pwd", function () {
          // if ($scope.inputData.phone.length >= 8 && $scope.inputData.pwd.length >= 8) {
          if ($scope.inputData.phone || $scope.inputData.pwd) {
            $scope.hasInput = true;
          } else {
            $scope.hasInput = false;
          }
        })
      })
      $scope.clearPhone = function () {//点击叉号时清除手机号码
        $scope.inputData.phone = '';
      }
      $scope.clearPwd = function () {//点击叉号时清除密码
        $scope.inputData.pwd = '';
      }

      $scope.phoneFocus = function () { //手机输入框获得焦点
        $scope.phone_focus = true;
      }

      $scope.phoneBlur = function () {//手机输入框失去焦点
        $scope.phone_focus = false;
      }

      $scope.pwdFocus = function () {//密码输入框获得焦点
        $scope.pwd_focus = true;
      }

      $scope.pwdBlur = function () {//密码输入框失去焦点
        $scope.pwd_focus = false;
      }

      $scope.showPwd = function () {
        if (!$scope.show_pwd) {
          //显示密码
          $scope.show_pwd = true;
          // $scope.pwd_focus = false;
          $scope.pwd_focus = true;
          $scope.phone_focus = false;
          $scope.pwd_focus = true;
        } else {
          //隐藏密码 
          $scope.show_pwd = false;
          // $scope.pwd_focus = false;
          $scope.pwd_focus = true;
          $scope.phone_focus = false;
          $scope.pwd_focus = true;
        }
      }
      //返回注册
      $scope.gotoRegister = function () {
        if ($stateParams.nextStep == 1) $state.go("tab.tab_register", {
          "nextStep": 1
        });
        else $state.go("tab.tab_register");
      }
      $scope.findAccount = function () { 
        $state.go('tab.mine_forgetLoginAccout')
      }
      // 用户协议
      $scope.selectInput = function () { 
        $scope.inputData.isAgreen = !$scope.inputData.isAgreen
      }
      //隐私些协议------取消不同意  是否同意隐私些协议内容 同意则进入登录页面进行操作 反之 则退出该应用程序。
     /*  $scope.cancelagreen = function() {
        $scope.showConfirmDialog = false
        $scope.showConfirm = true
      }
      //隐私些协议---- 仍不同意
      $scope.agincancel = function() {
        $scope.showConfirmDialog = false
        $scope.showConfirm = false
        Common.showConfirm('', '<span style="font-size:18px;font-weight:bold">确认退出应用</span>', function () {
          $scope.showConfirmDialog = true
          // Common.setCache('NOAGREEN', 'NoAgreen');
        }, function () {
            // 不同意则退出应用程序
            Common.logout()
            console.log('退出应用')
        }, '再次查看', '退出应用')
      }
      // 隐私些协议---查看用户协议详情
      $scope.toLink = function () {
        $state.go('tab.agreement')
      }
      // 隐私些协议-----同意 ISAGREEN为同意存值 作为进入界面时是否同意的判断依据
      $scope.agreen = function() {
        $scope.showConfirmDialog = false
        Common.setCache('ISAGREEN', 'ISAGREEN');
      } */
      $scope.gotoAgreen = function () { 
        $state.go('tab.agreement')
      }
      // 登录
      $scope.login = function () {
        var tel = $scope.inputData.phone;
        var pwd = $scope.inputData.pwd;
        console.log('$scope.isAgreen>>>>', $scope.inputData.isAgreen)
        if (!$scope.inputData.isAgreen) {
          toast.show("请先阅读并同意给乐商家用户协议！")
          return
        }
        if (tel || pwd) {
          if (tel.length >= 8) {
            if (pwd) {
              if ($scope.hasInput) {
                //TODO: 登录
                //TODO: 登录
                var myDevice = Common.getCache('getDeviceIdAndClientId') || {};
                Common.post_login('merchantAPI/login', {
                  deviceName: myDevice.deviceName || "",
                  deviceVersion: myDevice.deviceVersion || "",
                  deviceAppVersion: myDevice.deviceAppVersion || "",
                  username: tel,
                  password: pwd,
                  bfrontVersion: 114
                }, function (data) {
                  //Common.setCache('LoggedOn',true);
                  Common.setCache('Token', data.data);
                  var time = new Date().format() + ' ' + new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
                  Common.setCache('msgTime', time);
                  Common.setCache('lastUser', tel);
                  $http({
                    method: 'get',
                    url: './data/bank.json'
                  }).then(function (data) {
                    Common.setCache("allBankInfo", data.data);
                  })
                  //向原生外放极光推送广播
                  if (data.data.role == 1 || data.data.role == 5 || data.data.role == 6) {
                    cordovaPlug.CommonPL(function (data) { }, "login", [data.data.operatorId, data.data.role]);
                  } else {
                    cordovaPlug.CommonPL(function (data) { }, "login", [data.data.userId, data.data.role]);
                  }
                  if (data.data.role == 5 || data.data.role == 6) {
                    Common.post("merchantAPI/merchant/getChainBusinessList", {}, function (_data) {
                      $rootScope.myArr = _data.data;
                      var activeNum = 0;
                      if ($rootScope.myArr.merchantList.length > 0) {
                        for (i in $rootScope.myArr.merchantList) {
                          if (data.data.role == 5) activeNum = $rootScope.myArr.merchantList[i].merchantNo === $rootScope.myArr.merchantNo ? i : 0;
                          $rootScope.myArr.merchantList[i].active = false;
                        }
                        $rootScope.myArr.merchantList[activeNum].active = true;
                        $rootScope.merchantsChooseName = $rootScope.myArr.merchantList[activeNum].merchantName
                        Common.post('merchantAPI/user/changeChainBusiness', {
                          branchMerchantNo: $rootScope.myArr.merchantList[activeNum].merchantNo,
                          branchOperatorId: $rootScope.myArr.merchantList[activeNum].operatorId,
                          mainOperatorId: $rootScope.myArr.operatorId,
                          mainmerchantNo: $rootScope.myArr.merchantNo
                        }, function (res) {
                          var newData = angular.extend(data.data, res.data.data);
                          newData.username = tel;
                          newData.name = $rootScope.myArr.merchantList[activeNum].name;
                          newData.operatorId = $rootScope.myArr.merchantList[activeNum].operatorId;
                          Common.setCache('Token', newData);
                        if (newData.role == 1 && Common.getCache(newData.operatorId) == null) Common.setCache(newData.operatorId, "1")
                          $rootScope.role = _data.data.role;
                          $rootScope.onLinePay = _data.data.onLinePay;
                          $rootScope.saleRate = _data.data.saleRate;
                          $rootScope.information = Common.getCache('Token');
                            _data.data.role == 5 ? $state.go('tab.my_allmanager') : $state.go('tab.index_new');
                            // $scope.showConfirmDialog = true
                        }, {}, 1)
                      }


                    }, {}, 1)
                    /*Common.post('merchantAPI/wxpay/act/wallet/info', {}, function(data) {
                      if (data.data.status == 3) {
                        Common.setCache('wxpayMess', 1)
                      } else if (data.data.status == 1) {
                        Common.showConfirm('', '您的交易账户已受理，请前往给乐商家APP-我的-钱包页面完成设置以便交易资金及时汇入', function() {
                          Common.post('merchantAPI/wxpay/act/wallet/url/get', {}, function(res) {
                            cordovaPlug.CommonPL(function(data) {}, "weChatPay", [res.data.authUrl])
                          }, {}, 1)
                        }, {}, "去设置", '取消')
                        Common.setCache('wxpayMess', 1, 1 * 24 * 3600000);
                      }
                    }, {})*/
                    return;
                  }
                  Common.get('merchantAPI/merchant/basics', {}, function (_data) {
                    var newData = angular.extend(data.data, _data.data);
                    newData.username = tel;
                    Common.setCache('Token', newData);
                    if (newData.role == 1 && Common.getCache(newData.operatorId) == null) Common.setCache(newData.operatorId, "1")
                    console.log(newData);
                    $rootScope.role = data.data.role;
                    $rootScope.onLinePay = data.data.onLinePay;
                    $rootScope.saleRate = data.data.saleRate;
                    $rootScope.discountRate = newData.discountRate
                    //收银台扫一扫，如果不是“中付”则置灰 10004
                    //2018.08.06 ,改为“付费通”支付  10001
                    //2018.08.06 ,改为“融脉”支付  10003
                    // $rootScope.canUseScan = data.data.liquidationId == '10004' ? true : false;
                    // 安卓手机，关闭手机进程，再重启APP，扫一扫会置灰
                    // $rootScope.canUseScan = (data.data.liquidationId == '10001' || data.data.liquidationId == '10003') ? true : false;
                    Common.setCache('canUseScan',data.data.onLinePay )
                    $rootScope.information = Common.getCache('Token');
                    Common.showLoading();
                    $timeout(function () {
                      Common.hideLoading();
                      $state.go('tab.index_new')
                      // Common.getCache('ISAGREEN',ISAGREEN)
                      // $state.go('tab.index_new')
                      /*if ($rootScope.role == 1) {
                        var accType = newData.merchantType == 2 && newData.linkType == 1 ? '1' : '0';
                        Common.post('merchantAPI/wxpay/act/wallet/info', {
                          accType: accType
                        }, function(data) {
                          //分店+统一结算，查询分润钱包

                          if (data.data.status == 3) {
                            Common.setCache('wxpayMess', 1)
                          } else if (data.data.status == 1) {
                            Common.showConfirm('', '请前往“我的-钱包”尽快完善账号信息，以便收益金及时汇入', function() {
                              Common.post('merchantAPI/wxpay/act/wallet/url/get', {
                                accType: accType
                              }, function(res) {
                                cordovaPlug.CommonPL(function(data) {}, "weChatPay", [res.data.authUrl])
                              }, {}, 1)
                            }, {}, "去设置", '取消')
                            Common.setCache('wxpayMess', 1, 1 * 24 * 3600000);
                          } else if (data.data.status == 0) {
                            Common.showConfirm('', '请前往给乐商家APP-我的-钱包页面完成设置以便分润资金及时汇入', function() {
                              $state.go('tab.mine_openAccount')
                            }, {}, "去设置", '取消')
                            Common.setCache('wxpayMess', 1, 1 * 24 * 3600000);
                          }
                        }, {})
                      }*/
                    }, 1000);
                  }, {})

                }, {})
              }
            } else {
              toast.show("请输入您的密码")
            }
          } else {
            toast.show("ID或手机号格式有误")
          }
        }
      }
    });
  });
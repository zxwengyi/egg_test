var paying_myConfig = function($stateProvider) {
    $stateProvider
        .state('tab.paying', {
            url: '/paying/:barCode/:userid/:price',
            views: {
                'tab-cashier': {
                    templateUrl: 'component/paying/paying.html',
                    controller: 'payingCtrl'
                }
            }
        })
        .state('tab.pay_error', {
            url: '/pay_error',
            views: {
                'tab-cashier': {
                    templateUrl: 'component/paying/pay_error.html',
                    controller: 'pay_errorCtrl'
                }
            }
        })
        .state('tab.collection_success', {
            url: '/collection_success/:totalAmount',
            views: {
                'tab-cashier': {
                    templateUrl: 'component/paying/pay_success.html',
                    controller: 'pay_successCtrl1'
                }
            }
        });
};
myapp.config(paying_myConfig);

angular.module('starter.paying', [])
    .controller('payingCtrl', function($scope, Common, $stateParams, $state, $timeout) {
        $scope.chackBoo = true;
        $scope.goBack = function(){
            window.history.back();
        }
        $scope.$on('$ionicView.beforeLeave', function() {
            $scope.chackBoo = false;
        });
        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.chackBoo = true;
            $scope.info = Common.getCache('Token');
            var myTimeNew;
            var nowTimer = new Date().getTime();
            $scope.terminalId = Common.getCache('getDeviceIdAndClientId').DeviceId.toString().substring(0, 8);
            Common.post('merchantAPI/order/getOrderNo', {
                "barCode": $stateParams.barCode,
                "merchantNo": $scope.info.merchantNo,
                "payUserId": $stateParams.userid,
                "scene": 1
            }, function(data) {
                Common.post('merchantAPI/order/barCodePay', {
                    "barCode": $stateParams.barCode,
                    "desc": 'B扫C功能测试',
                    "merOrderId": data.data.orderNo,
                    "merchantNo": $scope.info.merchantNo,
                    "operatorId": $scope.info.userId,
                    "subject": "B扫C标题",
                    "terminalId": $scope.terminalId,
                    "totalAmount": $stateParams.price
                }, {}, {}, null, function(data) {
                    if (data.result == 000000) {
                        //跳转成功页面
                        $state.go('tab.collection_success', {
                            "totalAmount": $stateParams.price
                        });
                    } else if (data.result == 300002 || data.result == 300006) $state.go('tab.pay_error');
                    else{
                        myTimeNew = new Date().getTime();
                        $scope.gotoCycle(data.data.merchantCode)
                    }
                })
            }, {})

            $scope.num = 0; //轮询请求次数
            $scope.gotoCycle = function(_code) {
                if (!$scope.chackBoo) return;
                if(new Date().getTime() - nowTimer > 30000) $scope.backBtnShow = true; 
                $scope.num++;
                Common.post('merchantAPI/order/barPayQuery', {
                    "barCode": $stateParams.barCode,
                    "merchantCode": _code,
                    "terminalId": $scope.terminalId
                }, function(data) {}, {}, null, function(data) {
                    if (data.result == '000000') {
                        var state = data.data.orderStatue;
                        if (state == 00) {
                            //跳转成功页面
                            $state.go('tab.collection_success', {
                                "totalAmount": $stateParams.price
                            });
                        } else if (state == 03 || state == 05) {
                            $state.go('tab.pay_error');
                        } else {
                            if ($scope.num < 30) {
                                $timeout(function() {
                                    $scope.gotoCycle(_code);
                                }, 2000)
                            } else {
                                $state.go('tab.pay_error');
                            }
                        }
                    }else if(data.result == '200092'){
                        $state.go('tab.pay_error');
                    } else {
                        if ($scope.num < 30 && new Date().getTime() - myTimeNew <= 120000) {
                            $timeout(function() {
                                $scope.gotoCycle(_code);
                            }, 2000)
                        }else if(new Date().getTime() - myTimeNew >= 120000){
                            Common.showAlert('超时提醒','请求超时,请以账单消息为准！',function(){
                                $state.go('tab.counter_pay');
                            },'退出');
                        } else {
                            $state.go('tab.pay_error');
                        }
                    }

                })
            }
        });
    })
    .controller('pay_errorCtrl', function($scope, $state) {
        $scope.goBack = function() {
            $state.go('tab.counter_pay');
        }
        $scope.$on('$ionicView.beforeEnter', function() {

        });
    })
    .controller('pay_successCtrl1', function($scope, $state, $stateParams) {
        $scope.goBack = function() {
            $state.go('tab.counter_pay');
        }

        $scope.$on('$ionicView.beforeEnter', function() {
            $scope.totalAmount = $stateParams.totalAmount;
            $scope.num = 0; //轮询请求次数
        });
    });
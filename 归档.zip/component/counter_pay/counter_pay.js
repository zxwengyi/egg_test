var counter_pay_myConfig = function ($stateProvider) {
  $stateProvider
    .state('tab.counter_pay', {
      url: '/counter_pay',
      views: {
        'tab-cashier': {
          templateUrl: 'component/counter_pay/counter_pay_2.html',
          controller: 'counter_payCtrl'
        }
      }
    });
};
myapp.config(counter_pay_myConfig);

angular.module('starter.counter_pay', [])
  .controller('counter_payCtrl', function ($scope, Common, $state, $rootScope, $interval, $timeout, $filter) {
    var onLinePay = Common.getCache('Token').onLinePay;

    //  $rootScope.hideHeader = true;
    $scope.showCode = function () {
      if (!onLinePay) {
        $return.showAlert('', "收银暂时不能使用，原因：您拒绝了平台返豆率调整策略，如需帮助请联系客服人员", function () {
          $state.go('tab.counter_pay')
        });
      } else {
        if (!Common.isnetwork()) {
          $return.showAlert('温馨提示', "网络连接错误，请检查网络连接");
          return
        }
        var myPrice = $scope.total.showSum;
        var myPrice2 = $scope.dismiss.showSum;
        if (parseFloat(myPrice2) > parseFloat(myPrice)) {
          Common.showAlert("", "免返豆金额不能大于消费总金额", function () {
            $scope.dismiss.sum = '';
            $scope.dismiss.showSum = '';
          });
          return;
        }
        $state.go('tab.pay_code', {
          cash: $scope.formatPrice(myPrice),
          noBenefitPrice: $scope.formatPrice(myPrice2)
        });
      }
    };
    /*
        扫码支付
        1：确认是否输入金额；
           1.1：没输入金额，提示输入金额；
        2：确认输入金额
        3：调用native扫码功能
        4：等待扫码结果
        5：下单
           成功，显示消费信息
           等待，轮询查询结果
           失败，显示扫码信息失败
    */
    $scope.gotoScan = function () {
      //1：确认是否输入金额；
      //  1.1：没输入金额，提示输入金额；
      var price = $scope.total.showSum;
      if (!price || !parseFloat(price)) {
        Common.showAlert('', '扫一扫收款金额不能为空');
      } else {
        //    	var data = {
        //	               "scanStr" : '123123123'
        //	       }
        //    	$scope.gotoPaly(data)
        //3：调用native扫码功能
        // $scope.gotoPaly({
        //   scanStr: '135064605769104989'
        // });
        Common.checkscan(function (data) {
          console.log(data);
          // 下单
          $scope.gotoPaly(data);
        });
      }
    };
    //核销
      $scope.gotoExchangeRedeem = function(){
          var merchantNo = Common.getCache('Token').merchantNo;
          var operatorId = Common.getCache('Token').operatorId;
          var username = Common.getCache('Token').name;
          var token = Common.getCache('Token').token;
          // var rsa = Common.getCache('RSa');
          console.log(merchantNo,operatorId,username,token);
          Common.exchangeRedeem(merchantNo,operatorId,username,token);
      }
    // 下单
    $scope.gotoPaly = function (_data) {
      var data = {
        merchantNo: Common.getCache('Token').merchantNo, // 商户号
        merchantName: Common.getCache('Token').merchantShortName, // 商户名称
        barCode: _data.scanStr, // 条码
        totalAmount: $scope.formatPrice($scope.total.showSum), // 订单总金额
        subject: 'B扫C支付', // 订单标题
        desc: 'B端扫wx付款码支付' // 订单描述
      };
      console.log($filter('date')(new Date(), 'yyyy-MM-dd hh:mm:ss'));
      // 5.下单
      Common.post('merchantAPI/gather/barcodePay', data, function (result) {
        /*
          orderSn: 订单编号
          totalAmount: 订单总金额
          beanAmount: 乐豆金额
          cashAmount: 现金金额
        */
        // TODO
        // 我的分润 支付用户 暂时无法取到，继续跟进
        // Common.setCache('palyMessage', result.data);
        if (result.data.status === '00') {
          // 5.1 成功 显示成功页面信息
          // result.data.payTime = $filter('date')(new Date(), 'yyyy-MM-dd hh:mm:ss');
          Common.setCache('palyMessage', result.data);
          $state.go('tab.scan_success'); // component/pay_success
        } else if (result.data.status === '02') {
          // 5.2 等待 轮询
          Common.setCache('palyMessage_newData', result.data);
          $scope.startInter(result.data.orderSn);
        } else {
          // 5.3 下单失败
          $state.go('tab.pay_error');
        }
      }, function (err) {
        console.log(err);
      }, 0);
    };
    // 轮询查询支付结果
    // $scope.payNum = 0;
    $scope.startInter = function (_orderSn) {
      // 等待轮询
      Common.showLoading();
      Common.get('merchantAPI/gather/queryPayResult', {
        orderSn: _orderSn
      }, function (data) {
        // 下单成功
        if (data.data.orderStatus === '00') {
          var newData = Common.getCache('palyMessage_newData');
          newData.paymentTime = data.data.paymentTime;
          // newData.payTime = $filter('date')(data.data.payTime, 'yyyy-MM-dd hh:mm:ss');
          Common.setCache('palyMessage', newData);
          Common.hideLoading();
          $state.go('tab.scan_success');
        } else if (data.data.orderStatus === '02') {
          // 等待
          $scope.payNum++;
          if ($scope.payNum > 10) {
            // 超过10次 显示错误
            Common.hideLoading();
            $state.go('tab.pay_error');
          } else {
            // 轮询查询结果
            $timeout(function () {
              $scope.startInter(_orderSn);
            }, 1500);
          }

        } else {
          // 查询失败
          Common.hideLoading();
          $state.go('tab.pay_error');
        }
      });
    };

    $scope.formatPrice = function (myPrice) {
      var myPriceNum = myPrice;
      switch (myPrice.indexOf('.')) {
        case -1:
          myPriceNum = myPrice + '.00';
          break;
        case myPrice.length - 1:
          myPriceNum = myPrice + '00';
          break;
        case myPrice.length - 2:
          myPriceNum = myPrice + '0';
          break;
      }
      if (myPriceNum == '0.00' || myPriceNum == '.00') myPriceNum = "";
      return myPriceNum;
    }
    $scope.$watch('total.sum', function (news, old) {
      // $scope.isHasTrue= news > 0 ? news.indexOf('.') == news.length -1 ? false: true : false;
      // $scope.isHasTrue= news > 0 ? true : false;
      // if(/^\./.test(news)){
      //     $scope.isHasTrue= false;
      // }else {
      //     $scope.isHasTrue= true;
      // }
      // if(news.indexOf('.')!=-1){
      //     var mat = news.match(/\d+.(\d(\d)?)?/);
      //     if(!mat[1]){
      //         $scope.total.showSum = news+'00'
      //         console.log($scope.total.showSum)
      //     }else if(!mat[2]){
      //         $scope.total.showSum = news+'0'
      //     }
      // }  192.168.1.136：8082
      // if(news.indexOf('0.00')!=-1){
      //     $scope.total.sum=""
      // }
    })

    // $scope.gotoScan = function(){
    //   if(!$scope.isHasTrue) return;
    //   // var myArr = '780621019738972999|a2aceff999a945459589a26bbef342c8'.split('|');
    //   // $state.go("tab.paying",{"barCode":myArr[0],"userid":myArr[1],"price":$scope.total.showSum})
    //   var myPrice = $scope.total.showSum;
    //   var myPriceNum = myPrice;
    //   switch(myPrice.indexOf('.')){
    //     case -1:
    //       myPriceNum = myPrice + '.00';
    //       break;
    //     case myPrice.length-1:
    //       myPriceNum = myPrice + '00';
    //       break;
    //     case myPrice.length-2:
    //       myPriceNum = myPrice + '0';
    //       break;
    //   }
    //   Common.checkscan(function(data){
    //     var myArr = data.scanStr.split('|');
    //     if(myArr.length != 2) return;
    //     $state.go("tab.paying",{barCode:myArr[0],userid:myArr[1],price:myPriceNum})
    //
    //   })
    // }
    $scope.$watch('dismiss.sum', function (news, old) {
      if (parseFloat(news) > parseFloat($scope.total.sum)) {
        $scope.dismiss.sum = '';
        $scope.dismiss.showSum = '';
        Common.showAlert("", "免返豆金额不能大于消费总金额");
      }
    });
    $scope.setTotal = function (sum) {
      if (sum == "delete") {
        $scope[$scope.currentType].sum = "";
      } else if (sum == '-') {
        if ($scope[$scope.currentType].sum.length < 1) return;
        if ($scope[$scope.currentType].sum.match(/\d+\.$/)) {
          $scope[$scope.currentType].sum = $scope[$scope.currentType].sum.substr(0, $scope[$scope.currentType].sum.length - 1)
        }
        $scope[$scope.currentType].sum = $scope[$scope.currentType].sum.substr(0, $scope[$scope.currentType].sum.length - 1)
      } else if (sum == ".") {
        if ($scope[$scope.currentType].sum.length > 9) return;
        if ($scope[$scope.currentType].sum.length < 1) {
          $scope[$scope.currentType].sum = ""
        } else if (/\./.test($scope[$scope.currentType].sum)) {
          return false;
        } else {
          $scope[$scope.currentType].sum += sum
        }
      } else {
        if ($scope[$scope.currentType].sum.length >= 7) return;
        $scope[$scope.currentType].sum += sum
      }
      $scope[$scope.currentType].isHasDot = $scope[$scope.currentType].sum == "" || $scope[$scope.currentType].sum.indexOf('.') != -1;
      $scope[$scope.currentType].sum = $scope[$scope.currentType].sum.replace(/^0+/, "0").replace(/^(0([^.]))/, "$2").replace(/\.(\d{0,2})\d?$/, '.$1');
      $scope[$scope.currentType].showSum = $scope[$scope.currentType].sum;
    };

    $scope.changeFocus = function (type) {
      if (type === 'dismiss' && $scope.total.showSum.length <= 0) {
        return;
      }
      $scope.currentType = type;
      $scope.foucsShowBoo = false;
      $scope.foucsBreaksPrice = false;
    };
    $scope.currentType = "total";
    $scope.foucsShowBoo = true;

    $scope.$on('$ionicView.beforeLeave', function () {
      $interval.cancel($scope.focus);
      Common.hideLoading();
    });

    $scope.$on('$ionicView.beforeEnter', function () {
      // $scope.canScan = $rootScope.canUseScan;
      $scope.canScan = Common.getCache('canUseScan');
      $scope.payNum = 0;     //2018.04.08
      var nativeBroadcastMsg = null;
      $scope.noBenefitStyle = undefined;
      window.broadcastMsgNum = function (obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
        if (typeof (obj) == "object") {
          nativeBroadcastMsg = obj.data;
        } else {
          nativeBroadcastMsg = angular.fromJson(obj).data;
        }
        $scope.$emit('msgNum', nativeBroadcastMsg);
      };
      //收银金额
      $scope.total = {
        sum: '',
        showSum: '',
        isHasDot: false
      };
      //免返豆金额
      $scope.dismiss = {
        sum: '',
        showSum: '',
        isHasDot: false
      };
      $scope.isHasTrue = false;
      var item = Common.getCache(Common.getCache('Token').operatorId + "_pay_success_first_message_info")
      $scope.item = item ? item : false;
      $scope.focus = $interval(function () {
        if ($scope.currentType === "total") {
          $scope.foucsShowBoo = !$scope.foucsShowBoo;
        } else {
          $scope.foucsBreaksPrice = !$scope.foucsBreaksPrice;
        }
      }, 800);
      //免返豆高度设置
      var setHight = function () {
        $scope.noBenefit = Common.getCache('Token').noBenefit;
        if ($scope.noBenefit === 0) {
          $scope.noBenefitStyle = {
            "height": "3.6rem"
          }
        } else {
          $scope.noBenefitStyle = undefined;
        }
      }
      setHight()
      $scope.$on("jpush", function () {
        setHight()
      })

      /*        Common.get('merchantAPI/merchant/basics', {}, function (data) {
                  var newData = Common.getCache('Token');
                  newData.cashierBoo = data.data.cashierBoo;
                  newData.staffmanagementBoo = data.data.staffmanagementBoo;
                  newData.onLinePay = data.data.onLinePay;
                  newData.saleRate = data.data.saleRate;
                  newData.maxSaleRate = data.data.maxSaleRate;
                  newData.minSaleRate = data.data.minSaleRate;
                  newData.noBenefit = data.data.noBenefit;
                  Common.setCache('Token', newData);
                  $scope.noBenefit = data.data.noBenefit;
                  
                  console.log($scope.noBenefitStyle)
              }, {},0)*/
    });
  });
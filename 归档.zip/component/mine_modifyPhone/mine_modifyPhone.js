var mine_modifyPhone_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_modifyPhone', {
      url: '/mine_modifyPhone',
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_modifyPhone/mine_modifyPhone.html',
          controller: 'mine_modifyPhoneCtrl'
        }
      }
    });
};
myapp.config(mine_modifyPhone_myConfig);

angular.module('starter.mine_modifyPhone', [])
  .controller('mine_modifyPhoneCtrl', function($scope, $http, $rootScope, $timeout, actionSheetItem, $ionicModal, $state, toast, Common, $interval, $stateParams) {
    $scope.phoneCodeOK = false;
    console.log($scope.information.username)
    var regPhone = /^1(3|4|5|7|8)\d{9}$/;
    $scope.seconds = 59;
    $scope.btnText = "获取验证码";
    $scope.isCounting = false;
    var timer;
    $scope.$watch('inputData.phone', function() {
      $scope.$watch('inputData.vCode', function() {
        // if (/^\d{6}$/.test($scope.inputData.vCode) && /^1(3|4|5|7|8)\d{9}$/.test($scope.inputData.phone)) {
        if ($scope.inputData.vCode || $scope.inputData.phone) {
          $scope.phoneCodeOK = true;
        } else {
          $scope.phoneCodeOK = false;
        }
      })
    })

    //IOS计时缓慢问题
    var hiddenTime, visibleTime;
    document.addEventListener("pause", function() {
      if (!$scope.isCounting) return;
      hiddenTime = new Date().getTime();
      visibleTime = $scope.seconds;
    }, false);
    document.addEventListener("resume", function() {
      if (!$scope.isCounting) return;
      var timemax = visibleTime - ((new Date().getTime() - hiddenTime) / 1000 | 0)
      if (timemax > 0) {
        $scope.seconds = timemax;
      } else {
        $interval.cancel(timer);
        $scope.seconds = 59;
        $scope.isCounting = false;
        $scope.btnText = "重新发送";
      }
    }, false);

    //获取手机验证码
    $scope.getCode = function() {
      if ($scope.btnText == "获取验证码" || $scope.btnText == "重新发送") {
        if (regPhone.test($scope.inputData.phone)) {
          $scope.isCounting = true;
          $scope.count();
          //向后台发送请求
          // Common.get("merchantAPI/user/forgotPwdSendSmsCode", {
          //   "mobile": $scope.inputData.phone,
          //   "isAdmin": $scope.choosedIndex == 1 ? "1" : "0"
          // }, function(data) {
          //   console.log('发送验证码成功...')
          // }, {})
           Common.sendMessage($scope.inputData.phone, "1", function() {})
        } else {
          toast.show("请输入正确的手机号")
        }
      }
    }

    //短信倒计时
    $scope.count = function() {
      $scope.btnText = "59S";
      timer = $interval(function() {
        $scope.seconds--;
        if ($scope.seconds != 0) {
          $scope.seconds = $scope.seconds >= 10 ? $scope.seconds : "0" + $scope.seconds;
          $scope.btnText = $scope.seconds + "S";
        } else {
          $interval.cancel(timer);
          $scope.seconds = 59;
          $scope.isCounting = false;
          $scope.btnText = "重新发送";
        }
      }, 1000)
    }

    //完成手机验证，【下一步】
    $scope.sure = function() {
      if (!regPhone.test($scope.inputData.phone)) {
        toast.show("请输入正确格式的手机号")
        return;
      }
      if (!(/^\d{6}$/.test($scope.inputData.vCode))) {
        toast.show("请输入正确格式的验证码")
        return;
      }
      if (!$scope.canClick) return;
      $scope.canClick = false;
      var loop = $timeout(function() {
        $scope.canClick = true;
        $timeout.cancel(loop);
      }, 2000);
      Common.post("merchantAPI/user/mobilePhone", { ///////TODO：换成新接口
         "oldMobilePhone": $scope.information.username,
         "newMobilePhone": $scope.inputData.phone,
         "newverificationCode": $scope.inputData.vCode

      }, function(res) {
        toast.show("修改成功,请使用新帐号登录！")
        $timeout(function() {
          $state.go("tab.mine_toLogin");
          Common.logout();
        }, 200)
      }, {})
    }

    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.canClick = true; //防止用户双击
      $scope.inputData = {
        phone: '',
        vCode: ''
      }
    });
  });
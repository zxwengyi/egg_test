var pay_code_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.pay_code', {
        url: '/pay_code/:cash/:noBenefitPrice',
        views: {
            'tab-cashier': {
                templateUrl: 'component/pay_code/pay_code.html',
                controller: 'pay_codeCtrl'
            }
        }
    });
};
myapp.config(pay_code_myConfig);

angular.module('starter.pay_code',[])
.controller('pay_codeCtrl', function($scope,$stateParams,$state,debugLocalCommon,toast,cordovaPlug,Common,$timeout,$rootScope) {
    // $rootScope.statusBarHeight =0.44
    $scope.imageUrl="";
    $scope.saveImage=function () {
        if($scope.imageUrl){
            cordovaPlug.CommonPL(function (data) {
            	toast.show('二维码已经保存成功')
            },"saveQRImage",[$scope.imageUrl])
        }
    }
    function getCode(url){
        cordovaPlug.CommonPL(function(data){
            if(data.status == 1){
                $scope.imageUrl = data.data.QRCodeImage;
                $scope.$apply();
                window.broadcastMsgNum = function(obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
                    var data  = (typeof(obj) == "object") ? obj.data : angular.fromJson(obj).data;
                    $scope.$emit('msgNum',data);
                    var item = data.item
                    if(item.tranType == 1100 && data.type=="payment_app"){
                    	if(item.oneSelf === '00'){
	                        Common.setCache("pay_success_first_message_info",item,100000000000)
	                        Common.setCache(Common.getCache('Token').operatorId+"_pay_success_first_message_info",item,100000000000)
	                        $state.go('tab.pay_success')
                    	}
                    }
                };
            }else{
                toast.show("插件调用失败！");
            }
        }, "generateCode", [url])
    }
    $scope.$on('$ionicView.beforeEnter', function() {
        $scope.imageUrl = "";
        $scope.isHasCash = false;
        if($stateParams.cash){
            $scope.cash = $stateParams.cash
            $scope.isHasCash = true;
        }
        Common.get('merchantAPI/order/generateCode', {}, function (data) {
            var _b = '';
            if ($stateParams.noBenefitPrice) {
                _b = '&noBenefitAmount=' + $stateParams.noBenefitPrice;
            }
            var generateCode = $scope.cash ? (data.data.generateCode + '&cash=' + $stateParams.cash + _b) : data.data.generateCode;
            console.log(generateCode)
            getCode(generateCode)
        })
    });
    $scope.$on('$ionicView.beforeLeave', function() {
        // window.broadcastMsgNum = null
        $scope.imageUrl="";
    })
});

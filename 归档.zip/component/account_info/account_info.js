var account_info_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.account_info', {
        url: '/account_info',
        views: {
            'tab-financial': {
                templateUrl: 'component/account_info/account_info.html',
                controller: 'account_infoCtrl'
            }
        }
    });
};
myapp.config(account_info_myConfig);

angular.module('starter.account_info',[])
.controller('account_infoCtrl', function($scope,Common,debugLocalCommon) {
    $scope.item={}
    $scope.$on('$ionicView.beforeEnter', function() {
        $scope.item = Common.getCache('account_info_id_item')
        if($scope.item){
            debugLocalCommon.getUserInfo($scope.item.userId,$scope.item.operatorId,function (data) {
                angular.extend($scope.item,(data.data.operatorList?data.data.operatorList[0]:{}))
                angular.extend($scope.item,(data.data.userList?data.data.userList[0]:{}))
            })
        }
    });
});

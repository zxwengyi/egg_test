var tab_fans_myConfig = function($stateProvider) {
    $stateProvider
        .state('tab.tab_fans', {
            url: '/tab_fans',
            views: {
                'tab-fans': {
                    templateUrl: 'component/tab_fans/tab_fans.html',
                    controller: 'tab_fansCtrl'
                }
            }
        });
};
myapp.config(tab_fans_myConfig);

angular.module('starter.tab_fans', [])
    .controller('tab_fansCtrl', function($scope, Common, $ionicScrollDelegate) {

        $scope.$on('$ionicView.beforeEnter', function() {
            var nativeBroadcastMsg = null;
            // $ionicScrollDelegate.scrollTop();
            window.broadcastMsgNum = function(obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
                if (typeof(obj) == "object") {
                    nativeBroadcastMsg = obj.data;
                } else {
                    nativeBroadcastMsg = angular.fromJson(obj).data;
                }
                $scope.$emit('msgNum',nativeBroadcastMsg);
            };
            $scope.selectSettlement = function(num) {
                $ionicScrollDelegate.scrollTop();
                $scope.noMoreMsg = true;
                $scope.navNum = num;
            };
            
            $scope.navNum = 0;
            $scope.noMoreMsg = false;

            var CoCurPage = 1;
            var AcCurPage = 1;
            $scope.coLists = [];
            $scope.acLists = [];

            $scope.loadMoreMsg = function() {
                if ($scope.navNum === 0) {
                    Common.post('merchantAPI/merchant/invite/inviteOrFollow', {
                        status: 1,
                        curPage: CoCurPage,
                        pageSize: 10
                    },function(res) {
                        list = res.data.list || [];
                        if (res.data.list.length > 0) {
                            $scope.coLists = $scope.coLists.concat(list);
                        }

                        if (list.length < 10) {
                            $scope.noMoreMsg = false;
                        } else {
                            $scope.noMoreMsg = true;
                        }
                        CoCurPage++;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    },function(){
                        $scope.noMoreMsg = false;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    });
                } else {
                    Common.post('merchantAPI/merchant/invite/inviteOrFollow', {
                        status: 0,
                        curPage: AcCurPage,
                        pageSize: 10
                    },function(res) {
                        list = res.data.list || [];
                        if (res.data.list.length > 0) {
                            $scope.acLists = $scope.acLists.concat(list);
                        }

                        if (list.length < 10) {
                            $scope.noMoreMsg = false;
                        } else {
                            $scope.noMoreMsg = true;
                        }
                        AcCurPage++;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    },function(){
                        $scope.noMoreMsg = false;
                        $scope.$broadcast('scroll.infiniteScrollComplete');
                    });
                }
            };

            $scope.loadMoreMsg();

            $scope.loadMoreAcFans = function() {

            };
        });
    });

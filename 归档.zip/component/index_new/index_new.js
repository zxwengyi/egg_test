var index_new_myConfig = function ($stateProvider) {
	$stateProvider
		.state('tab.index_new', {
			url: '/index_new',
			views: {
				'tab-index': {
					templateUrl: 'component/index_new/index_new.html',
					controller: 'index_newCtrl'
				}
			}
		});
};
myapp.config(index_new_myConfig);

angular.module('starter.index_new', [])
	.controller('index_newCtrl', function ($scope, $rootScope, $location, Common, $ionicSlideBoxDelegate, $state, $ionicModal, $sce, $timeout, cordovaPlug, toast) {	
		$scope.isTips = false
		var curTime = new Date().getTime() // 当前时间戳
		var overTime = new Date('2020-01-01').getTime() // 截止时间戳
		if (curTime < overTime) {
			$scope.isDelay = true
		} else {
			$scope.isDelay = false
		}
		if ((localStorage.showTips == undefined && $scope.isDelay) || (Number(localStorage.showTips) && $scope.isDelay)) {
			$scope.showTips = true
		} else {	
			$scope.showTips = false
		}
		// 是否不再提示
		$scope.selectTips = function () {
			$scope.isTips = !$scope.isTips
			if ($scope.isTips) {
				localStorage.showTips = 0
			} else {
				localStorage.showTips = 1
			}
		}
		// 关闭提示
		$scope.closeTips = function () {
			$scope.showTips = false
		}
		// 查看提示
		$scope.goDetails = function () {
			$state.go("tab.step")
		}
		if (Common.getCache('Token')) {
		var sysStatus = Common.getCache('Token').sysServiceExpire;  
		}
		if (sysStatus === 0) {
			$rootScope.mealShowTip = false;
		} else if (sysStatus === 1) {
			$rootScope.mealShowTip = true;
			Common.logout()
		} else {
			$rootScope.mealShowTip = false; 
		}
		//mock数据
		console.log('1111111', window.location.hash)
		$scope.bannerImg = [{
			"imageUrl": "./img/index_new/banner2.jpg",
			"title": "测试一下"
		}, {
			"imageUrl": "./img/index_new/banner1.png",
			"title": "测试一下"
		}]
		$scope.slideNum = 1;
		$scope.openNum = 0;
		$scope.discountRate = 8.5;
		Common.get('merchantAPI/merchant/info', {}, function (data) {
			$scope.categoryID = data.data.categoryId;
			Common.post('/merchantAPI/queryMerchantCategory/maxDiscountRate/' + $scope.categoryID, {
				categoryId: $scope.categoryID
			}, function (res) {
				Common.setCache('maxDiscountRate', res.data)
			});
		})
		var user = Common.getCache('Token')
		if (Common.getCache('Token') != null && $rootScope.role == 1 && !Common.getCache("missMessage")) {
			Common.get('merchantAPI/merchant/info', {}, function (data) {
				if (data.data == null || data.data == undefined) return;
				if (!data.data.merchantName || !data.data.merchantShortName || !data.data.officeTel ||
					!data.data.businessAddress || !data.data.businessTime || !data.data.avgPrice || !data.data.province) {
					Common.showConfirm('', '恭喜您成为给乐特约商户，为了给你带来更多客户量，请前往"我的-商家基本信息"完善信息，这样才能在平台显示哦', function () {
						$state.go('tab.my_information')
					}, {}, "去完善", '取消');
					Common.setCache('missMessage', 1, 7 * 24 * 3600000);
				}
			}, {}, 1)
		}
		
		$ionicModal.fromTemplateUrl('my-modal.html', {
			scope: $scope,
			animation: 'slide-in-up'
		}).then(function (modal) {
			$scope.modal = modal;
		});

		$scope.openModal = function () {
			$scope.modal.show();
		}
		$scope.closeModal = function () {
			$scope.modal.hide();
		}
		$scope.btnNoAccept = function () {
			$scope.isMessage = false;
			Common.post('/merchantAPI/rejectChangeDiscountRate', {
				merchantNo: user.merchantNo
			}, function (res) {
				toast.show('您的收银和店铺展示将受限，如需要改变，请联系客服人员')
			}, {}, 1)
		}
		$scope.btnAccept = function () {
			$scope.isMessage = false;
			var discountRate = $scope.discountRate * 10
			Common.post('/merchantAPI/openDiscountRate', {
				discountRate: discountRate,
				merchantNo: user.merchantNo
			}, function (res) {
				toast.show('您已接收调整，感谢您的支持，APP可正常使用 ')
				Common.get('merchantAPI/merchant/basics', {}, function (data) {
					Common.setCache('isFlag', 1)
					var newData = Common.getCache('Token');
					newData.cashierBoo = data.data.cashierBoo;
					newData.staffmanagementBoo = data.data.staffmanagementBoo;
					newData.merchantShortName = data.data.merchantShortName;
					newData.onLinePay = data.data.onLinePay;
					newData.saleRate = data.data.saleRate;
					newData.discountRate = data.data.discountRate;
					newData.maxSaleRate = data.data.maxSaleRate;
					newData.minSaleRate = data.data.minSaleRate;
					newData.noBenefit = data.data.noBenefit;
					if (data.data.role && newData.role != 5 && newData.role != 6) newData.role = data.data.role;
					Common.setCache('Token', newData);
					$rootScope.role = newData.role;
					$rootScope.onLinePay = newData.onLinePay;
					$rootScope.saleRate = newData.saleRate;
					$rootScope.discountRate = newData.discountRate
					$rootScope.information = Common.getCache('Token');
					Common.setCache('onLinePay', data.data.onLinePay, 8640000);
				}, {})
			}, {}, 1)

		}
		//查看广告位
		$scope.bannerClick = function (_data) {
			if (_data.url == null) return;
			$scope.myUrl = $sce.trustAsResourceUrl(_data.url);
			$scope.title = _data.title;
			$scope.openModal();
		}
		//查看账单
		$scope.gotoEarnings = function (_data, _nav) {
			Common.clearCache('statisticalDate')
			$state.go('tab.tab_bill', {
				random: new Date().getTime(),
				date: _data,
				navNum: _nav
			})
		}

		//进入本店评价
		$scope.gotoAllScore = function () {
			if ($rootScope.role == 4) {
				Common.showAlert('离职提醒', '您目前已经离职，无法查看更多信息！');
				return;
			}
			$state.go("tab.index_comVereview", {
				'score': $scope.indexData.merchantScore,
				'type': '0'
			});
		}
		//进入员工评价
		$scope.gotoScore = function () {
			if ($rootScope.role == 4) {
				Common.showAlert('离职提醒', '您目前已经离职，无法查看更多信息！');
				return;
			}
			$state.go('tab.index_employees');
		}
		//显示tip描述
		$scope.showTip = function () {
			$rootScope.tabShowTip = true;
		}

		$scope.getDate1 = function () {
			$timeout(function () {
				Common.get('merchantAPI/homePage/revenue', {
					queryType: 6
				}, function (data) {
					$scope.nearlyEarnings = data.data;
				})
				Common.get('merchantAPI/homePage/revenue', {
					queryType: 1
				}, function (data) {
					$scope.yesterdayEarnings = data.data;
				})
			}, 1500)
		}
		$scope.getDate1();

		// var myInfor = Common.getCache('Token');
		//获取权限角色

		//console.log($rootScope.information);

		$scope.slideChanged = function (index) {
			$scope.slideNum1 = index % 2;
		};
		$scope.$on('$ionicView.beforeEnter', function () {
			$scope.isMessage = false;
			Common.clearCache('bill_details');
			Common.clearCache('bill_details_cancel');
			$rootScope.information = Common.getCache('Token');
			var merchantNo = $rootScope.information.merchantNo
			var role = $rootScope.information.role
			if (role === '1') {
				Common.post('merchantAPI/queryMerchantDisacceptLogByMerchantNo/' + merchantNo, {}, function (res) {
					$scope.isMessage = res.data.flag === '0' ? false : true;
				})
			}

			$timeout(function () {
				$rootScope.hideHeader = false;
			}, 10)
			if (Common.getCache('getDeviceIdAndClientId') == null || $scope.openNum == 0) $timeout(function () {
				$scope.getDate()
			}, 1500);
			else $scope.getDate()
			$scope.openNum = 1;
			$scope.slideNum1 = 0;
			$scope.messageObj = null;

			//极光推送红包入口判断
			$timeout(function () {
				//每次进首页获取红包列表
				// $scope.bonusArr = [{},{},{}];
				// $scope.bonusShow = true;
				cordovaPlug.CommonPL(function (res) {
					var resList = res.data.list || [];
					var delArr = [];
					$scope.bonusArr = [];
					var now = new Date().getTime();
					if (resList.length > 0) {
						resList.forEach(function (ele) {
							if (now > ele.effectiveExpireTime) {
								delArr.push(ele.id);
							} else {
								$scope.bonusArr.push(ele);
							}
						});

						if ($scope.bonusArr.length > 0) {
							$scope.bonusShow = true;
						}
						//删除过期红包
						if (delArr.length > 0) {
							cordovaPlug.CommonPL(function (res) {

							}, 'deleteMessageByBatch', ['redenvelope_app', delArr.join(',')]);
						}

					}

				}, 'getMessageList', ['redenvelope_app', 1, 10]);
			}, 500);

			//红包模态框
			$scope.moddle_show = false;
			$scope.getBonus = function (type, id, effectiveExpireTime) {
				console.log(type);
				//$scope.bonusArr.splice(0, 1);
				if (new Date().getTime() > effectiveExpireTime) {
					toast.show('该红包已经过期');
					$scope.bonusArr.splice(0, 1);
					if ($scope.bonusArr.length === 0) {
						$scope.bonusShow = false;
					}
					cordovaPlug.CommonPL(function () {

					}, 'deleteMessageByBatch', ['redenvelope_app', id.toString()]);
				} else {
					Common.get('merchantAPI/redenvelope/distribute', {
						accountType: type
					}, function (res) {
						$scope.bonus = res.data.operateAmount;
						$scope.bonusArr.splice(0, 1);
						if ($scope.bonusArr.length == 0) {
							console.log($scope.bonusArr.length);
							$scope.bonusShow = false;
						}
						cordovaPlug.CommonPL(function () {

						}, 'deleteMessageByBatch', ['redenvelope_app', id.toString()]);

						$scope.moddle_show = true;

					});
				}
			};

			$scope.closeBonus = function () {
				$scope.moddle_show = false;
				//$scope.bonusShow = false;
			};

		});
		//获取数据
		$scope.getDate = function () {
			Common.post('merchantAPI/merchant/invite/getHomePageCommentFans', {}, function (data) {
				console.log(data)
				$scope.indexData = data.data;
				$scope.setWidth();
				$scope.showMess()
			}, {}, 1)
			Common.get('merchantAPI/homePage/revenue', {
				queryType: 0
			}, function (data) {
				$scope.nowEarnings = data.data;

			})

		}
		//绘制星星比例
		$scope.setWidth = function () {
			$scope.indexData.merchantScoreWidth = 1.32 - ((5 - $scope.indexData.merchantScore) / 5 * 1.32) + "rem";
			$scope.indexData.operatorScoreWidth = 1.32 - ((5 - $scope.indexData.operatorScore) / 5 * 1.32) + "rem";
		}

		//解析消息体
		$scope.showMess = function () {
			if ($scope.indexData.receiveMoneyMsg == '' || $scope.indexData.receiveMoneyMsg == null) return;
			var jsonDate = JSON.parse($scope.indexData.receiveMoneyMsg).systemBody
			$scope.messageObj = jsonDate.tranBody;
			$scope.messageObj.tranType = jsonDate.tranType;
			$scope.titleMsg = $scope.messageObj.oneSelf == '00' && '我的收款' ||
				$scope.messageObj.operatorName != '' && {
					'1': '商家',
					'2': '店长',
					'3': '店员'
				} [$scope.messageObj.operatorRoleId] + '：「' + $scope.messageObj.operatorName + '」收款' ||
				($scope.messageObj.tranType == '1000' || $scope.messageObj.tranType == '4100') && 'POS收款' || '微信收款';
			console.log($scope.titleMsg)
		}
		//进入收款消息
		$scope.setMessageHasRead = function () {
			Common.setCache('msg_pay', $scope.messageObj);
			$state.go('tab.msg_pay');
		};
		//接收jpush
		window.broadcastMsgNum = function (obj) {
			$scope.getDate()
		}
		$scope.slideChange = function (num) {
			$scope.slideNum = num;
		}


		// $scope.currentPosition = {
		// 	// 'longitude': 117.33,
		// 	// 'latitude': 27.55
		// 	"latitude": "22.543544",
		// 	"longitude": "113.959062",
		// };
		// Common.setCache('currentPosition', 	$scope.currentPosition)
		Common.checkLocation(function (data) {
			Common.setCache('currentPosition', data)
			// if (bak) bak()
		});
		//首页banner广告位
		//实时刷新的数据
		//var myCacheTime = new Date(new Date().format(1)).getTime() - new Date().getTime();
		/*$scope.getBanner = function(){
			Common.get("merchantAPI/ad/banner", {}, function(data) {
					$scope.bannerImg = data.data;
					Common.setCache("bannerImg", data.data, myCacheTime)
					$ionicSlideBoxDelegate.$getByHandle('my-handle').update();
					$ionicSlideBoxDelegate.$getByHandle('my-handle').loop(true);
				}, function() {})
		}
		if (Common.getCache('bannerImg') == null) {
			if(Common.getCache('getDeviceIdAndClientId') == null){
				$timeout(function(){
					$scope.getBanner();
				},1500);
			}else{
				$scope.getBanner();
			}
		} else {
			$scope.bannerImg = Common.getCache('bannerImg');
			$ionicSlideBoxDelegate.$getByHandle('my-handle').update();
			$ionicSlideBoxDelegate.$getByHandle('my-handle').loop(true);
		}*/



	});
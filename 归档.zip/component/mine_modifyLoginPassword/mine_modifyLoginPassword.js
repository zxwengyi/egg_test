var mine_modifyLoginPassword_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_modifyLoginPassword', {
      url: '/mine_modifyLoginPassword',
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_modifyLoginPassword/mine_modifyLoginPassword.html',
          controller: 'mine_modifyLoginPasswordCtrl'
        }
      }
    });
};
myapp.config(mine_modifyLoginPassword_myConfig);

angular.module('starter.mine_modifyLoginPassword', [])
  .controller('mine_modifyLoginPasswordCtrl', function($scope, $ionicModal, $state, toast, Common, $timeout) {

    $ionicModal.fromTemplateUrl('my-modal.html', {
      scope: $scope,
      animation: 'slide-in-right'
    }).then(function(modal) {
      $scope.modal = modal;
    });

    // $scope.openModal = function () {
    //   $scope.modal.show();
    // };

    $scope.closeModal = function() {
      $scope.modal.hide();
    };

    $scope.$watch('inputData.prevPwd', function() {
      // if ($scope.inputData.prevPwd.length >= 8) {
      if ($scope.inputData.prevPwd) {
        $scope.filled = true;
      } else {
        $scope.filled = false;
      }
    })

    $scope.$watch('inputData.pwd', function() {
        $scope.$watch('inputData.pwdConfirm', function() {
          // if ($scope.inputData.pwd && $scope.inputData.pwdConfirm && ($scope.inputData.pwd === $scope.inputData.pwdConfirm)) {
          if ($scope.inputData.pwd || $scope.inputData.pwdConfirm) {
            $scope.pwdFilled = true;
          } else {
            $scope.pwdFilled = false;
          }
        })
      })
      //下一步
    $scope.next = function() {
      var reg = /^[^/|\\|\s|\u4e00-\u9fa5]{8,16}$/;
      var prevPwd = $scope.inputData.prevPwd;
      if (prevPwd) {
        Common.checkMd5("GL_SALT_MD5_KEY" + $scope.inputData.prevPwd.toString(), function(data) {
            Common.post('merchantAPI/user/updatePwd', {
              "password": data.MD5
            }, function() {
              $scope.modal.show();
            }, {}, 1);
          })
          // 电脑登录    调用密码修改接口 
          // Common.post('/merchantAPI/user/updatePwd', {
          //   "password": hex_md5("GL_SALT_MD5_KEY" + $scope.inputData.prevPwd.toString())
          // }, function(data) {
          //   $scope.modal.show();
          // }, {})

        // if (reg.test(prevPwd)) {
        //   $scope.modal.show();
        // } else {
        //   $scope.showTips1 = true;
        //   $scope.tips1 = "* 密码格式不正确"
        // }
      } else {
        $scope.showTips1 = true;
        $scope.tips1 = "* 密码不能为空"
      }
    }

    //返回登录
    $scope.return = function() {
      $state.go("tab.my_manager")
    }

    //返回按钮
    $scope.goBack = function() {
      $scope.modal.hide();
    }

    //确认修改
    $scope.confirm = function() {
      var pwd = $scope.inputData.pwd;
      var pwdConfirm = $scope.inputData.pwdConfirm;
      var regPwd = /^[^/|\\|\s|\u4e00-\u9fa5]{8,16}$/;
      var regAllNum = /^\d{8,16}$/;
      var regAllAlphabet = /^[a-zA-Z]{8,16}$/;
      var regAllSymbol = /^^[!@`~#\*^+-.%&<>()',;_"'=?\$\x22]{8,16}$/;
      if (pwd && pwdConfirm) {
        if (pwd === pwdConfirm) {
          if (regPwd.test(pwdConfirm)) {
            if (!regAllNum.test(pwdConfirm) && !regAllAlphabet.test(pwdConfirm) && !regAllSymbol.test(pwdConfirm)) {
              console.log($scope.inputData.prevPwd + "$%$%$" + $scope.inputData.pwdConfirm.toString())

              // 电脑登录    调用密码修改接口  
              // Common.post('merchantAPI/updatePassword', {
              //   "oldPassword":hex_md5("GL_SALT_MD5_KEY"+$scope.inputData.prevPwd.toString()),
              //   "newPassword": hex_md5("GL_SALT_MD5_KEY" + $scope.inputData.pwdConfirm.toString())
              // }, function(data) {
              //   console.log('密码修改成功');
              //   Common.post('merchantAPI/logout/', {}, function(data) {
              //     toast.show("密码修改成功")
              //       //隐藏modal才能跳转
              //     $scope.modal.hide();
              //     $state.go("tab.mine_toLogin");
              //     Common.logout();
              //     console.log("密码修改成功，跳转登录")
              //   }, {})
              // }, {});

              //手机登录
              Common.checkMd5("GL_SALT_MD5_KEY" + $scope.inputData.prevPwd.toString(), function(data) {
                Common.checkMd5("GL_SALT_MD5_KEY" + $scope.inputData.pwdConfirm.toString(), function(_data) {
                  console.log("加密成功")
                  Common.post('merchantAPI/updatePassword', {
                    "oldPassword": data.MD5,
                    "newPassword": _data.MD5
                  }, {}, {}, 1, function(data) {
                    $scope.showTips1 = false;
                    $scope.showTips2 = false;
                    if (data.result == "000000") {
                    	var newUrl = $scope.information.role ==5 || $scope.information.role == 6 ? 'merchantAPI/chainLogout' : 'merchantAPI/logout';
                      Common.post(newUrl, {}, function(data) {
                        //隐藏modal才能跳转
                        toast.show("密码修改成功")
                        $scope.modal.hide();
                        $timeout(function() {
                          Common.logout();
                          $state.go("tab.mine_toLogin");
                        }, 300);
                      }, {})
                    } else {
                      //如果旧密码验证失败                      
                      $scope.modal.hide();
                      toast.show(data.description);
                      $scope.inputData = {
                        prevPwd: '',
                        pwd: '',
                        pwdConfirm: ''
                      }
                    }
                  });
                })
              })
            } else {
              $scope.showTips2 = true;
              $scope.tips2 = "* 密码过于简单,请设置数字与字母密码组合";
              // toast.show('密码过于简单，<br>请设置数字与字母密码组合')
            }
          } else {
            $scope.showTips2 = true;
            $scope.tips2 = "* 密码格式错误,密码为8-16为数字与字符组合";
            // toast.show('密码格式错误')
          }
        } else {
          $scope.showTips2 = true;
          $scope.tips2 = "* 两次密码输入不一致";
          // toast.show('两次密码输入不一致')
        }
      } else {
        $scope.showTips2 = true;
        $scope.tips2 = "* 密码不能为空";
        // toast.show('请输入密码和确认密码')
      }
    }


    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.showTips1 = false;
      $scope.showTips2 = false;
      // $scope.filled = false;
      // $scope.pwdFilled = false;
      $scope.inputData = {
        prevPwd: '',
        pwd: '',
        pwdConfirm: ''
      }
    });
  });
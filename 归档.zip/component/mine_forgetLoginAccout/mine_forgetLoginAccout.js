var mine_forgetLoginAccout_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.mine_forgetLoginAccout', {
            url: '/mine_forgetLoginAccout',
            views: {
                'tab-index': {
                    templateUrl: 'component/mine_forgetLoginAccout/mine_forgetLoginAccout.html',
                    controller: 'mine_forgetLoginAccoutCtrl'
                }
            }
        });
};
myapp.config(mine_forgetLoginAccout_myConfig);

angular.module('starter.mine_forgetLoginAccout', [])
    .controller('mine_forgetLoginAccoutCtrl', function ($scope, toast, $interval, Common, $ionicModal, $timeout, $state) {
        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.inputData = {
                phone: '',
                vCode: '',
                idNo: '',
                pwd: '',
                pwdConfirm: ''
            }
            $scope.selectMerchant = 0
            $scope.operatorId = ''
            $scope.canClick = true; //防止用户双击
        });
        var timer;
        $scope.phoneCodeOK = false;
        $scope.setPasswordOK = false;
        $scope.verifyIdOK = false;
        $scope.selectId = 0
        var regIdCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;


        var regPhone = /^1(3|4|5|7|8)\d{9}$/;
        $scope.seconds = 59;
        $scope.btnText = "发送验证码";

        $scope.submit = false;
        $scope.isCounting = false;
        $ionicModal.fromTemplateUrl('retrievePassword.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalRetrievePassword = modal;
        });
        //获取手机验证码
        $scope.getCode = function () {
            if ($scope.btnText == "发送验证码" || $scope.btnText == "重新发送") {
                if (regPhone.test($scope.inputData.phone)) {


                    //向后台发送请求
                    Common.post("/merchantAPI/user/findAccountNumVerifySmsCode", {
                        "mobile": $scope.inputData.phone,
                    }, function (data) {
                        $scope.isCounting = true;
                        $scope.count();
                        console.log('发送验证码成功...')
                    }, {})
                } else {
                    toast.show("请输入正确的手机号")
                }
            }
        }

        //短信倒计时
        $scope.count = function () {
            $scope.btnText = "59S";
            timer = $interval(function () {
                $scope.seconds--;
                if ($scope.seconds != 0) {
                    $scope.seconds = $scope.seconds >= 10 ? $scope.seconds : "0" + $scope.seconds;
                    $scope.btnText = $scope.seconds + "S";
                } else {
                    $interval.cancel(timer);
                    $scope.seconds = 59;
                    $scope.isCounting = false;
                    $scope.btnText = "重新发送";
                }
            }, 1000)
        }

        $scope.$watch('inputData.phone', function () {
            $scope.$watch('inputData.vCode', function () {
                // if (/^\d{6}$/.test($scope.inputData.vCode) && /^1(3|4|5|7|8)\d{9}$/.test($scope.inputData.phone)) {
                if ($scope.inputData.vCode || $scope.inputData.phone) {
                    $scope.phoneCodeOK = true;
                } else {
                    $scope.phoneCodeOK = false;
                }
            })
        })

        //IOS计时缓慢问题
        var hiddenTime, visibleTime, token;
        document.addEventListener("pause", function () {
            if (!$scope.isCounting) return;
            hiddenTime = new Date().getTime();
            visibleTime = $scope.seconds;
        }, false);
        document.addEventListener("resume", function () {
            if (!$scope.isCounting) return;
            var timemax = visibleTime - ((new Date().getTime() - hiddenTime) / 1000 | 0)
            if (timemax > 0) {
                $scope.seconds = timemax;
            } else {
                $interval.cancel(timer);
                $scope.seconds = 59;
                $scope.isCounting = false;
                $scope.btnText = "重新发送";
            }
        }, false);
        $scope.verifyPhoneComplete = function () {
            if (regPhone.test($scope.inputData.phone)) {
                if (/^\d{6}$/.test($scope.inputData.vCode)) {
                    if (!$scope.canClick) return;
                    $scope.canClick = false; //防止用户双击
                    $scope.doubleClick_timer()
                    Common.post("/merchantAPI/user/getMerchantListForFindAccount", {
                        "mobile": $scope.inputData.phone,
                        "verifyCode": $scope.inputData.vCode
                    }, function (res) {
                        token = res.data.token;
                        $scope.merchantLists = res.data.merchantList;
                        $scope.merchantName = $scope.merchantLists[0].merchantName
                        $scope.merchantNo = $scope.merchantLists[0].merchantNo
                        $scope.modalRetrievePassword.show()
                        // //token

                        // $scope.inputData.vCode = '';
                        // Common.post("merchantAPI/user/getAdminByMobile", {
                        //     "mobilePhone": $scope.inputData.phone,
                        //     "token": token
                        // }, function (res2) {
                        //     if (res2.data.length == 1) { //如果返回数据长度为1，则不弹出商户选择框
                        //         $scope.operatorId = res2.data[0].operatorId; //operaterId需最后一步传给后台
                        //         $scope.modalSetPassword.show();
                        //     } else if (res2.data.length > 1) { //如果返回数据长度 > 1
                        //         $scope.modalRetrievePassword.show();
                        //         $scope.merchantLists = res2.data;
                        //     }
                        // }, {})

                    }, {})
                } else {
                    toast.show("请输入正确格式的验证码")
                }
            } else {
                toast.show("请输入正确格式的手机号")
            }
        }
        //防双击
        $scope.doubleClick_timer = function () {
            var timer = $timeout(function () {
                $scope.canClick = true;
                $timeout.cancel(timer);
            }, 2000);
        }
        $scope.chooseMerchant = function (obj, index) {
            $scope.merchantNo = obj.merchantNo
            $scope.merchantName = obj.merchantName
            $scope.selectMerchant = index
        }
        $scope.sendMsg = function () {
            Common.post("/merchantAPI/user/findAccountSendSms", {
                "mobile": $scope.inputData.phone,
                "merchantNo": $scope.merchantNo,
                "merchantName": $scope.merchantName,
                "token": token
            }, function (res2) {
                toast.show('账号通过短信发送到您的手机上，请注意查收')
                $state.go('tab.mine_toLogin')
                $scope.modalRetrievePassword.hide()

            }, {})



        }
    });
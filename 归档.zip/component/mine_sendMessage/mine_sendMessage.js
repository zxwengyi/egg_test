var mine_sendMessage_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_sendMessage', {
      url: '/mine_sendMessage',
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_sendMessage/mine_sendMessage.html',
          controller: 'mine_sendMessageCtrl'
        }
      }
    });
};
myapp.config(mine_sendMessage_myConfig);

angular.module('starter.mine_sendMessage', [])
  .controller('mine_sendMessageCtrl', function($scope, $interval, $timeout, $state, Common, toast) {
    var timer;
    $scope.seconds = 59;
    $scope.btnText = "获取验证码";

    $scope.submit = false;
    $scope.isCounting = false;

    //下一步
    $scope.next = function() {
      $state.go("tab.mine_addBankCard");
      // if (/^\d{6}$/.test($scope.inputData.vCode)) {
      //   console.log($scope.inputData.vCode)
      //     //验证验证码
      //   Common.post("merchantAPI/operator/bank/accountno/sms/verify", {
      //     "verifyCode": $scope.inputData.vCode
      //   }, function() {
      //     $state.go("tab.mine_addBankCard");
      //   }, {})
      // } else {
      //   toast.show('验证码格式错误')
      // }
    }

    $scope.$watch("inputData.vCode", function() {
      if (/^\d{6}$/.test($scope.inputData.vCode)) {
        $scope.submit = true;
      } else {
        $scope.submit = false;
      }
    })

    //IOS计时缓慢问题
    var hiddenTime, visibleTime;
    document.addEventListener("pause", function() {
      if (!$scope.isCounting) return;
      hiddenTime = new Date().getTime();
      visibleTime = $scope.seconds;
    }, false);
    document.addEventListener("resume", function() {
      if (!$scope.isCounting) return;
      var timemax = visibleTime - ((new Date().getTime() - hiddenTime) / 1000 | 0)
      if (timemax > 0) {
        $scope.seconds = timemax;
      } else {
        $interval.cancel(timer);
        $scope.seconds = 59;
        $scope.isCounting = false;
        $scope.btnText = "重新发送";
      }
    }, false);



    $scope.sendCode = function() {
      var vCode = $scope.inputData.vCode;
      if ($scope.btnText == "获取验证码" || $scope.btnText == "重新发送") {
        $scope.isCounting = true;
        console.log('sending code...')
        $scope.count();
        //向后台发送请求
        Common.post("merchantAPI/operator/bank/accountno/sms/send", {}, function() {
          console.log('发送验证码成功...')
        }, {})
      }
    }



    //短信倒计时
    $scope.count = function() {
      $scope.btnText = "59s后重发";
      timer = $interval(function() {
        $scope.seconds--;
        if ($scope.seconds != 0) {
          $scope.seconds = $scope.seconds >= 10 ? $scope.seconds : "0" + $scope.seconds;
          $scope.btnText = $scope.seconds + "s后重发";
        } else {
          $interval.cancel(timer);
          $scope.seconds = 59;
          $scope.isCounting = false;
          $scope.btnText = "重新发送";
        }
      }, 1000)
    }

    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.loginPhone = Common.getCache('Token').username;
      $scope.inputData = {
        vCode: ''
      }

    });
  });
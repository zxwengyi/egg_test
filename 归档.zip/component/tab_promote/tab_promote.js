var tab_promote_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.tab_promote', {
            url: '/tab_promote',
            views: {
                'tab-promote': {
                    templateUrl: 'component/tab_promote/tab_promote.html',
                    controller: 'tab_promoteCtrl'
                }
            }
        });
};
myapp.config(tab_promote_myConfig);

angular.module('starter.tab_promote', [])
    .controller('tab_promoteCtrl', function ($scope, Common, cordovaPlug, toast, $rootScope) {

        $scope.saveCode = function () {
        	if ($rootScope.role == 4) {
                Common.showAlert('','对不起，您暂未关联商家，请关联后再进行分享');
                return
            }
            cordovaPlug.CommonPL(function (data) {
                toast.show('二维码已经保存成功')
            }, "saveQRImage", [$scope.QRCode])
        }
        $scope.gotoShare = function () {
            if ($rootScope.role == 4) {
                Common.showAlert('','对不起，您暂未关联商家，请关联后再进行分享');
                return
            }
            console.log('成功调用分享');
            Common.glShare('给乐生活：邀您体验有bigger的全单打折消费方式！', '用给乐生活消费买单，单单返现，让您的消费增值。', 'https://register.365gl.com/register/c/image/le.png', $scope.shareUrl);
        }
        $scope.$on('$ionicView.beforeEnter', function () {
            var nativeBroadcastMsg = null;
            window.broadcastMsgNum = function (obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
                if (typeof(obj) == "object") {
                    nativeBroadcastMsg = obj.data;
                } else {
                    nativeBroadcastMsg = angular.fromJson(obj).data;
                }
                $scope.$emit('msgNum', nativeBroadcastMsg);
            };

            if ($rootScope.role != 4) {
                Common.get('merchantAPI/merchant/invite/register', {}, function (_data) {
                    Common.showLoading();
                    console.log(_data.data.invitationUrl);
                    $scope.shareUrl = _data.data.invitationUrl;
                    cordovaPlug.CommonPL(function (data) {
                        if (data.status == 1) {
                            $scope.QRCode = data.data.QRCodeImage;
                            Common.hideLoading();
                            $scope.$apply();
                        } else {
                            Common.hideLoading();
                            toast.show("插件调用失败！");
                        }
                    }, "generateCode", [_data.data.invitationUrl])
                }, {});
            } else {
                $scope.QRCode = 'img/er_img_1.png';
            }


            //读取推广人数
            // $scope.todayFansNum = ''; //今日推广人数
            $scope.totalFansNum = '';  //累计推广人数
            Common.post('merchantAPI/merchant/invite/queryToDayInviteCount', {}, function (res) {
                // $scope.todayFansNum = res.data.todayFansNum;
                $scope.totalFansNum = res.data.totalFansNum;
            }, {})
        });
    });
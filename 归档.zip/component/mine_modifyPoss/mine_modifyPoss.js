var mine_modifyPoss_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_modifyPoss', {
      url: '/mine_modifyPoss',
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_modifyPoss/mine_modifyPoss.html',
          controller: 'mine_modifyPossCtrl'
        }
      }
    });
};
myapp.config(mine_modifyPoss_myConfig);

angular.module('starter.mine_modifyPoss', [])
  .controller('mine_modifyPossCtrl', function($scope, $ionicModal, $state, toast, Common, $timeout) {
    $scope.inputData = {
      prevPwd: ''
    }
    $scope.msg = '密码不能为空';
    $scope.showTips1 = false;
    $scope.next = function() {
      var reg = /^\d+$/;
      var prevPwd = $scope.inputData.prevPwd;
      if (prevPwd.length < 6) {
        $scope.showTips1 = true;
        $scope.msg = "请输入6位数数字密码";
        return;
      }
      if (!reg.test(prevPwd)) {
        $scope.showTips1 = true;
        $scope.msg = "密码只能为数字";
        return;
      }
      if (prevPwd) {
        Common.checkMd5("GL_SALT_MD5_KEY" + $scope.inputData.prevPwd.toString(), function(data) {
          Common.post('merchantAPI/operator/initPosPwd', {
            "newPassword": data.MD5
          }, function(res) {
            console.log('res>>>>', res);
            $scope.showTips1 = true;
            $scope.msg = res.description;
            $scope.inputData.prevPwd = '';
            setTimeout(function(){
              $scope.showTips1 = false;
              $scope.msg = '';
              $state.go('tab.my_manager');
            },1500)
          }, {}, 1);
        })
      } else {
        $scope.showTips1 = true;
        $scope.msg = "密码不能为空";
      }
    }
  });
var mapSearch_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.mapSearch', {
            url: '/mapSearch',
            cache: false,
            views: {
                'tab-index': {
                    templateUrl: 'component/mapSearch/mapSearch.html',
                    controller: 'mapSearchCtrl'
                }
            }
        });
};
myapp.config(mapSearch_myConfig);

angular.module('starter.mapSearch', [])
    .controller('mapSearchCtrl', function ($scope, $state, toast, Common) {
        var map = new BMap.Map("l-map");
        $scope.$on('$ionicView.beforeEnter', function () {
            $scope.isShowCurrenPositon = false
            $scope.isShowSelectPositon = false

            if (Common.getCache('currentPosition')) {
                $scope.isShowCurrenPositon = true
                $scope.currentPosition = Common.getCache('currentPosition')
                if ($scope.currentPosition) {
                    var pointA = {
                        lng: $scope.currentPosition.longitude,
                        lat: $scope.currentPosition.latitude
                    }
                    var point = new BMap.Point(pointA.lng, pointA.lat);
                    map.centerAndZoom(point, 18);
                    map.enableScrollWheelZoom(true);
                    var marker = new BMap.Marker(point);
                    map.addOverlay(marker);
                    map.panTo(pointA);
                    var loadCount = 1;
                    map.addEventListener("tilesloaded", function () {
                        if (loadCount == 1) {
                            map.setCenter(point);
                        }
                        loadCount = loadCount + 1;
                    })
                }
            } else {
                $scope.isShowCurrenPositon = true
                var geolocation = new BMap.Geolocation();
                geolocation.getCurrentPosition(function (r) {
                    if (this.getStatus() == BMAP_STATUS_SUCCESS) {
                        map.centerAndZoom(new BMap.Point(r.point.lng, r.point.lat), 18);
                        map.enableScrollWheelZoom(true);
                        var mk = new BMap.Marker(r.point);
                        map.addOverlay(mk);
                        map.panTo(r.point);
                        var loadCounts = 1;
                        map.addEventListener("tilesloaded", function () {
                            if (loadCounts == 1) {
                                map.setCenter(r.point);
                            }
                            loadCount = loadCount + 1;
                        })
                        $scope.currlng = r.point.lng
                        $scope.currlat = r.point.lat
                       
                    }
                }, {
                    enableHighAccuracy: true
                })
            }
        });

        $scope.toggleShowOptions = function () {
            Common.checkLocation(function (data) {
                Common.setCache('currentPosition', data)
                $state.go('tab.my_information', {
                    longitude: data.longitude,
                    latitude: data.latitude
                })
            });
        }
        $scope.backPre = function () {
            window.history.back()
        }
        $scope.search = function () {
        
            $scope.isShowCurrenPositon = false

            function myFun() {
                var pointList = []
                console.log('local>>>>>>>', local.getResults())
                pointList = local.getResults().Br
                var pointArray = new Array()
                var marker = new Array()
                map = new BMap.Map("l-map");
                pointList.forEach(function (item, i) {
                    var p0 = item.point.lng
                    var p1 = item.point.lat
                    pointArray[i] = new window.BMap.Point(p0, p1)
                    // map.centerAndZoom(pointArray[i], 18)
                    map.setCenter(pointArray[i]);
                    marker[i] = new BMap.Marker(pointArray[i]) //按照地图点坐标生成标记
                    map.addOverlay(marker[i])
                    map.panTo(pointArray[i]);
                    // var loadCounts = 1;
                    // map.addEventListener("tilesloaded", function () {
                    //     if (loadCounts == 1) {
                    //         map.setCenter(pointArray[i]);
                    //     }
                    //     loadCounts = loadCounts + 1;
                    // })
                    marker[i].addEventListener('click', function (evt) {
                        // $scope.isShowCurrenPositon = false
                        document.getElementById('isShowSelectPositon').style.display = 'block'
                        var point = evt.target.point
                        var geocoder = new BMap.Geocoder()

                        geocoder.getLocation(point, function (geocoderResult, LocationOptions) {
                            $scope.longitude = geocoderResult.point.lng
                            $scope.latitude = geocoderResult.point.lat
                            $scope.gps = geocoderResult.point.lng + ',' + geocoderResult.point.lat
                        })

                    })
                  
                });
                map.setViewport(pointArray)
            }

            var local = new BMap.LocalSearch(map, {
                onSearchComplete: myFun
            });
            var myValue = $scope.address
            local.search(myValue);
            $scope.isShowSelectPositon = true

        }
        $scope.sureSelectAddress = function () {
            if (!$scope.gps) {
                return toast.show('请选择一个地址')
            }
            $state.go('tab.my_information', {
                longitude: $scope.longitude,
                latitude: $scope.latitude,
                mapAddress:$scope.address
            })
        }
    });
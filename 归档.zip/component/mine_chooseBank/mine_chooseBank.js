var mine_chooseBank_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_chooseBank', {
      url: '/mine_chooseBank',
      params: {
        bankName: '',
        bankIndex: '',
        userName: '',
        idNo: '',
        cardNo: '',
        city: '',
        province: ''
      },
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_chooseBank/mine_chooseBank.html',
          controller: 'mine_chooseBankCtrl'
        }
      }
    });
};
myapp.config(mine_chooseBank_myConfig);

angular.module('starter.mine_chooseBank', [])
  .controller('mine_chooseBankCtrl', function($scope, $http, $stateParams, $timeout, $ionicModal, actionSheetItem, $state, toast, Common) {



    //保存所有银行名字
    var bankNames = [],
      bankIcons = [],
      bankId = [],
      bankColor = [];



    function getAllAreas() {
      $http({
        method: 'get',
        url: './data/city.json'
      }).then(function(data) {
        var data = data.data.list;
        var parent = {},
          city = {},
          area = {}
        data.forEach(function(item) {
          if (!parent[item.parentAreaId]) {
            parent[item.parentAreaId] = [item]
          } else {
            parent[item.parentAreaId].push(item)
          }
        })
        //  取所有的城市
        parent[1].forEach(function(item) {
          if (!city[item.parentAreaId]) {
            city[item.parentAreaId] = [item.pickerViewText]
          } else {
            city[item.parentAreaId].push(item.pickerViewText)
          }
        })

        Common.setCache('allCitiesProvinces', data);
        Common.setCache('allCities', city[1]);
      })
    }

    //取省份
    function getAllProvinces(index) {
      var province = [];
      var p = Common.getCache('allCitiesProvinces');
      p.forEach(function(item) {
        if (item.parentAreaId == index) {
          province.push(item.pickerViewText)
        }
      })
      return province;
    }

    // $scope.selectedYear = $stateParams.city ? $stateParams.city : Common.getCache("allCities")[1];
    // $scope.selectedMonth = $stateParams.province ? $stateParams.province : getAllProvinces(3)[0];
    $scope.selectedYear = $stateParams.city ? $stateParams.city : '';
    $scope.selectedMonth = $stateParams.province ? $stateParams.province : '';


    $scope.selectBankId = '';
    $scope.selectBank = function(i, e) {
      //用于给当前li添加active
      $scope.selectBankId = i;
      actionSheetItem.chooseBankCard({
        scope: $scope,
        shengfen: Common.getCache("allCities"),
        c_shengfen: Common.getCache("allCities")[1], //安徽
        chengshi: getAllProvinces(3),
        c_chengshi: getAllProvinces(3)[0],
        show_city: $stateParams.city ? $stateParams.city : '',
        show_province: $stateParams.province ? $stateParams.province : '',
        cancel: function() {

        },
        success: function(rst) {
          $scope.selectBankId = ''
          $state.go('tab.mine_chooseBranchBank', {
            // bankIndex: i,
            bankName: bankNames[i],
            city: rst[0],
            province: rst[1],
            areaId: rst[2],
            userName: $stateParams.userName,
            idNo: $stateParams.idNo,
            cardNo: $stateParams.cardNo,
            icon: bankIcons[i],
            bankId: bankId[i],
            color: bankColor[i]
          });

        }
      })
    }

    $scope.goBack = function() {
      var userName = $stateParams.userName ? $stateParams.userName : '';
      var cardNo = $stateParams.cardNo ? $stateParams.cardNo : '';
      var idNo = $stateParams.idNo ? $stateParams.idNo : '';
      $state.go("tab.mine_addBankCard", {
        userName: userName,
        cardNo: cardNo,
        idNo: idNo
      })
    }

    $scope.$on('$ionicView.beforeEnter', function() {
      getAllAreas();
      //取得所有银行信息
      $http({
        method: 'get',
        url: './data/bank.json'
      }).then(function(data) {
        var data = data.data;
        $scope.bankList = data;
        Common.setCache("allBankInfo", data);
        for (var key in data) {
          bankNames.push(data[key].name);
          bankIcons.push(data[key].icon);
          bankId.push(key);
          bankColor.push(data[key].color);
        }
      })
    });
  });
var my_allmanager_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.my_allmanager', {
      url: '/my_allmanager',
      views: {
        'tab-mine': {
          templateUrl: 'component/my_allmanager/my_allmanager.html',
          controller: 'my_allmanagerCtrl'
        }
      }
    });
};
myapp.config(my_allmanager_myConfig);
angular.module('starter.my_allmanager', [])
  .controller('my_allmanagerCtrl', function($scope, Common, $state, $rootScope, cordovaPlug, toast, $http,$timeout) {
    $scope.logout = function() {
      Common.showConfirm('退出提醒', '<p class="tc">您是否要退出当前账户？</p>', function() {
        Common.post('merchantAPI/chainLogout',{}, function(data) {
          Common.logout();
          $state.go("tab.mine_toLogin",{}, { reload: true });
        }, {}, 1)
      }, {}, '确定', '取消')
    }
    $scope.$on('$ionicView.beforeLeave',function(){
      $scope.showTipBoo = false;
    })
    $scope.$on('$ionicView.beforeEnter', function() {
    	$rootScope.hideHeader = true;
    	$timeout(function(){
    		$rootScope.hideHeader = true;
    	},10)
      $scope.information = Common.getCache('Token');
      //获取分类配置表
    });
  });
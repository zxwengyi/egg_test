var mine_verifyPhoneCode_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_verifyPhoneCode', {
      url: '/mine_verifyPhoneCode',
      views: {
        'tab-index': {
          templateUrl: 'component/mine_verifyPhoneCode/mine_verifyPhoneCode.html',
          controller: 'mine_verifyPhoneCodeCtrl'
        }
      }
    });
};
myapp.config(mine_verifyPhoneCode_myConfig);

angular.module('starter.mine_verifyPhoneCode', [])
  .controller('mine_verifyPhoneCodeCtrl', function($scope, $interval, $timeout, $state, Common, toast) {
    var timer;
    var regPhone = /^1(3|4|5|7|8)\d{9}$/;
    $scope.seconds = 59;
    $scope.btnText = "获取验证码";

    $scope.submit = false;
    $scope.isCounting = false;

    //下一步
    $scope.next = function() {
      console.log(111222)
      if (/^\d{6}$/.test($scope.inputData.vCode)) {
        console.log($scope.inputData.vCode)
          //验证验证码
        Common.post("merchantAPI/operator/bank/accountno/sms/verify", {
          "verifyCode": $scope.inputData.vCode
        }, function() {
          $state.go("tab.mine_addBankCard");
        }, {})
      } else {
        toast.show('验证码格式错误')
      }
    }

    $scope.$watch("inputData.vCode", function() {
      if (/^\d{6}$/.test($scope.inputData.vCode)) {
        $scope.submit = true;
      } else {
        $scope.submit = false;
      }
    })



    $scope.sendCode = function() {
      if ($scope.btnText == "获取验证码" || $scope.btnText == "重新发送") {
        if (regPhone.test($scope.inputData.phone)) {
          $scope.isCounting = true;
          $scope.count();
          //向后台发送请求
          Common.post("merchantAPI/operator/bank/accountno/sms/send", {}, function() {
            console.log('发送验证码成功...')
          }, {})
        } else {
          toast.show("请输入正确的手机号")
        }
      }
    }



    //短信倒计时
    $scope.count = function() {
      $scope.btnText = "59s后重发";
      timer = $interval(function() {
        $scope.seconds--;
        if ($scope.seconds != 0) {
          $scope.seconds = $scope.seconds >= 10 ? $scope.seconds : "0" + $scope.seconds;
          $scope.btnText = $scope.seconds + "s后重发";
        } else {
          $interval.cancel(timer);
          $scope.seconds = 59;
          $scope.isCounting = false;
          $scope.btnText = "重新发送";
        }
      }, 1000)
    }

    //IOS计时缓慢问题
    var hiddenTime, visibleTime;
    document.addEventListener("pause", function() {
      if (!$scope.isCounting) return;
      hiddenTime = new Date().getTime();
      visibleTime = $scope.seconds;
    }, false);
    document.addEventListener("resume", function() {
      if (!$scope.isCounting) return;
      var timemax = visibleTime - ((new Date().getTime() - hiddenTime) / 1000 | 0)
      if (timemax > 0) {
        $scope.seconds = timemax;
      } else {
        $interval.cancel(timer);
        $scope.seconds = 59;
        $scope.isCounting = false;
        $scope.btnText = "重新发送";
      }
    }, false);

    $scope.$on('$ionicView.beforeEnter', function() {
      $scope.inputData = {
        phone: '',
        vCode: ''
      }

    });
  });
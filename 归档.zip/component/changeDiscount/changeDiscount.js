var changeDiscount_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.changeDiscount', {
        url: '/changeDiscount',
        views: {
            'tab-mine': {
                templateUrl: 'component/changeDiscount/changeDiscount.html',
                controller: 'changeDiscountCtrl'
            }
        }
    });
};
myapp.config(changeDiscount_myConfig);

angular.module('starter.changeDiscount',[])
.controller('changeDiscountCtrl', function($scope,Common) {
    $scope.goBack=function(){
        window.history.back()
    }
    $scope.NextSubmit=function(){
        console.log($scope.bean)
        Common.post("merchantAPI/merchant/update/glfeerate", {
            discountRate: $scope.bean,
            remark: $scope.reason
        }, function(data) {
            console.log(data);
            toast.show("提交成功");
        }, {});
    }
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

var my_award_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_award', {
        url: '/my_award',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_award/my_award.html',
                controller: 'my_awardCtrl'
            }
        }
    })
    .state('tab.my_award1', {
        url: '/my_award1',
        views: {
            'tab-index': {
                templateUrl: 'component/my_award/my_award.html',
                controller: 'my_awardCtrl'
            }
        }
    });
};
myapp.config(my_award_myConfig);

angular.module('starter.my_award',[])
.controller('my_awardCtrl', function($scope,$interval,$document,Common,toast,$timeout,$ionicScrollDelegate) {
        //点击事件后处理
        $scope.selkey = 50;
        $scope.draw = true;
        $scope.ruleData = [];
        $scope.clickMe = function(){
            if($scope.draw){
                if($scope.numSize==0){
                    toast.show("抽奖次数为零");
                }else{
                    $scope.draw = false;
                    $scope.numSize--;
                    $scope.numberValue1();
                }
            }
        }
        $scope.randomRule = function(data){
            $scope.oldItems = data;
            var newObject = {"createRuleId":"test",
                    "operateAmount":0,
                    "prizeName":"谢谢参与"
                }
            if($scope.oldItems != null && $scope.oldItems.length < 8){
                var myNewNum = 8 - $scope.oldItems.length;
                for(var i= 0 ;i<myNewNum;i++){
                    var l = Math.random()*($scope.oldItems.length+1) | 0;
                    $scope.oldItems.splice(l,0,newObject);
                }
            }
            $scope.oldItems.splice(4,0,newObject);
            $scope.awardList = $scope.oldItems;
        }

        

        //大图动画，找到元素
        $scope.bigImg = function(){
            var num = 0;
            var timer = $interval(function(){
                num++;
                if(num%2 == 0){
                    $scope.awardSelect = true;
                }else{
                    $scope.awardSelect = false;
                }
            },800,5);
        }


        $scope.numberValue1 = function(){
            Common.get("merchantAPI/redenvelope/distribute",{
              'accountType':'02'
            },function(data){
                for(var i=0;i<$scope.oldItems.length;i++){
                    if($scope.oldItems[i].operateAmount == data.data.operateAmount){
                        $scope.operateAmount = data.data.operateAmount;
                        $scope.selkey = 4*8+i+1;
                        console.log($scope.operateAmount)
                        break;
                    }
                }
                $scope.bigImg();
                $scope.smallImg();
            },{})
        }

        //小图片滚动
        $scope.smallImg = function(){
            var bgColor = true,lists = [0,1,2,5,8,7,6,3];
            var liList = angular.element(document.querySelectorAll('.item-lists'));
            for(var i=0;i<$scope.selkey;i++){
                (function(i,$scope){
                    $timeout(function(){
                        var itemIndex = i % 8;
                        liList.removeClass('show-item');
                        angular.element(liList[lists[itemIndex]]).addClass('show-item');
                    },80*i)
                })(i,lists)
                if(i == $scope.selkey-1){
                    $timeout(function(){
                        if($scope.operateAmount == 0) $scope.moddle_show5 = true;
                        else{
                            Common.get("merchantAPI/redenvelope/winning", {}, function (data) {
                                $scope.dataTops = data.data;
                            }, {})
                            $scope.awardMeModdle = true;
                        }
                    },i*80)
                }
            }
        }
        //隐藏model
        $scope.hideModel = function(){
            $scope.moddle_show5 = false;
            $scope.awardMeModdle = false;
            $scope.draw = true;
            $scope.getModd();
        }
    $scope.hasmOreDell = function(elem,attrs) {
        Common.get("merchantAPI/redenvelope/winning", {}, function (data) {
            $scope.dataTops = data.data;
            if(data.data.length >6){
                $scope.startRun(1);
            }
        }, {})
    }
    $scope.startRun = function(_num){
        $timeout(function(){
            var height = angular.element(document.querySelectorAll('.my_award')[0]).css('height').toString();
            $ionicScrollDelegate.$getByHandle('mainScroll').scrollTo(0, height.substring(0,height.length - 2)*_num,true);
            if(_num > 10){
                _num = 1;
                $ionicScrollDelegate.$getByHandle('mainScroll').scrollTo(0, 0,false);
            }else{
                $scope.dataTops.push($scope.dataTops[_num-1]);
            }
            $scope.startRun(_num+1);
        },1000)
    }
    $scope.hasmOreDell();
    $scope.$on('$ionicView.beforeEnter', function() {
        //初始化加载抽奖实例
        $scope.getModd = function(){
            Common.get("merchantAPI/redenvelope/rule",{},function(data){
                $scope.ruleData = data.data;
                $scope.randomRule(data.data);
            },{});
        }
        $scope.getModd();
        //进来加载抽奖次数
        Common.get("merchantAPI/redenvelope/operateSum",{},function(data){
            $scope.numSize = data.data.operateSum;
        },{});
    });
});

var account_detail_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.account_detail', {
        url: '/account_detail/:id/:time',
        //hideHeader:true,
        views: {
            'tab-financial': {
                templateUrl: 'component/account_detail/account_detail.html',
                controller: 'account_detailCtrl'
            }
        }
    });
};

myapp.config(account_detail_myConfig);

angular.module('starter.account_detail',[])
.controller('account_detailCtrl', function($scope,Common,$stateParams,$state,debugLocalCommon,$timeout,$ionicHistory) {
    $scope.showDetail = function (item) {
        Common.setCache('account_info_id_item',item)
        $state.go('tab.account_info')
    }
    $scope.goBack=function () {
        debugLocalCommon.setNoReloadPage();
        window.history.back()
    }
    $scope.search={
        index:0,
        pageSize:10,
        queryDate:$stateParams.time
    }
    $scope.doRefresh=function () {
        $scope.search.index = 1;
        getList()
    }
    $scope.list=[]
    $scope.isHasMore =false;
    $scope.loadMore = function () {
        $scope.search.index++;
        getList()
    }
    $scope.loadMore()
    function getList() {

        debugLocalCommon.post('merchantAPI/order/finanStatisDetail',{
            curPage:$scope.search.index,
            pageSize:$scope.search.pageSize,
            status:$stateParams.id,
            queryDate:$stateParams.time
        },function (rst) {
            var list = rst.data.list ? rst.data.list:[]
            if($scope.search.index>rst.data.totalPage) {
                $scope.isHasMore =false;
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.$broadcast('scroll.refreshComplete');
                return
            }
            if($scope.search.index == 1) $scope.list =list
            else $scope.list =$scope.list.concat(list)
            $timeout(function () {
                $scope.isHasMore = true;
                if(list.length<$scope.search.pageSize) $scope.isHasMore =false;
                $scope.$broadcast('scroll.infiniteScrollComplete');
                $scope.$broadcast('scroll.refreshComplete');
            },500)
        },function () {})
    }

    $scope.$on('$ionicView.beforeEnter', function() {
        angular.element(document.querySelectorAll('#tab_header')).addClass('change_common_hide_header');
    });
});

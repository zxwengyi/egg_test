var mine_myWallet_myConfig = function($stateProvider) {
    $stateProvider
        .state('tab.mine_myWallet', {
            url: '/mine_myWallet',
            views: {
                'tab-mine': {
                    templateUrl: 'component/mine_myWallet/mine_myWallet.html',
                    controller: 'mine_myWalletCtrl'
                }
            }
        });
};
myapp.config(mine_myWallet_myConfig);

angular.module('starter.mine_myWallet', [])
    .controller('mine_myWalletCtrl', function($scope, $state, $stateParams,$sce,Common,$state) {
        $scope.$on('$ionicView.beforeEnter', function() {
			Common.get('merchantAPI/operator/bank/accountno/query',{},function (data) {
				$scope.bankList = data.data;
				console.log($scope.bankList)
	        })
			Common.post('merchantAPI/withdraw/query/totalProfitFee',{},function(data){
				$scope.Money = data.data;
			})
			Common.get('merchantAPI/withdraw/query/user',{
	            "curPage":1,
	            "pageSize":100
	        },function(data){
	            $scope.items = data.data;
	        },{})
	    });
	    $scope.gotoWithdrawal = function(){
	    	if($scope.bankList == undefined) return;
	    	$state.go('tab.mine_withdrawal')
	    }
	    $scope.gotoBack = function(){
//	    	window.history.back();
			$state.go('tab.my_manager');
	    }
	    $scope.showStatus = function(item,$event){
	    	$event.stopPropagation();
	    	Common.showAlert('',item.remark);
	    }
	    $scope.gotoDetail = function(item){
	    	Common.setCache('wallet_detail',item);
	    	$state.go("tab.wallet_details")
//	    	ui-sref="tab.wallet_details({'id':item.voucherId})"
	    }
	    
    });
var my_getting_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_getting', {
        url: '/my_getting',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_getting/my_getting.html',
                controller: 'my_gettingCtrl'
            }
        }
    })
    .state('tab.my_getting1', {
        url: '/my_getting1',
        views: {
            'tab-index': {
                templateUrl: 'component/my_getting/my_getting.html',
                controller: 'my_gettingCtrl'
            }
        }
    });
};
myapp.config(my_getting_myConfig);

angular.module('starter.my_getting',[])
.controller('my_gettingCtrl', function($scope,$state,$ionicHistory) {
     $scope.hdqgotoBack = function () {
          $state.go("tab.my_feedBack");   
    }   

    $scope.gotoRuturn = function(){
         $state.go("tab.my_manager");            
    }

    $scope.$on('$ionicView.beforeEnter', function() {
        
    });
});

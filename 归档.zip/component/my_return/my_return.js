var my_return_myConfig = function ($stateProvider) {
	$stateProvider
		.state('tab.my_return', {
			url: '/my_return/{:vallue}',

			views: {
				'tab-mine': {
					templateUrl: 'component/my_return/my_return.html',
					controller: 'my_returnCtrl'
				}
			}
		});
};
myapp.config(my_return_myConfig);

angular.module('starter.my_return', [])
	.controller('my_returnCtrl', function ($scope, toast, Common, $stateParams, $state, $ionicHistory, $timeout, $ionicScrollDelegate) {

		// var c = document.getElementById("myCanvas");
		// var ctx = c.getContext("2d");
		// ctx.beginPath(); //路径开始
		// ctx.strokeStyle = "rgba(232,233,235,0.2)";
		// ctx.lineWidth = 9;
		// ctx.arc(225, 100, 90, 0, 2 * Math.PI);
		// ctx.stroke();
		// $scope.bean = $stateParams.vallue
		// var end = parseFloat($scope.bean) / 100 * 2 + 1.5;
		// $scope.endR = function() {
		// 	ctx.beginPath(); //注意此处！
		// 	ctx.arc(225, 100, 90, 1.5 * Math.PI, end * Math.PI, false);
		// 	ctx.strokeStyle = 'rgb(255,159,0)';
		// 	ctx.stroke();
		// }
		// var timer = setInterval(function() {
		// 	$scope.endR();
		// }, 100);


		// $scope.slideBottom = function () {
		//     $timeout(function () {
		//         $ionicScrollDelegate.scrollBottom(true)
		//         $ionicScrollDelegate.resize()
		//     }, 300)
		// }
		$scope.maxDiscountRate = Common.getCache('maxDiscountRate');
		Common.get('merchantAPI/merchant/info', {}, function (data) {
			$scope.discountRate = data.data.discountRate;
			if ($scope.maxDiscountRate < $scope.discountRate) {
				$scope.maxDiscountRates = $scope.discountRate
			} else {
				$scope.maxDiscountRates = $scope.maxDiscountRate
			}
			$scope.showPlace = "（根据您的行业最高可输入" + $scope.maxDiscountRates / 10 + "折,高于" + $scope.maxDiscountRates / 10 + "折需要审核）";
			$scope.showPlace_2 = "请输入修改原因";
		})

		$scope.data = {
			discountRate: null,
			reason: null
		}
		$scope.playFun = 1;
		// $scope.infor = Common.getCache("Token");
		$scope.showMark = false;
		$scope.myVar = true;
		$scope.clientSideList = [{
				text: "活动结束",
				value: "bb"
			},
			{
				text: "运营成本增加",
				value: "ng"
			},
			{
				text: "其他",
				value: "em"
			},
		];
		Common.get('merchantAPI/merchant/info', {}, function (data) {
			$scope.infor = data.data
		})
		$scope.serverSideChange = function (item) {
			$('#inputA').blur();
			$('#inputB').blur();
			$scope.activeText = item.text;
			if (item.text == '活动结束') {
				$scope.myVar = true;
				$scope.data.reason = '';
				$('#message').blur();
			} else if (item.text == '运营成本增加') {
				$scope.myVar = true;
				$scope.data.reason = '';
				$('#message').blur();
			} else {
				$scope.myVar = false;
			}
		};

		// $scope.showPlace = "高于" + $scope.infor.minSaleRate + "折直接生效，低于" + $scope.infor.minSaleRate + "折需要审核";
		// $timeout(function () {
		//
		// },100)
		//状态为0的话说明有审核中的订单
		Common.get("merchantAPI/merchant/glfeerate/info", {
			"curPage": 1,
			"pageSize": 100
		}, function (data) {
			if (data.data.list) {
				$scope.dataStatus = data.data.list[0].status
			}
		}, {});

		$scope.funReturn = function () {
			if ($scope.dataStatus == 0) {
				$scope.present();
				return
			}
			if ($scope.data.code < $scope.maxDiscountRate && $scope.data.code < ($scope.discountRate * 0.5) && $scope.data.code != null) {
				Common.showConfirm("退出提醒", "您的折扣过低，确定这样输入吗？", function () {
					$scope.present();
				}, function () {}, "确定", "取消");
				return;
			}
			if ($scope.submitBoo) $scope.present();
		}
		$scope.$watch('data.code', function (n) {
			var reg = /^\d+?$/;
			$scope.showMark = false;
			$scope.$watch('data.password', function (v) {
				if (n == null || v == null || n == undefined || !v == undefined) {
					$scope.submitBoo = false
					return;
				} else {
					$scope.submitBoo = true;
				}
			})


			if (n == 0) {
				Common.showConfirm("温馨提醒", "您输入的折扣过低，请输入10以上的数字", function () {}, function () {}, "我知道了", "取消");
				return
			}

			if (!reg.test(n)) $scope.data.code = (n+'').toString().substr(0, n.length - 1);
			if (n > $scope.maxDiscountRate && n < $scope.infor.discountRate) {
				$scope.showMark = false;
			} else if (n > $scope.maxDiscountRate) {
				$scope.showMark = true;
				$scope.submitBoo = true;
			} else {
				$scope.showMark = false;
			}
		});



		$scope.present = function () {
			var reg = /^\d+?$/;
			//如果状态是0的话直接走接口
			if (!$scope.dataStatus == 0) {
				if (!reg.test($scope.data.code)) {
					Common.showConfirm("温馨提醒", "请输入两位不带小数点的数字，例：9折输入90，8.5折输入85", function () {}, function () {}, "我知道了", "取消");
					return
				}
			}

			if (!$scope.data.code) {
				return toast.show('请输入修改折扣！')
			}
			if ($scope.data.code == $scope.discountRate) {
				return toast.show('输入折扣和当前折扣一致，请重新输入')
			}
			if (!$scope.data.password) {
				return toast.show('请输入商户账号登录密码！')
			}
			if ($scope.showMark && !$scope.activeText) {
				return toast.show('请选择修改原因！')
			}
			if (!$scope.myVar && !$scope.data.reason) {
				return toast.show('请输入修改原因！')
			}
			Common.post("merchantAPI/merchant/update/glfeerate", {
				"discountRate": $scope.data.code,
				"remark": $scope.data.reason ? $scope.data.reason : $scope.activeText,
				"pwd":  hex_md5("GL_SALT_MD5_KEY" + $scope.data.password)
			}, function (data) {
				if ($scope.showMark) {
					toast.show("折扣修改已经提交审核！");
				} else {
					toast.show("折扣修改成功");
				}
				if ($scope.showMark) {
					$scope.information = Common.getCache('Token');
					$scope.information.saleRate = $scope.data.code;
					Common.setCache('Token', $scope.information)
				}
				$scope.infor.discountRate = $scope.data.code;
				$state.go('tab.my_manager');
			}, {});
		}

		// $scope.fiLows = function() {
		//     if ((5 <= $scope.data.code && $scope.data.code <= 90) && ($scope.data.reason != null && $scope.data.reason != '')) {
		//         $scope.active = true;
		//     } else {
		//         $scope.active = false;
		//     }
		// }
		// $scope.$watch('data.code', function() {
		//     $scope.$watch('data.reason', function() {
		//         $scope.fiLows();
		//     }, true)
		// }, true);
		$scope.goBack = function () {
			window.history.back();
		}

		//var reg=/^[\u4e00-\u9fa5]{6}.{0,}$/;  //文本
		//var type = ["20%","40%","60%","80%","100%"];
		//var regx = /^[5-9]%|[1-2]\d%|3[0-5]%$/;  //百分比
		// 中心：arc(100,75,50,0*Math.PI,1.5*Math.PI)
		// 起始角：arc(100,75,50,0,1.5*Math.PI)
		// 结束角：arc(100,75,50,0*Math.PI,1.5*Math.PI)
		$scope.$on('$ionicView.beforeEnter', function () {

			$scope.data = {
				code: null,
				reason: null,
				password: null
			}
		});
	});
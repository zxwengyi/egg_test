var mine_earnings_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.mine_earnings', {
        url: '/mine_earnings',
        views: {
            'tab-mine': {
                templateUrl: 'component/mine_earnings/mine_earnings.html',
                controller: 'mine_earningsCtrl'
            }
        }
    });
};
myapp.config(mine_earnings_myConfig);

angular.module('starter.mine_earnings',[])
.controller('mine_earningsCtrl', function($scope,Common) {

    $scope.$on('$ionicView.beforeEnter', function() {
        Common.get('merchantAPI/withdraw/query/monthly',{
            "curPage":1,
            "pageSize":100
        },function(data){
            $scope.itemList = data.data;
            Common.setCache('earningsList',data.data);
        },{},1)
    });
});

var my_consumption_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_consumption', {
        url: '/my_consumption',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_consumption/my_consumption.html',
                controller: 'my_consumptionCtrl'
            }
        }
    });
};
myapp.config(my_consumption_myConfig);

angular.module('starter.my_consumption',[])
.controller('my_consumptionCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

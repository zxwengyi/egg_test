var index_comVereview_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.index_comVereview', {
        url: '/index_comVereview/:score/:type',
        views: {
            'tab-index': {
                templateUrl: 'component/index_comVereview/index_comVereview.html',
                controller: 'index_comVereviewCtrl'
            }
        }
    });
};
myapp.config(index_comVereview_myConfig);

angular.module('starter.index_comVereview',[])
.controller('index_comVereviewCtrl', function($scope,$stateParams,Common,$rootScope,$state,$timeout,$ionicScrollDelegate) {
    $scope.myArr = [{},{},{},{},{}];
    $scope.myScore = $stateParams.score;
    $scope.myStar = 2.1-((5 - $scope.myScore )/5 * 2.1) +"rem";
    $scope.type = $stateParams.type;
    $scope.information = Common.getCache('Token'); 
    var myCurPage = 1;
    
    $scope.showDiff = function(_num){
        myCurPage = 1;
        $ionicScrollDelegate.$getByHandle('mainScroll').scrollTop();
        Common.post("merchantAPI/merchant/comment/scoreDetailed", {
            "commentType":_num,
            "curPage":myCurPage,
            "pageSize":"20"
        }, function(data) {
            $scope.scoreDetailed = data.data;
            $scope.type = _num;
            $scope.noMoreMsg = true;
            $scope.allCount = Number(data.data.dataMap.goodCount)+Number(data.data.dataMap.mediumCount)+Number(data.data.dataMap.differenceCount);
        }, function() {},1)
    };
    $scope.showDiff(0);
    $scope.loadMore = function(){
        myCurPage++;
        $scope.noMoreMsg = false;
        Common.post("merchantAPI/merchant/comment/scoreDetailed", {
            "commentType":$scope.type,
            "curPage":myCurPage,
            "pageSize":"20"
        }, function(data) {
            if(data.data.totalPage > myCurPage){
                $scope.scoreDetailed.list = $scope.scoreDetailed.list.concat(data.data.list);
                $timeout(function(){
                     $scope.noMoreMsg = true;
                },2000)
            }
            
        }, function() {},1)
    }
    $scope.getComments = function(_int){
        return Number(_int) <= 2 && "差评" || Number(_int) > 3 && "好评" || "中评";
    };
    $scope.gotoIndex = function(){
        $state.go('tab.index_new');
    };
    $scope.$on('$ionicView.beforeEnter', function() {
    });
});

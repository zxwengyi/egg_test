var mine_openAccount_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.mine_openAccount', {
            url: '/mine_openAccount',
            views: {
                'tab-mine': {
                    templateUrl: 'component/mine_openAccount/mine_openAccount.html',
                    controller: 'mine_openAccountCtrl'
                }
            }
        });
};
myapp.config(mine_openAccount_myConfig);

angular.module('starter.mine_openAccount', [])
    .controller('mine_openAccountCtrl', function ($scope, toast, Common, $http, $state, $timeout) {
        $scope.inputData = {
            realName: '',
            idNo: '',
            phoneNo: '',
            verifyCode: ''
        }
        $scope.infoFilled = false;
        var regPhone = /^1(3|4|5|7|8)\d{9}$/;
        var isCardID = function (sId) {
            var regIdCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;
            if (!regIdCard.test(sId)) return "你输入的身份证长度或格式错误";
            return true;
        }

        $scope.sure = function () {
            if ($scope.inputData.realName == '') {
                toast.show('请输入您的姓名');
                return;
            }
            if (isCardID($scope.inputData.idNo) != true) {
                toast.show(isCardID($scope.inputData.idNo));
                return;
            }
            if (!regPhone.test($scope.inputData.phoneNo)) {
                toast.show('请输入正确格式的手机号');
                return;
            }

            //TODO：点击确定，向后台获取跳转URL  POST /merchantAPI/wxpay/act/open
            Common.post("merchantAPI/wxpay/act/open", {
                "cerNo": $scope.inputData.idNo,
                "mobile": $scope.inputData.phoneNo,
                "userName": $scope.inputData.realName,
                "accType": '1'
            }, function (res) {
                toast.show('开户受理成功！');
                $state.go('tab.my_manager')
//              cordovaPlug.CommonPL(function(data){}, "weChatPay", [res.data.authUrl])
            }, {},1)

            // $http({
            //   method: 'post',
            //   data: {
            //     "cerNo": $scope.inputData.idNo,
            //     "mobile": $scope.inputData.phoneNo,
            //     "userName": $scope.inputData.realName
            //   },
            //   url: 'http://192.168.0.183:9012/merchantAPI/wxpay/act/open'
            // }).then(function(data) {
            //   if (data.data.result === '000000') {
            //     toast.show('开户成功！')
            //       //TODO: 跳转到返回的url
            //     console.log("authUrl:" + data.data.data.authUrl)
            //     $state.go("tab.mine_myWallet", {
            //       url: data.data.data.authUrl
            //     })
            //   } else {
            //     toast.show(data.description)
            //   }
            // })   //http END
        }

        $scope.countDownFlag = false; // true的时候为正在倒计时
        var second = 60;

        $scope.countDownText = '发送验证码';

        $scope.countDown = function () {

            if ($scope.countDownFlag) return; // 正在倒计时时候不能重复点击

            $scope.countDownFlag = true;
            var phoneNo = $scope.inputData.phoneNo;

            if (!(/^1[34578]\d{9}$/.test(phoneNo))) {
                Common.showAlert('温馨提示', '手机号码格式不正确');
                $scope.countDownFlag = false;
                return;
            }

            Common.post('merchantAPI/sms/sendSms', {
                businessType: 20,
                phoneNo: phoneNo
            }, function (res) {
                toast.show('验证码已发送');
                count()
            }, function () {
                $scope.countDownFlag = false;
            }, null, null, function () {
                $scope.countDownFlag = false;
            })


        };

        // 验证验证码是否正确
        var canclick = true;
        $scope.verifyCode = function () {

            if (!canclick) return;

            if ($scope.inputData.realName == '') {
                toast.show('请输入您的姓名');
                return;
            }
            if (isCardID($scope.inputData.idNo) != true) {
                toast.show(isCardID($scope.inputData.idNo));
                return;
            }

            if (!regPhone.test($scope.inputData.phoneNo)) {
                Common.showAlert('温馨提示', '手机号码格式不正确');
                return;
            }

            if ($scope.inputData.verifyCode == '') {
                toast.show('请输入验证码');
                return;
            }

            canclick = false;
            Common.post('merchantAPI/sms/verifySms', {
                "phoneNo": $scope.inputData.phoneNo,
                "verifyCode": $scope.inputData.verifyCode,
                "businessType": 20
            }, function () {
                $scope.sure();
            })

            $timeout(function () {
                canclick = true;
            }, 4000)
        };
        function count() {
            $scope.countDownText = second + '秒';
            second--;
            if (second < 0) {
                $scope.countDownText = '重新发送';
                $scope.countDownFlag = false;
                second = 60;
            } else {
                $timeout(function () {
                    count(second)
                }, 1000)
            }
        }

        $scope.$watch('inputData', function (newV) {
            if (newV.realName && isCardID(newV.idNo) == true && regPhone.test(newV.phoneNo) && newV.verifyCode) {
                //点亮确定按钮
                $scope.infoFilled = true;
            } else {
                $scope.infoFilled = false;
            }
        },true)

        $scope.$on('$ionicView.beforeEnter', function () {

        });
    });
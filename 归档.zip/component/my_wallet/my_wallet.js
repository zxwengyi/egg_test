var my_wallet_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_wallet', {
        url: '/my_wallet',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_wallet/my_wallet.html',
                controller: 'my_walletCtrl'
            }
        }
    });
};
myapp.config(my_wallet_myConfig);

angular.module('starter.my_wallet',[])
.controller('my_walletCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

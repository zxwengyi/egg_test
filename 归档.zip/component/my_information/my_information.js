var my_information_myConfig = function ($stateProvider) {
  $stateProvider
    .state('tab.my_information', {
      url: '/my_information?{:longitude,:latitude,:mapAddress}',
      cache: false,
      views: {
        'tab-mine': {
          templateUrl: 'component/my_information/my_information.html',
          controller: 'my_informationCtrl'
        }
      }
    });
};
myapp.config(my_information_myConfig);

angular.module('starter.my_information', [])
  .controller('my_informationCtrl', function ($scope, $ionicHistory, $state, $ionicListDelegate, $http, Common, cordovaPlug, toast, $stateParams, $ionicActionSheet, $timeout, $ionicModal, $ionicSlideBoxDelegate) {
    if (Common.getCache('change') === false) {
      $scope.change = Common.getCache('change')
    } else {
      $scope.change = true;
    }
    if (Common.getCache('merchantInfo') == null && !Common.getCache('newData')) {
      Common.get('merchantAPI/merchant/info', {}, function (data) {

        $scope.newData = data.data;
        $scope.allCityList = []
        $http({
          method: 'get',
          url: './data/city.json'
        }).then(function (rst) {
          $scope.allCityList = rst.data.list
          angular.forEach(rst.data.list, function (v) {
            if (v.areaLevel == 1) {
              if (data.data.province == v.areaId) {
                console.log(v.areaName)
                $scope.provinceName = v.areaName
              }
            } else if (v.areaLevel == 2) {
              if (data.data.city == v.areaId) {
                console.log(v.areaName)
                $scope.cityName = v.areaName
              }
            } else if (v.areaLevel == 3) {
              if (data.data.district == v.areaId) {
                console.log(v.areaName)
                $scope.districtName = v.areaName
              }
            }

          })

          if (!$scope.provinceName || !$scope.cityName || !$scope.districtName) {
            $scope.merApplyInfo.completeArea = '请选择地区';
            return
          } else {
            $scope.merApplyInfo.completeArea = $scope.provinceName + '-' + $scope.cityName + '-' + $scope.districtName
          }
          if ($stateParams.mapAddress) {
            $scope.newData.businessAddress = $stateParams.mapAddress
          }

        }, {}, 1)
      });
    } else {
      $scope.newData = Common.getCache('newData') || Common.getCache('merchantInfo');
      if ($stateParams.mapAddress) {
        $scope.newData.businessAddress = $stateParams.mapAddress
      }
    }
    $scope.$on('$ionicView.beforeEnter', function () {

      var nativeBroadcastMsg = null;
      window.broadcastMsgNum = function (obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
        if (typeof (obj) == "object") {
          nativeBroadcastMsg = obj.data;
        } else {
          nativeBroadcastMsg = angular.fromJson(obj).data;
        }
        $scope.$emit('msgNum', nativeBroadcastMsg);
      }
    });

    $scope.merApplyInfo = {
      city: '', //城市id
      province: '', //省id
      district: '', //区id
      completeArea: '请选择地区', //地址名
    }

    $scope.cityPickData = { // 地区选择器数据
      buttonClicked: function () {
        console.log($scope.cityPickData.areaId[0])
        $scope.newData.province = $scope.cityPickData.areaId[0];
        $scope.newData.city = $scope.cityPickData.areaId[1];
        $scope.newData.district = $scope.cityPickData.areaId[2];
        $scope.merApplyInfo.completeArea = $scope.cityPickData.areaData.join(' ');
      }
    };
    //选择地区
    $scope.areaChooseIndex = null
    $scope.areaChooseCategoryName = []
    $scope.areaChooseCategory = []
    $scope.areaChoose = function (d, index) {
      $scope.areaChooseIndex = index
      if ($scope.areaChooseCategoryName.length < 1) {
        $scope.areaChooseCategory = []
      }
      $scope.areaChooseCategoryName.push(d.areaName)
      $scope.merApplyInfo.completeArea = $scope.areaChooseCategoryName.join(" ");
      $scope.areaChooseCategory.push(d)
      $scope.setCityList(d.areaId)
    };

    function setAreaInfo() {
      if ($scope.areaChooseCategory.length < 1) {
        $scope.merApplyInfo.province = 0
        $scope.merApplyInfo.city = 0
        $scope.merApplyInfo.district = 0
      }
      $scope.areaChooseCategory.forEach(function (v, i) {
        if (v.areaLevel == 1) {
          $scope.merApplyInfo.province = v.areaId
        } else if (v.areaLevel == 2) {
          $scope.merApplyInfo.city = v.areaId
        } else {
          $scope.merApplyInfo.district = v.areaId
        }
      })
    }
    $scope.setCityList = function (id) {
      if ($scope.allCityList.length < 1) {
        $http({
          method: 'get',
          url: './data/city.json'
        }).then(function (rst) {
          $scope.allCityList = rst.data.list
          getList(id)
        })
        return
      }
      getList(id)

      function getList(id) {
        $scope.areaList = []
        $scope.allCityList.forEach(function (v) {
          if (v.parentAreaId == id) {
            $scope.areaList.push(v)
          }
        })
        setAreaInfo()
        if ($scope.areaList.length < 1) {
          $scope.merCounty = true;
        }
        setTimeout(function () {
          $ionicScrollDelegate.resize()
        }, 100)
      }
    }
    $scope.allCityList = []
    $http({
      method: 'get',
      url: './data/city.json'
    }).then(function (rst) {
      $scope.allCityList = rst.data.list
    })

    if (Common.getCache('picUrlList') == null) {
      Common.get('merchantAPI/merchant/pic/list', {}, function (data) {
        $scope.picArray = data.data;
        Common.setCache('picUrlList', data.data);
      }, {})
    } else {
      $scope.picArray = Common.getCache('picUrlList');
    }



    //获取token
    token = Common.getCache('Token');
    console.log(token);

    //图片预览
    $scope.showImg = function (_num) {
      $scope.currentPage = _num;
      $scope.totalPage = $scope.picArray.length;
      $scope.openModal();
    }

    $scope.slideHasChanged = function (index) {
      $scope.delegateHandle = $ionicSlideBoxDelegate;
      $scope.currentPage = index;
    };

    $scope.hideImg = function () {
      $scope.closeModal();
    }

    $scope.edit = true;

    $scope.editOK = function () {
      if (($scope.picArray == null || $scope.picArray.length < 1) && !$scope.edit) {
        Common.showAlert('温馨提示', '最少提交一张图片')
      }
      if (!$scope.edit) {
        Common.post('merchantAPI/merchant/pic/upload', {
          "picUrl": $scope.picArray
        }, function (data) {
          $scope.edit = !$scope.edit;
          Common.setCache('picUrlList', $scope.picArray);
          token.mainImage = $scope.picArray[0];
          if (token.role == 1) {
            token.photo = $scope.picArray[0];
          }
          $scope.newData.mainImage = $scope.picArray[0];
          Common.setCache('Token', token);
          Common.showAlert('', "信息已经保存成功");
        }, {}, 1)
      } else {
        $scope.edit = !$scope.edit;
      }
    }

    //图片预览
    $ionicModal.fromTemplateUrl('my-modal.html', {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function (modal) {
      $scope.modal = modal;
    });

    $scope.openModal = function () {
      $scope.modal.show();
    }

    $scope.closeModal = function () {
      $scope.modal.hide();
    }

    $scope.sortImage = function ($item, $partFrom, $partTo, $indexFrom, $indexTo) {
      $scope.picArray = $partFrom;
    }

    //图片删除
    $scope.deleteImg = function (_num) {
      console.log(_num)
      $scope.picArray.splice(_num, 1);
      console.log($scope.picArray)
      $scope.courrPage = $scope.courrPage - 1;
      $scope.totalPage = $scope.picArray.length;
      $scope.closeModal();

    }

    //环境图片上传
    $scope.addition = function () {
      Common.showLoading();
      Common.get('merchantAPI/merchant/pic/token', {}, function (_data) {
        Common.showLoading();
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            toast.show('图片上传成功！');
            $scope.picArray.push(data.data.imageUrl);
            $scope.$apply();
            Common.hideLoading();
          } else if (data.status == 2) {
            Common.hideLoading();
          } else {
            Common.hideLoading();
            toast.show("插件调用失败！");
          }
        }, "headImageUpload", [_data.data.accessKeyId, _data.data.accessKeySecret, _data.data.securityToken, "merchant/gl_24_agent/"])
      }, {});
    }


    //去定位
    $scope.goPosition = function () {
      Common.setCache('change', $scope.change)
      Common.setCache('newData',$scope.newData)
      $state.go('tab.mapSearch')
    }
    $scope.editPosition = function () {
      Common.setCache('change', $scope.change)
      Common.setCache('newData',$scope.newData)
      $state.go('tab.mapSearch')
    }
    //按钮编辑

    $scope.unChange = function () {
      //二级
      $('.select-value2').mPicker({
        level: 2,
        dataJson: level3,
        Linkage: true,
        rows: 6,
        idDefault: true,
        splitStr: '-',
        header: '<div class="mPicker-header">时间选择</div>',
        confirm: function (json) {
          console.info('当前选中json：', json);
          console.info('【json里有带value的情况】');
          var time = json.name
          var timeArry = time.split('-')
          var startTime = trimLeft(timeArry[0])
          var endTime = timeArry[1]
          if (startTime === endTime || (startTime == '00:00' && endTime == '23:00')) {
            $scope.newData.businessTime = '24小时营业'
          } else {
            $scope.newData.businessTime = json.name
          }

        }
      })

      function trimLeft(s) {
        if (s == null) {
          return "";
        }
        var whitespace = new String(" \t\n\r");
        var str = new String(s);
        if (whitespace.indexOf(str.charAt(0)) != -1) {
          var j = 0,
            i = str.length;
          while (j < i && whitespace.indexOf(str.charAt(j)) != -1) {
            j++;
          }
          str = str.substring(j, i);
        }
        return str;
      }
      //三级
      // $('.select-value').mPicker({
      //     level:3,
      //     dataJson: city3,
      //     Linkage:true,
      //     rows:6,
      //     idDefault:true,
      //     splitStr:'-',
      //     header:'<div class="mPicker-header">省市区选择</div>',
      //     confirm:function(json){
      //         $scope.newData.province=json.ids.split('-')[0]
      //         $scope.newData.city1=json.ids.split('-')[1]
      //         $scope.newData.district=json.ids.split('-')[2]
      //     }
      // })
      if (!$scope.change) {
        if (!$scope.newData.merchantShortName) {
          toast.show('请输入商户简称！');
          return;
        }
        if (!$scope.newData.offficeContact) {
          toast.show('请输入商户联系人！');
          return;
        }
        if (!$scope.newData.officeTel) {
          toast.show('请输入商户电话！');
          return;
        }
        if (!$scope.newData.businessTime) {
          toast.show('请选择商户营业时间！');
          return;
        }
        if (!$scope.newData.avgPrice) {
          toast.show('请输入人均消费！');
          return;
        }
        // if (!$scope.merApplyInfo.completeArea || $scope.merApplyInfo.completeArea == '请选择地区') {
        //   toast.show('请选择地区！');
        //   return;
        // }
        if (!$scope.newData.businessAddress) {
          toast.show('请输入商户地址！');
          return;
        }

        var reg = new RegExp(BQ_RANGES.join('|'), 'g');
        if (reg.test($scope.newData.merchantShortName) || reg.test($scope.newData.offficeContact) || reg.test($scope.newData.businessAddress) ||
          reg.test($scope.newData.merchantDesc)) {
          Common.showAlert('', "对不起，请勿输入特殊字符，请删除后重新保存！");
          return
        }

        if (!/^[\u4E00-\u9FA5A-Za-z0-9]+$/.test($scope.newData.merchantShortName)) {
          Common.showAlert('', "商户名称格式错误，请修改后重新提交！");
          return;
        } else if (!/^[\u4E00-\u9FA5A-Za-z]+$/.test($scope.newData.offficeContact)) {
          Common.showAlert('', "姓名格式错误，请修改后重新提交！");
          return;
        } else if (!/(^0[1-9][0-9]{1,2}[\-]?[2-9][0-9]{6,7}$)|^1[3-9][0-9]{9}/.test($scope.newData.officeTel)) {
          Common.showAlert('', "商户电话格式错误，请修改后重新提交！");
          return;
        } else if (!/^[1-9]\d*$/.test($scope.newData.avgPrice)) {
          Common.showAlert('', "人均消费只能输入数字，请修改后重新提交！");
          return;
        }
        $scope.change = !$scope.change;
        var myArr = [];
        console.log($scope.newData)
        $scope.data = {
          "merchantShortName": $scope.newData.merchantShortName,
          "offficeContact": $scope.newData.offficeContact,
          "officeTel": $scope.newData.officeTel,
          "businessTime": $scope.newData.businessTime,
          "businessAddress": $scope.newData.businessAddress,
          "merchantDesc": $scope.newData.merchantDesc,
          //        "specialService": myArr,
          "avgPrice": $scope.newData.avgPrice,
          "province": $scope.newData.province,
          "city": $scope.newData.city,
          "district": $scope.newData.district,
          "longitude": $stateParams.longitude,
          "latitude": $stateParams.latitude
        }

        Common.post('merchantAPI/merchant/update/info', $scope.data, function (data) {
          Common.clearCache('merchantInfo');
          Common.showAlert('', "信息已经保存成功");
          //Common.showAlert('保存成功', "修改的信息系统将在24小时内审核通过，请耐心等待！");
        }, {})
      } else {
        $scope.change = !$scope.change;
      }
    }
    $scope.goBack = function () {
      $state.go('tab.my_manager')
    }



    $scope.$on('$ionicView.beforeLeave', function () {
      $scope.closeModal();
    });

  });
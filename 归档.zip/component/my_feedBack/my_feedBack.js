var my_feedBack_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_feedBack', {
        url: '/my_feedBack',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_feedBack/my_feedBack.html',
                controller: 'my_feedBackCtrl'
            }
        }
    });
};
myapp.config(my_feedBack_myConfig);

angular.module('starter.my_feedBack',[])
.controller('my_feedBackCtrl', function($scope,Common,toast, $ionicHistory,$state,$interval) {
       $scope.gotoRuturn = function(){
         $state.go("tab.my_getting");            
       }
      $scope.text = {val:''};
        $scope.configg = false;
        $scope.$watch("text.val",function(){
            if($scope.text.val!=null&&$scope.text.val != ''){
                $scope.configg = true;
            }else{
                 $scope.configg = false;
            }
        })
       $scope.comfirm = function(){
            var tad = $scope.text.val;
              var reg = /^[^~`@#$%^&<>]*$/;
              var rege = new RegExp(BQ_RANGES.join('|'), 'g')
              if(rege.test(tad)){
                Common.showAlert("","对不起，请勿输入特殊字符，请删除后重新保存！")
                return;
              }
            if(tad!=null&&tad!=''){
                 if(reg.test(tad)){
                    if(tad.length<=200){
                        Common.post("merchantAPI/createFeedback",{
                        "content":$scope.text.val
                         },function(data){
                           toast.show("您的反馈己提交，我们会根据您的反馈优化产品，感谢支持！");
                           $state.go("tab.my_getting"); 
                         })
                     }else{
                        toast.show("字数限制200字内")
                    }  
            }else{
                toast.show("请输入中文，数字，英文")
            }
            }else{
                toast.show("请输入内容");
            }
           
       }

    $scope.$on('$ionicView.beforeEnter', function() {
        $scope.text = {val:''};
    });
});

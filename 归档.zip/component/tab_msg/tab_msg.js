var tab_msg_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.tab_msg', {
            url: '/tab_msg?{random}{type}',
            views: {
                'tab-index': {
                    templateUrl: 'component/tab_msg/tab_msg.html',
                    controller: 'tab_msgCtrl'
                }
            }
        });
};
myapp.config(tab_msg_myConfig);

angular.module('starter.tab_msg', [])
    .controller('tab_msgCtrl', function ($stateParams, $scope, $ionicHistory, toast, $state, $location, cordovaPlug, Common, $rootScope, $timeout, $ionicListDelegate, $ionicScrollDelegate) {
        //返回上一页
        $scope.goBack = function () {
            // window.history.back();
            $state.go('tab.index_new')
        };

        //$scope.selfId = Common.getCache('Token').operatorId;
        //初始化ion-item是否可移动；
        $scope.canSwipe = true;

        $scope.closeOption = function () {
            $ionicListDelegate.closeOptionButtons();
            $scope.canSwipe = !$scope.canSwipe;
        };
        //初始化tab按钮
        $scope.press = function (num) {
            $scope.navNum = num;
            $scope.canSwipe = true;
            $scope.edit = false;
        };

        if ($stateParams.type === 'payment_app') {
            $scope.press(0);
        } else {
            $scope.press(1);
        }

        $scope.info = Common.getCache('Token');
        //初始化数据
        $scope.sysLists = [];
        $scope.actLists = [];
        $scope.noMoreSysMsg = false;
        $scope.noMoreActMsg = false;
        $scope.master1 = { all: false };
        $scope.master2 = { all: false };
        var sysPage = 1,
            actPage = 1;

        $scope.nativeBroadcastMsg = { type: null };

        // //初始化ion-item是否可移动；
        // $scope.canSwipe = true;

        // $scope.closeOption = function() {
        //     $ionicListDelegate.closeOptionButtons();
        //     $scope.canSwipe = !$scope.canSwipe;
        // };

        $scope.loadMoreSys = function () {
            Common.post('merchantAPI/msg/getMsg', {
                "curPage": sysPage,
                "messageResultTypeList": [
                    "payment_app", 'gl_system'
                ],
                "pageSize": 30
            }, function (res) {
                if (res.data.list.length > 0) {
                    var syslist = []
                    res.data.list.forEach(function (item) {
                        if (item.message)
                            item.message = angular.fromJson(item.message);
                        if (item.message.systemType === 'payment_app') {
                            item.message.systemBody.tranBody.systemType = item.message.systemType;
                            item.message.systemBody.tranBody.tranType = item.message.systemBody.tranType;
                            item.message.systemBody.tranBody.id = item.id;
                            item.message.systemBody.tranBody.messageRead = item.messageRead;
                            syslist.push(item.message.systemBody.tranBody);  // 把后台给的json解析成一个对象。

                        } else {
                            syslist.push(item);  // 把后台给的json解析成一个对象。
                        }

                    });
                    $scope.sysLists = $scope.sysLists.concat(syslist);
                    console.log($scope.sysLists)
                    // $scope.sysLists = $scope.sysLists.slice(3,$scope.sysLists.length)
                }

                if (res.data.list.length < 10) {
                    $scope.noMoreSysMsg = false;
                } else {
                    $scope.noMoreSysMsg = true;
                }

                $scope.$broadcast('scroll.infiniteScrollComplete');
                sysPage++;
            })
            // cordovaPlug.CommonPL(function (res) {
            //
            // if (res.data.list.length > 0) {
            //     $scope.actLists = $scope.sysLists.concat(res.data.list);
            // }
            //
            // if (res.data.list.length < 10) {
            //     $scope.noMoreSysMsg = false;
            // } else {
            //     $scope.noMoreSysMsg = true;
            // }
            //
            // $scope.$broadcast('scroll.infiniteScrollComplete');
            // sysPage++;
            // }, 'getMessageList', ["payment_app", sysPage, 10]);
        };

        $scope.loadMoreSys();

        $scope.loadMoreAct = function () {

            Common.post('merchantAPI/msg/getMsg', {
                "curPage": actPage,
                "messageResultTypeList": [
                    "gl_payment", "gl_system"
                ],
                "pageSize": 30
            }, function (res) {
                if (res.data.list.length > 0) {
                    var actLists = []
                    res.data.list.forEach(function (item) {
                        if (item.message.systemType === 'gl_system') {
                            actLists.push(item);  // 把后台给的json解析成一个对象。
                        } else {
                            item.message = angular.fromJson(item.message);
                            item.message.id = item.id;
                            item.message.messageRead = item.messageRead;
                            actLists.push(item.message);  // 把后台给的json解析成一个对象。
                        }

                    });
                    $scope.actLists = $scope.actLists.concat(actLists);

                }

                if (res.data.list.length < 10) {
                    $scope.noMoreActMsg = false;
                } else {
                    $scope.noMoreActMsg = true;
                }

                $scope.$broadcast('scroll.infiniteScrollComplete');
                actPage++;
            })
            // cordovaPlug.CommonPL(function (res) {
            //     if (res.data.list.length > 0) {
            //         $scope.actLists = $scope.actLists.concat(res.data.list);
            //     }
            //
            //     if (res.data.list.length < 10) {
            //         $scope.noMoreActMsg = false;
            //     } else {
            //         $scope.noMoreActMsg = true;
            //     }
            //
            //     $scope.$broadcast('scroll.infiniteScrollComplete');
            //     actPage++;
            // }, 'getMessageList', ["gl_payment", actPage, 10]);

        };
        $scope.loadMoreAct();

        //全选方法
        $scope.checkAll = function (bool, arr) {
            if (bool) {
                for (var i in arr) {
                    arr[i].checked = true;
                }
            } else {
                for (var j in arr) {
                    arr[j].checked = false;
                }
            }
        };

        /*监听checkbox全选状态
         @param "sysLists"  监听系统消息列表checkbox
         @param "actLists"  监听推荐消息列表checkbox
         ***************************************************************/
        $scope.$watch('sysLists', function (newValue) {
            var count = 0;
            for (var i in newValue) {
                if (!newValue[i].checked) {
                    $scope.master1.all = false;
                    break;
                } else {
                    count++;
                }
            }
            for (var j in newValue) {
                if (newValue[j].checked) {
                    $scope.deleteblock1 = true;
                    break;
                } else {
                    $scope.deleteblock1 = false;
                }
            }
            if (newValue.length === count) {
                $scope.master1.all = true;
            }
            if (newValue.length === 0) {
                $scope.master1.all = false;
            }
        }, true);

        $scope.$watch('actLists', function (newValue) {
            var count = 0;
            for (var i in newValue) {
                if (!newValue[i].checked) {
                    $scope.master2.all = false;
                    break;
                } else {
                    count++;
                }
            }
            for (var j in newValue) {
                if (newValue[j].checked) {
                    $scope.deleteblock2 = true;
                    break;
                } else {
                    $scope.deleteblock2 = false;
                }
            }
            if (newValue.length === count) {
                $scope.master2.all = true;
            }
            if (newValue.length === 0) {
                $scope.master2.all = false;
            }
        }, true);


        /*批量删除方法 & 单个删除方法 & 设置已读方法
         @ deleteSysLists  批量删除系统消息
         @ deleteActLists  批量删除推荐消息
         @ singleDel 单个删除方法
         @ setMessageHasRead 设置已读
         ***************************************************************/
        $scope.deleteSysLists = function () {
            if ($scope.sysLists.length == 0) {
                toast.show('暂无消息');
                return;
            }
            var newArr = [];
            var nativeArr = [];
            for (var i in $scope.sysLists) {
                if ($scope.sysLists[i].checked) {
                    nativeArr.push($scope.sysLists[i].id);
                } else {
                    newArr.push($scope.sysLists[i]);
                }
            }
            if (nativeArr.length === 0) {
                return;
            }

            Common.post('merchantAPI/msg/delete', { idList: nativeArr }, function () {
                $scope.sysLists = newArr;
                if (newArr.length === 0) {
                    $scope.edit = false;
                    $scope.canSwipe = true;
                    sysPage = 1
                    $scope.loadMoreSys();
                }
            });
            // cordovaPlug.CommonPL(function () {
            //     toast.show('删除成功');
            // }, 'deleteMessageByBatch', ['payment_app', nativeArr.join(',')]);

        };

        $scope.deleteActLists = function () {
            if ($scope.actLists.length === 0) {
                toast.show('暂无消息');
                return;
            }
            var newArr = [];
            var nativeArr = [];
            for (var i in $scope.actLists) {
                if ($scope.actLists[i].checked) {
                    nativeArr.push($scope.actLists[i].id);
                } else {
                    newArr.push($scope.actLists[i]);
                }
            }

            if (nativeArr.length === 0) {
                return;
            }
            Common.post('merchantAPI/msg/delete', { idList: nativeArr }, function () {
                $scope.actLists = newArr;
                if (newArr.length === 0) {
                    $scope.edit = false;
                    $scope.canSwipe = true;
                    actPage = 1;
                    $scope.loadMoreAct();
                }
            })
            // cordovaPlug.CommonPL(function () {
            //     toast.show('删除成功');
            // }, 'deleteMessageByBatch', ['gl_payment', nativeArr.join(',')]);

        };

        $scope.singleDel = function (idx, arr, ID, type) { //idx为数组下标， arr是目标数组， ID是消息对象的id值

            // cordovaPlug.CommonPL(function () {
            //     toast.show('删除成功');
            // }, 'deleteMessageByBatch', [type, ID.toString()]);
            Common.post('merchantAPI/msg/delete', { idList: [ID] }, function () {
                arr.splice(idx, 1);
            })
        };

        $scope.setMessageHasRead = function (list) {
            if (list.messageRead != 1) {
                Common.post('merchantAPI/msg/readMsg', { id: list.id }, function () {

                }, {});
                list.messageRead = 1;
            }

            if (list.tranType == '1000' || list.tranType == '1100' || list.tranType == '2000' || list.tranType == '2100' || list.tranType == '3000' || list.tranType == '3100' || list.tranType == '3200' || list.tranType == '3300') {
                Common.setCache('msg_pay', list);
                // cordovaPlug.CommonPL(function () {
                //
                // }, 'setMessageHasRead', ['payment_app', list.id]);
                if ((list.tranType == '1100' || list.tranType == '1000') && (list.orderType == 2 || list.orderType == 5)) {
                    $state.go('tab.msg_reward');
                } else {
                    $state.go('tab.msg_pay');
                }
            }
        };

        $scope.setMessageHasRead2 = function (list) {
            console.log(list)
            //list.status = 1;
            // cordovaPlug.CommonPL(function () {
            //
            // }, 'setMessageHasRead', ['gl_payment', list.id]);

            if (list.messageRead != 1) {
                Common.post('merchantAPI/msg/readMsg', { id: list.id }, function () {
                 
                }, {});
                list.messageRead = '01';
            } if (list.systemType === 'gl_system') {
                return $state.go('tab.msg_system', {messageRead:list.messageRead});
            }

            if (list.isFirstTrade === true) {
                return false;   // 激活粉丝没有二级
            } else if (list.dataType) {  //dataType='service_fee_return' 时是服务费返还消息，不需要再下一步
                return false;
            } else {
                if (list.isOwnerShop === false) {
                    return false;  // 不是本店消费没有2级
                } else {
                    $state.go('tab.msg_profit', { profit: list.ownerProfitAmount, payId: list.payId });
                }
            }

        };
        $scope.$on('$ionicView.beforeLeave', function () {
            window.notifyMsg = function (obj) {
                var type;
                if (typeof (obj) == "object") {
                    type = obj.data.type;
                } else {
                    type = angular.fromJson(obj).data.type;
                }
                $state.go('tab.tab_msg', { random: new Date().getTime(), type: type })
            }
        });


        $scope.$on('$ionicView.beforeEnter', function () {

            window.notifyMsg = function (obj) {
                var type;
                if (typeof (obj) == "object") {
                    type = obj.data.type;
                } else {
                    type = angular.fromJson(obj).data.type;
                }
                if (location.href.indexOf('/tab_msg') !== -1) {
                    if (type === 'payment_app') {
                        $scope.press(0);
                        $scope.$apply();
                    } else {
                        $scope.press(1);
                        $scope.$apply();
                    }
                } else {
                    $state.go('tab.tab_msg', { random: new Date().getTime(), type: type })
                }
            };

            // setTimeout(function () {
            //     broadcastMsgNum({
            //         data: {
            //             type: 'payment_app'
            //         }
            //     })
            // },5000);

            var async = false;
            window.broadcastMsgNum = function (obj) { //obj参数为APP返回的字符串，{"num":1,"type":0||1},num为未读消息条数，type是消息类型
                if (async) {
                    return;
                } else {
                    receiveMsg()
                }
            };

            function receiveMsg() {
                async = true;
                Common.post('merchantAPI/msg/getMsg', {
                    "curPage": 1,
                    "messageResultTypeList": [
                        'payment_app', 'gl_system'
                    ],
                    "pageSize": 30
                }, function (res) {
                    var syslist1 = [];
                    res.data.list.forEach(function (item) {
                        item.message = angular.fromJson(item.message);
                        item.message.systemBody.tranBody.systemType = item.message.systemType;
                        item.message.systemBody.tranBody.tranType = item.message.systemBody.tranType;
                        item.message.systemBody.tranBody.id = item.id;
                        item.message.systemBody.tranBody.messageRead = item.messageRead;
                        syslist1.push(item.message.systemBody.tranBody);  // 把后台给的json解析成一个对象。
                    });
                    $scope.sysLists = syslist1;
                    sysPage = 2;
                }, {}
                );
                Common.post('merchantAPI/msg/getMsg', {
                    "curPage": 1,
                    "messageResultTypeList": [
                        'gl_payment', 'gl_system'
                    ],
                    "pageSize": 30
                }, function (res) {
                    var actLists1 = [];
                    res.data.list.forEach(function (item) {

                        item.message = angular.fromJson(item.message);
                        item.message.id = item.id;
                        item.message.messageRead = item.messageRead;
                        actLists1.push(item.message);  // 把后台给的json解析成一个对象。
                    });
                    $scope.actLists = actLists1;
                    actPage = 2;
                }, {}
                );
                $ionicScrollDelegate.scrollTop();
                $scope.nativeBroadcastMsg.type = null;
                $timeout(function () {
                    async = false;
                }, 2000)
            }
        })
            ;
    })
    .filter('payMsgContent', function () {
        return function (type, obj) {
            switch (type) {
                case '1000':
                    return "收到１笔来自" + obj.user + "，金额为" + parseFloat(obj.totalAmt).toFixed(2) + "元付款";
                case '1100':
                    // superior: 01下级  00上级
                    if (obj.superior == '01') {
                        if (obj.orderType == 1 || obj.orderType == 7) {
                            return "收到１笔来自" + obj.user + "，金额为" + parseFloat(obj.totalAmt).toFixed(2) + "元付款";
                        } else if (obj.orderType == 2 || obj.orderType == 5) {
                            if (obj.cashAmount == 0 || !obj.cashAmount) {
                                return "您收到" + obj.user + "打赏" + parseFloat(obj.beanAmount).toFixed(2) + "乐豆";
                            } else if (obj.beanAmount == 0 || !obj.beanAmount) {
                                return "您收到" + obj.user + "打赏" + parseFloat(obj.cashAmount).toFixed(2) + "元现金，现金明天就能看到哦";
                            } else if (obj.cashAmount || obj.beanAmount) {
                                return '您收到' + obj.user + '打赏' + obj.beanAmount + '乐豆和' + obj.cashAmount + '元现金，现金明天就能看到哦';
                            }
                        }
                    } else {
                        return obj.operatorName + '收款成功，金额为' + parseFloat(obj.totalAmt).toFixed(2);
                    }
                    break;
                case '1102':
                    return "收到１笔来自" + obj.user + "，金额为" + parseFloat(obj.totalAmt).toFixed(2) + "元打赏";
                case '2000':
                    return '已成功撤销１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款';
                case '2001':
                    return '已成功撤销１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款';
                case '2100':
                    if (obj.oneSelf === '00') { // 00标识本人，01非本人
                        return '已成功撤销１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款';
                    } else {
                        return obj.refundOperatorName + '已成功撤销１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款';
                    }
                case '2101':
                    return '已成功撤销１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款';
                case '3000':
                    return '１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款，已退款成功';
                case '3100':
                    return '１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款，已退款成功';
                case '3200':
                    return '１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款，已退款成功';
                case '3300':
                    return '１笔来自' + obj.user + '，金额为' + parseFloat(obj.totalAmt).toFixed(2) + '元付款，已退款成功';
                default:
                    return "点击查看详情";
            }
        };
    })

    ;

var mine_aboutGL_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.mine_aboutGL', {
        url: '/mine_aboutGL',
        views: {
            'tab-mine': {
                templateUrl: 'component/mine_aboutGL/mine_aboutGL.html',
                controller: 'mine_aboutGLCtrl'
            }
        }
    });
};
myapp.config(mine_aboutGL_myConfig);

angular.module('starter.mine_aboutGL',[])
.controller('mine_aboutGLCtrl', function($scope,actionSheetItem,Common,$http,$state,cordovaPlug,$timeout){
    $scope.uploadShow = false;
    $scope.iosShow = false;
    var isClick = false;
    $scope.showTel = function(){
        actionSheetItem.showTel("4000200365");
    };
    $scope.gotoUpload = function(){
        if($scope.uploadShow){
            if(!isClick){
                isClick = true;
                cordovaPlug.CommonPL(function(){}, "updateApk", []);
                $timeout(function(){
                    isClick = false;
                },500);
            } 
        }else{
            Common.showAlert("升级提醒","暂无更新")
        }
    };
    var myClientId = Common.getCache('getDeviceIdAndClientId').ClientId;
    if(myClientId.indexOf('android') != -1){
        $scope.iosShow = true;
        $http.get('https://upgrade.365gl.com/upgrade/config/android/glMerchant-upgrade.json').success(function(_data){
            $scope.myCode = _data.version;
            cordovaPlug.CommonPL(function(data){
               if(data.status == 1){
                    $scope.newClientVer = data.data.versionName;
                   if(data.data.versionCode < _data.lastVersion){
                        $scope.uploadShow = true;
                        $scope.$apply();
                   }
               }else{
                    toast.show("插件调用失败！");
                }
            }, "getVersionCode", []);
        })
    } else {
            cordovaPlug.CommonPL(function(data) {
                if (data.status == 1) {
                    $scope.newClientVer = data.data.versionName;
                    $scope.$apply();
                } else {
                    toast.show("插件调用失败！");
                }
            }, "getVersionCode", [])
        }
    $scope.gotoShare = function(){
        Common.glShare('分享给乐商户','体验跨界收益，时时惊喜，更好的商户利润体系','https://register-cdn.365gl.com/register/b/image/le.png','https://register-cdn.365gl.com/register/b/bDownload.html');
    };
    $scope.$on('$ionicView.beforeEnter', function(){

    });
});

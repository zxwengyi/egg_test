var mine_chooseBranchBank_myConfig = function($stateProvider) {
  $stateProvider
    .state('tab.mine_chooseBranchBank', {
      url: '/mine_chooseBranchBank/:bankName/:city/:province?{:bankIndex,:userName,:idNo,:cardNo,:bankId,:icon,:color,:areaId}',
      views: {
        'tab-mine': {
          templateUrl: 'component/mine_chooseBranchBank/mine_chooseBranchBank.html',
          controller: 'mine_chooseBranchBankCtrl'
        }
      }
    });
};
myapp.config(mine_chooseBranchBank_myConfig);

angular.module('starter.mine_chooseBranchBank', [])
  .controller('mine_chooseBranchBankCtrl', function($scope, $timeout, $stateParams, $state, Common, toast) {

    $scope.bankList = [];
    var curPage = 1,
      pageSize = 15,
      timer = null;
    $scope.inputData = {
      kw: '',
      bankName: $stateParams.bankName,
      city: $stateParams.city,
      province: $stateParams.province
    }
    $scope.showList = true;
    $scope.isHasMore = true;
    $scope.hasMore = true;
    $scope.searchHasMore = true;
    $scope.hasData = false;
    // $scope.lists = $scope.bankList.splice(curPage, pageSize);
    //银行编码
    $scope.bankId = $stateParams.bankId ? $stateParams.bankId : '';
    $scope.areaId = $stateParams.areaId ? $stateParams.areaId : '';


    //上拉加载数据
    $scope.loadMore = function() {
      $scope.getList();
    }

    $scope.getList = function() {
      timer = $timeout(function() {
        Common.post("merchantAPI/operator/bank/branch/list", {
          "areaId": parseInt($scope.areaId),
          "bankNo": $scope.bankId,
          "bankName": $scope.inputData.kw,
          "curPage": curPage++,
          "pageSize": pageSize
        }, function(data) {
          Common.hideLoading();
          $scope.bankList = $scope.bankList.concat(data.data.list);
          $scope.hasData = $scope.bankList.length ? false : true;
          if (data.data.list.length < pageSize) {
            $scope.isHasMore = false;
            curPage = 1 //如果滑到底，点击搜索，curPage会显示最后一页的页号
          }
          $scope.$broadcast('scroll.infiniteScrollComplete');
          console.log("curPage:" + curPage + ",pageSize:" + pageSize + ",data.length:" + data.data.list.length)
          //console.dir('data:' + data.data.list[0].name);//中国建设银行股份有限公司深圳市分行
        }, {})
      }, 300);

      // $scope.$on("$destroy", function() {
      //   $timeout.cancel(timer); //清除配置,不然scroll会重复请求 
      // });
    }

    Common.showLoading();
    $scope.getList();

    var loop;
    $scope.toSearch = function() {
      $scope.bankList = []
      curPage = 1
      $scope.isHasMore = true;
      clearTimeout(loop)
      loop = setTimeout(function() {
        Common.showLoading()
        $scope.getList()
      }, 0)
    }

    $scope.clearInput = function() {
      $scope.isHasMore = true;
      curPage = 1
      $scope.inputData.kw = '';
    }

    $scope.goBack = function() {
      window.history.back();
    }



    //查询支行信息
    $scope.chooseBranch = function(i, e,branchBankName) {
      angular.element(e.target.parentElement.parentElement).find("li").removeClass("active");
      angular.element(e.target.parentElement.parentElement).find("li").eq(i).addClass("active");
      var myParam = {
        'bankName': $stateParams.bankName,
        'hasCard': true,
        'icon': $stateParams.icon ? $stateParams.icon : '',
        'color': $stateParams.color ? $stateParams.color : '',
        'branchBankName': $scope.bankList[i].name,
        'branchBankNo': $scope.bankList[i].bankNo
      }
      Common.setCache('setParam', myParam);
      $timeout(function() {
        $state.go('tab.mine_addBankCard');
        angular.element(e.target.parentElement.parentElement).find("li").removeClass("active");
      }, 100)
    }

    $scope.$on('$ionicView.beforeEnter', function() {});
  });
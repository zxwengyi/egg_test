var mine_addBankCard_myConfig = function ($stateProvider) {
    $stateProvider
        .state('tab.mine_addBankCard', {
            url: '/mine_addBankCard',
            views: {
                'tab-mine': {
                    templateUrl: 'component/mine_addBankCard/mine_addBankCard.html',
                    controller: 'mine_addBankCardCtrl'
                }
            }
        });
};
myapp.config(mine_addBankCard_myConfig);

angular.module('starter.mine_addBankCard', [])
    .controller('mine_addBankCardCtrl', function ($scope, $stateParams, Common, toast, $timeout, $interval, $ionicScrollDelegate, $state, actionSheetItem, $rootScope, cordovaPlug) {
        $scope.inputData = {
            userName: '',
            idNo: '',
            cardNo: '',
            // bankName: '请选择银行名称',
            branchBankName: '请选择银行名称',
            icon: '',
            vCode: ''
        }
        $scope.goBack = function () {
            if (Common.getCache("setParam")) $state.go("tab.my_manager")
            else if (Common.getCache('cjc_gotoAdd')) {
                $state.go("tab.mine_myWallet");
                Common.clearCache('cjc_gotoAdd')
            }
            // if(Common.getCache("setParam")) $state.go("tab.mine_myWallet")
            else window.history.back();
            Common.clearCache("setParam")
            $scope.inputData = {
                userName: '',
                idNo: '',
                cardNo: '',
                // bankName: '请选择银行名称',
                branchBankName: '请选择银行名称',
                icon: '',
                vCode: ''
            }
        }


        //点亮下一步按钮
        $scope.$watch('inputData', function () {
            if ($scope.inputData.userName || $scope.inputData.idNo || $scope.inputData.cardNo || $scope.inputData.bankName != '请选择银行名称') {
                $scope.filled = true;
            } else {
                $scope.filled = false;
            }
        }, true)
        /*$scope.$watch('inputData.userName', function() {
          $scope.$watch('inputData.idNo', function() {
            $scope.$watch('inputData.cardNo', function() {
              $scope.$watch('inputData.bankName', function() {
                //TODO:验证输入
                if ($scope.inputData.userName || $scope.inputData.idNo || $scope.inputData.cardNo || $scope.inputData.bankName != '请选择银行名称') {
                  $scope.filled = true;
                } else {
                  $scope.filled = false;
                }
              })
            })
          })
        })*/


        //点亮完成按钮
        // $scope.$watch('inputData.vCode', function() {
        //   if (/^\d{6}$/.test($scope.inputData.vCode)) {
        //     $scope.submit = true;
        //   } else {
        //     $scope.submit = false;
        //   }
        // })
        $scope.gotoCard = function () {
            console.log("调用摄像头")
            cordovaPlug.CommonPL(function (data) {
                if (data.status == 1) {
                    $scope.inputData.cardNo = data.data.code;
                    $scope.$apply();
                } else {
//        toast.show("插件调用失败！");
                }
            }, "scanBank", [])
        }
        $scope.chooseBankName = function () {
            $state.go("tab.mine_chooseBank")
            // $state.go("tab.mine_chooseBank", {
            //   bankName: $scope.inputData.bankName,
            //   idNo: $scope.inputData.idNo,
            //   userName: $scope.inputData.userName,
            //   cardNo: $scope.inputData.cardNo
            // });
        }

        //银行卡每4位插入空格
        angular.element(document.getElementById("cardNo")).on('keyup', function (e) {
            //只对输入数字时进行处理
            if ((e.which >= 48 && e.which <= 57) ||
                (e.which >= 96 && e.which <= 105)) {
                //获取当前光标的位置
                var caret = this.selectionStart
                //获取当前的value
                var value = this.value
                //从左边沿到坐标之间的空格数
                var sp = (value.slice(0, caret).match(/\s/g) || []).length
                //去掉所有空格
                var nospace = value.replace(/\s/g, '')
                //重新插入空格
                var curVal = this.value = nospace.replace(/(\d{4})/g, "$1 ").trim()
                //从左边沿到原坐标之间的空格数
                var curSp = (curVal.slice(0, caret).match(/\s/g) || []).length
                //修正光标位置
                this.selectionEnd = this.selectionStart = caret + curSp - sp

            }
        })

        /*$scope.$watch('inputData.vCode', function() {
          var reg = /^\d{6}$/;
          if (reg.test($scope.inputData.vCode)) {
            $scope.submit = true;
          } else {
            $scope.submit = false;
          }
        })*/


        var isCardID = function (sId) {
            var regIdCard = /^(^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$)|(^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])((\d{4})|\d{3}[Xx])$)$/;
            if (!regIdCard.test(sId)) return "请输入正确格式的身份证号";
            return true;
        }

        //完成添加
        $scope.finishAddCard = function () {
            if (!$scope.filled) return
            if (!$scope.inputData.userName) {
                toast.show('请输入银行开户名')
                return
            }
            if (isCardID($scope.inputData.idNo) != true) {
                toast.show(isCardID($scope.inputData.idNo));
                return;
            }
            if (!$scope.inputData.cardNo) {
                toast.show('请输入银行卡号')
                return
            }
            if ($scope.inputData.bankName == '请选择银行名称') {
                toast.show('请选择银行名称')
                return
            }
            //向后台发送请求/
            Common.post("merchantAPI/operator/bank/accountno/add", {
                "bankAccountNo": $scope.inputData.cardNo.replace(/\s+/g, ""),
                "bankAccountName": $scope.inputData.userName.replace(/\s+/g, ""),
                "certNo": $scope.inputData.idNo.replace(/\s+/g, ""), //身份证号
                "bankName": $scope.inputData.branchBankName ? $scope.inputData.branchBankName.replace(/\s+/g, "") : '',
                "bankNo": $scope.inputData.branchBankNo ? $scope.inputData.branchBankNo.replace(/\s+/g, "") : '',
                // 'bankAccountType': '01'
            }, function (data) {
                Common.setCache("user_bankCardName", $scope.inputData.bankName);
                Common.setCache("user_bankCardNo", $scope.inputData.cardNo);
                Common.setCache("user_bankCardIcon", $scope.inputData.icon ? $scope.inputData.icon : '');
                Common.setCache("user_bankCardColor", $scope.inputData.color ? $scope.inputData.color : '');
                /*$state.go('tab.mine_myBankCard', {
                  bankName: $scope.inputData.bankName, //**银行
                  userName: $scope.inputData.userName,
                  cardNo: $scope.inputData.cardNo,
                  hasAddCard: true,
                  icon: $stateParams.icon ? $stateParams.icon : '',
                  color: $stateParams.color ? $stateParams.color : ''
                })*/
                toast.show("绑卡完成！");
                Common.clearCache("setParam");
                $scope.inputData = {
                    userName: '',
                    idNo: '',
                    cardNo: '',
                    // bankName: '请选择银行名称',
                    branchBankName: '请选择银行名称',
                    icon: '',
                    vCode: ''
                }
                $state.go('tab.mine_myBankCard')
            }, {})
        }


        $scope.$on('$ionicView.beforeEnter', function () {
            var timer = '';
            $scope.submit = false;
            $scope.showList = false;
            $scope.filled = false;
            if (Common.getCache('setParam')) {
                $scope.inputData.bankName = Common.getCache('setParam').bankName;
                $scope.inputData.icon = Common.getCache('setParam').icon;
                $scope.inputData.bankNo = Common.getCache('setParam').bankNo;
                $scope.inputData.branchBankName = Common.getCache('setParam').branchBankName;
                $scope.inputData.branchBankNo = Common.getCache('setParam').branchBankNo;
                $scope.filled = true;
            }
//    if ($scope.inputData.cardNo == '' && $scope.inputData.bankName == '请选择银行名称') {
//      $timeout(function() {
//        $scope.gotoCard();
//      }, 100)
//    }
        });

    });
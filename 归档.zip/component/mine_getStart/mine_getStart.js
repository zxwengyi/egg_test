var mine_getStart_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.mine_getStart', {
        url: '/mine_getStart',
        views: {
            'tab-mine': {
                templateUrl: 'component/mine_getStart/mine_getStart.html',
                controller: 'mine_getStartCtrl'
            }
        }
    });
};
myapp.config(mine_getStart_myConfig);

angular.module('starter.mine_getStart',[])
.controller('mine_getStartCtrl', function($scope) {
    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

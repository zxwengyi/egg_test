/**
 * 基础js类型拓展
 * Created by ozx.
 */
String.prototype.format = function(args) {
    var result = this;
    if (arguments.length > 0) {
        if (arguments.length == 1 && typeof(args) == "object") {
            for (var key in args) {
                if (args[key] != undefined) {
                    result = result.replace(new RegExp("({" + key + "})", "g"), args[key]);
                }
            }
        } else {
            for (var i = 0; i < arguments.length; i++) {
                if (arguments[i] != undefined) {
                    result = result.replace(new RegExp("({)" + i + "(})", "g"), arguments[i]);
                }
            }
        }
    }
    return result;
};

Date.prototype.format = function(AddDayCount) {
    var count = AddDayCount || 0;
    this.setDate(this.getDate() + count); //获取AddDayCount天后的日期
    var y = this.getFullYear();
    var m = this.getMonth() + 1; //获取当前月份的日期
    m = m < 10 ? '0' + m : m;
    var d = this.getDate();
    d = d < 10 ? '0' + d : d;
    return y + "-" + m + "-" + d;
};
Date.prototype.getMonthEnd = function() {
    return new Date(this.getFullYear(),this.getMonth()+1).toJSON().substring(0,10);
}

Date.prototype.getMonthFirst = function() {
    return new Date(this.getFullYear()+'/'+(this.getMonth()+1)+"/01").toJSON().substring(0,10);
}

Date.prototype.getPreMonth=function () {
    var year = this.getFullYear();
    var month = this.getMonth()+1;
    return new Date(year+'/'+month+'/01').setDate(-1)
}

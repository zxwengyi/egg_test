var withdrawal_list_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.withdrawal_list', {
        url: '/withdrawal_list',
        views: {
            'tab-mine': {
                templateUrl: 'component/withdrawal_list/withdrawal_list.html',
                controller: 'withdrawal_listCtrl'
            }
        }
    });
};
myapp.config(withdrawal_list_myConfig);

angular.module('starter.withdrawal_list',[])
.controller('withdrawal_listCtrl', function($scope,Common) {
    $scope.$on('$ionicView.beforeEnter', function() {
        Common.get("merchantAPI/withdraw/query/user",{
            "curPage":1,
            "pageSize":100
        },function(data){
            $scope.itemList = data.data;
            Common.setCache('earningsList',data.data);
        },{})
    });
});

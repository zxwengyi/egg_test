var my_manager_myConfig = function ($stateProvider) {
  $stateProvider
    .state('tab.my_manager', {
      url: '/my_manager',
      views: {
        'tab-mine': {
          templateUrl: 'component/my_manager/my_manager.html',
          controller: 'my_managerCtrl'
        }
      }
    });
};
myapp.config(my_manager_myConfig);
angular.module('starter.my_manager', [])
  .controller('my_managerCtrl', function ($scope, Common, $state, $rootScope, cordovaPlug, toast, $http) {
   
    //上传头像--店长/店员
    var hasClickBoo = false;
    $scope.uploadImg = function (data) {
      if ($scope.information.role == 1 || $scope.information.role == 5 || $scope.information.role == 6) return;
      if (!hasClickBoo) {
        hasClickBoo = true;
        Common.get('merchantAPI/merchant/pic/token', {}, function (_data) {
          cordovaPlug.CommonPL(function (data) {
            if (data.status == 1) {
              Common.showLoading();
              Common.post("merchantAPI/user/photo", {
                'url': data.data.imageUrl
              }, function () {
                $scope.information.photo = data.data.imageUrl;
                Common.setCache('Token', $scope.information);
                toast.show('头像上传成功！');
                Common.hideLoading();
                $scope.$apply();
              }, function () {
                Common.hideLoading();
              });
            }
          }, "headImageUpload", [_data.data.accessKeyId, _data.data.accessKeySecret, _data.data.securityToken, 'user/' + Common.getCache('Token').userId])
          hasClickBoo = false;
        }, function () {
          hasClickBoo = false;
        })
      }
    }
    // console.log($scope.picArray);
    $scope.$on('$ionicView.beforeLeave', function () {
      $scope.showTipBoo = false;
    })
    $scope.$on('$ionicView.beforeEnter', function () {
      $scope.information = Common.getCache('Token');
        Common.get('merchantAPI/merchant/info', {}, function (data) {
            $rootScope.discountRate = data.data.discountRate / 10;
        })
      // $rootScope.discountRate = $scope.information.discountRate / 10;
      if ($scope.information.linkType == 1) $scope.adminBoo = true;
    
      if (Common.getCache('picUrlList') == null) {
        Common.get('merchantAPI/merchant/pic/list', {}, function (data) {
          if (data.data != null) {
            if (data.data.length > 8) data.data.length = 8;
            $scope.picArray = data.data;
            $scope.myWidth = {
              "width": 1.84 * $scope.picArray.length + "rem"
            }
            console.log($scope.myWidth);
          }
          Common.setCache('picUrlList', data.data);
        }, {}, 1);
      } else {
        $scope.picArray = Common.getCache('picUrlList');
        if ($scope.picArray != null) {
          $scope.myWidth = {
            "width": 1.84 * $scope.picArray.length + "rem"
          }
          //console.log($scope.myWidth);
        }
      }

      $scope.count = function () {
        Common.get("merchantAPI/redenvelope/operateSum", {}, function (data) {
          $scope.countNum = data.data.operateSum;
        }, {})
      }
      $scope.count();

    });
    $scope.toMyInformation = function () { 
      Common.clearCache('change')
      Common.clearCache('newData')
      $state.go('tab.my_information')
    }
  });
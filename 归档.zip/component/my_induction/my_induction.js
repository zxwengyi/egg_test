var my_induction_myConfig = function($stateProvider){
    $stateProvider
    .state('tab.my_induction', {
        url: '/my_induction',
        views: {
            'tab-mine': {
                templateUrl: 'component/my_induction/my_induction.html',
                controller: 'my_inductionCtrl'
            }
        }
    });
};
myapp.config(my_induction_myConfig);

angular.module('starter.my_induction',[])
.controller('my_inductionCtrl', function($scope,$ionicScrollDelegate) {

      $scope.bossSelect = false;
      $scope.shop = false;
      $scope.assistant = false;
      $scope.buttonNum = false;
      $scope.goal = function(num){
           // $scope.buttonNum = true;
            $scope.scrollTop();
            if(num==0){
                $scope.bossSelect = !$scope.bossSelect;
                $scope.assistant = false;
                $scope.shop = false;
            } else if (num==1) {
              $scope.shop = !$scope.shop;
              $scope.assistant = false;
               $scope.bossSelect = false;
            } else if(num==2) {
                $scope.assistant = !$scope.assistant;
                $scope.shop = false;
                $scope.bossSelect = false;
            }

         //切换下一个按钮 
        }

        $scope.swtcher = function(){
           $scope.buttonNum = true; 
           $scope.scrollTop();
          if($scope.bossSelect){
            $scope.bossSelect = false;
            $scope.shop = true;
            $scope.assistant = false;
          }else if($scope.shop){
            $scope.bossSelect = false;
            $scope.shop = false;
            $scope.assistant = true;
          }else{
            $scope.bossSelect = true;
            $scope.shop = false;
            $scope.assistant = false;
          }
        }


          //点击回到顶部
         $scope.scrollTop = function() {
            $ionicScrollDelegate.scrollTop();
          };

    $scope.$on('$ionicView.beforeEnter', function() {

    });
});

#!/bin/sh
script/a_init.sh
echo "生成配置文件"
gulp sass-debug
gulp scripts-debug
echo "编译文件"
cp -rf ./component css data img js lib template ./config.js ./index.html ../www/b_h5/uat
echo "复制文件"
sed -i '' 's/isDebug = true/isDebug = false/g' ../www/b_h5/uat/js/all.min.js
sed -i '' 's/https:\/\/bapp.365gl.com\//https:\/\/test.365gl.com\/bfront\//g' ../www/b_h5/uat/js/all.min.js
sed -i '' 's/https:\/\/locbapp.365gl.com\//https:\/\/test.365gl.com\/bfront\//g' ../www/b_h5/uat/js/all.min.js
echo "关闭debug模式"

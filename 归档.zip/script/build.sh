#!/bin/sh
script/init.sh
echo "生成配置文件"
gulp sass-debug
gulp scripts-debug
echo "编译文件"
cp -rf ./component/ css/ data/ img/ js/ lib/ template/ ./config.js ./index.html ../www2/b_www
echo "复制文件"
sed -i 's/isDebug = true/isDebug = false/g' ../www2/b_www/js/all.min.js
sed -i 's/https:\/\/bapp.365gl.com\//https:\/\/locbapp.365gl.com\//g' ../www2/b_www/js/all.min.js
echo "关闭debug模式"
cd ../www2/b_www
git status
git add .
git commit -m "打包"
git push
echo "git上传成功"
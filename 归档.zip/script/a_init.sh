#!/bin/sh
touch config.js
echo "var myapp = angular.module('starter', ['ionic','starter.services','angular-sortable-view','toast','ionic-citypicker'" > config.js
dir=$(ls -l ./component |awk '/^d/ {print $NF}')
for i in $dir
do
    echo ",'starter.$i'" >> config.js
done   

echo "]);" >> config.js
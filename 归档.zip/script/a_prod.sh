#!/bin/sh
script/a_init.sh
echo "生成配置文件"
sed -i '' 's/isDebug = true/isDebug = false/g' ./js/services.js
echo "关闭debug模式"
gulp imagemin
gulp sass
gulp scripts
echo "编译文件"
cp -rf ./img ../www/b_h5/prod
cp -rf ./dist/* ../www/b_h5/prod
echo "复制文件"
sed -i '' 's/https:\/\/locbapp.365gl.com\//https:\/\/bapp.365gl.com\//g' ../www/b_h5/prod/js/all.min.js
sed -i '' 's/https:\/\/test.365gl.com\/bfront\//https:\/\/bapp.365gl.com\//g' ../www/b_h5/prod/js/all.min.js
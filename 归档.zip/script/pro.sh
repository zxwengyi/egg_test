#!/bin/sh
script/init.sh
echo "生成配置文件"
sed -i 's/isDebug = true/isDebug = false/g' ./js/services.js
echo "关闭debug模式"
gulp imagemin
gulp sass
gulp scripts
echo "编译文件"
cp -rf ./img ../www2/b_www_pro/
cp -rf ./dist/* ../www2/b_www_pro/
echo "复制文件"
sed -i 's/https:\/\/locbapp.365gl.com\//https:\/\/bapp.365gl.com\//g' ../www2/b_www_pro/js/all.min.js
cd ../www2/b_www_pro
git status
git add .
git commit -m "打包"
git push
echo "git上传成功"
var myRun = function ($ionicPlatform, $templateCache, cordovaPlug, Common, $rootScope, $timeout, $state, $location, $ionicHistory, debugLocalCommon) {
    $ionicPlatform.ready(function () {
        if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
            cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
            cordova.plugins.Keyboard.disableScroll(true);
        }
        if (window.StatusBar) StatusBar.styleDefault();
        ionic.Platform.fullScreen(true, false);
        // $timeout(function () {
        //     cordovaPlug.CommonPL(function (data) {
        //         if (data.status != 1) toast.show("插件调用失败！");
        //     }, "showMainContent", [])
        // }, 1000)
        console.log(1112121)
        // Common.checkLocation(function (data) {
        //     console.log(22)
        //     Common.setCache('currentPosition', data)
        //     // if (bak) bak()
        // });
        var checkUpdate = function(){
			cordovaPlug.CommonPL(function (res) {
				if(res.data.deviceAppVersion === '6.3.7' && Common.$client.ANDROID){
					Common.showConfirm('系统更新', '给乐商家有新版本啦</br>赶紧升级体验一下吧', function () {
						cordovaPlug.CommonPL(function (res) {
						}, 'spitslot', []);
					}, {}, "升级", '取消');
				}
			}, 'getDeviceIdAndClientId', []);
		}
		// checkUpdate();
        // $rootScope.statusBarHeight = 0.44
        //状态栏高度
        cordovaPlug.CommonPL(function (data) {
            if (data.status == 1) {
                $rootScope.statusBarHeight = data.data.height / 100;
            }
        }, "getStatusBarHeight", []);

        //iphoneX底部安全距离
        // Common.setCache('BottomSafeAreaHeight',0.44);

        if (!Common.getCache('BottomSafeAreaHeight')) {
            $timeout(function () {
                cordovaPlug.CommonPL(function (data) {
                    if (data.status == 1) {
                        $rootScope.BottomSafeAreaHeight = data.data.height / 100;
                        Common.setCache('BottomSafeAreaHeight', data.data.height / 100);
                        document.querySelector('.tabs').style.height = 1.05 + data.data.height / 100 + 'rem';
                    }
                }, "getBottomSafeAreaHeight", [])
            }, 100)
        }
    });





    //返回键处理
    //主页面显示退出提示框
    $ionicPlatform.registerBackButtonAction(function (e) {    
        if (window.location.hash.indexOf('#/tab/collection_success') != -1 || window.location.hash.indexOf('#/tab/pay_error') != -1) {
            $state.go("tab.counter_pay")
        } else if (window.location.hash == '#/tab/index' || window.location.hash == '#/tab/tab_index_operator' || window.location.hash == '#/tab/mine_toLogin' || window.location.hash == '#/tab/my_allmanager') {
            Common.showConfirm("退出提醒", "您确定要退出？", function () {
                ionic.Platform.exitApp();
            }, {}, "确定", "取消")
        } else {
            window.history.back();
        }
        e.preventDefault();
        return false;
    }, 101);

    setTimeout(function () {
        window.notifyMsg = function (obj) {
            var type;
            if (typeof (obj) == "object") {
                type = obj.data.type;
            } else {
                type = angular.fromJson(obj).data.type;
            }
            $state.go('tab.tab_msg', {
                random: new Date().getTime(),
                type: type
            })
        }
    }, 300)

    $timeout(function () {
        if (Common.getCache('Token') != null) {
            $rootScope.role = Common.getCache('Token').role;
            $rootScope.information = Common.getCache('Token');
            $rootScope.onLinePay = Common.getCache('Token').onLinePay;
            if ($rootScope.role == 5) $state.go('tab.my_allmanager')
            else $state.go('tab.index_new');
        } else {
            $rootScope.role = 1;
            $state.go('tab.mine_toLogin')
        }
    }, 0)

    Common.checkDevice();

    function setonLinePay() {
        if (Common.getCache('Token') == null) return;
        Common.get('merchantAPI/merchant/basics', {}, function (data) {
            var newData = Common.getCache('Token');
            newData.cashierBoo = data.data.cashierBoo;
            newData.staffmanagementBoo = data.data.staffmanagementBoo;
            newData.onLinePay = data.data.onLinePay;
            newData.saleRate = data.data.saleRate;
            newData.maxSaleRate = data.data.maxSaleRate;
            newData.minSaleRate = data.data.minSaleRate;
            newData.noBenefit = data.data.noBenefit;
            if (data.data.role && newData.role != 5 && newData.role != 6) newData.role = data.data.role;
            //          if(data.data.role) newData.role = 5;
            Common.setCache('Token', newData);
            $rootScope.role = newData.role;
            $rootScope.onLinePay = newData.onLinePay;
            $rootScope.saleRate = newData.saleRate;
            $rootScope.information = Common.getCache('Token');
            Common.setCache('onLinePay', data.data.onLinePay, 8640000);
        }, {})
    }

    setonLinePay();
    //处理最小化后重新打开事件
    document.addEventListener('resume', function () {
        setonLinePay();
    }, false)

};

var myConfig = function ($urlRouterProvider, $ionicConfigProvider) {
    $ionicConfigProvider.views.swipeBackEnabled(false);
    $urlRouterProvider.otherwise('/tab/mine_toLogin');
};
myapp
    //图片出错时显示
    .directive('errSrc', function () {
        return {
            link: function (scope, element, attrs) {
                element.bind('error', function () {
                    if (attrs.src != attrs.errSrc) {
                        attrs.$set('src', attrs.errSrc);
                    }
                });
            }
        }
    })
    //图片懒加载
    .directive('lazyScroll', ['$rootScope',
        function ($rootScope) {
            return {
                restrict: 'A',
                link: function ($scope, $element) {
                    var origEvent = $scope.$onScroll;
                    $scope.$onScroll = function () {
                        $rootScope.$broadcast('lazyScrollEvent');
                        if (typeof origEvent === 'function') {
                            origEvent();
                        }
                    };
                }
            };
        }
    ])
    .directive('countUp', ['$filter', function ($filter) {

        return {
            restrict: 'A',
            scope: {
                startVal: '=?',
                endVal: '=?',
                duration: '=?',
                decimals: '=?',
                reanimateOnClick: '=?',
                filter: '@',
                options: '=?'
            },
            link: function ($scope, $el, $attrs) {

                var options = {};

                if ($scope.filter) {
                    var filterFunction = createFilterFunction();
                    options.formattingFn = filterFunction;
                }

                if ($scope.options) {
                    angular.extend(options, $scope.options);
                }

                var countUp = createCountUp($scope.startVal, $scope.endVal, $scope.decimals, $scope.duration);

                function createFilterFunction() {
                    var filterParams = $scope.filter.split(':');
                    var filterName = filterParams.shift();

                    return function (value) {
                        var filterCallParams = [value];
                        Array.prototype.push.apply(filterCallParams, filterParams);
                        value = $filter(filterName).apply(null, filterCallParams);
                        return value;
                    };
                }

                function createCountUp(sta, end, dec, dur) {
                    sta = sta || 0;
                    if (isNaN(sta)) sta = Number(sta.match(/[\d\-\.]+/g).join('')); // strip non-numerical characters
                    end = end || 0;
                    if (isNaN(end)) end = Number(end.match(/[\d\-\.]+/g).join('')); // strip non-numerical characters
                    dur = Number(dur) || 2;
                    dec = Number(dec) || 0;

                    // construct countUp 
                    var countUp = new CountUp($el[0], sta, end, dec, dur, options);
                    if (end > 999) {
                        // make easing smoother for large numbers
                        countUp = new CountUp($el[0], sta, end - 100, dec, dur / 2, options);
                    }

                    return countUp;
                }

                function animate() {
                    countUp.reset();
                    if ($scope.endVal > 999) {
                        countUp.start(function () {
                            countUp.update($scope.endVal);
                        });
                    } else {
                        countUp.start();
                    }
                }

                // fire on scroll-spy event, or right away
                if ($attrs.scrollSpyEvent) {
                    // listen for scroll spy event
                    $scope.$on($attrs.scrollSpyEvent, function (event, data) {
                        if (data === $attrs.id) {
                            animate();
                        }
                    });
                } else {
                    animate();
                }

                // re-animate on click
                var reanimateOnClick = angular.isDefined($scope.reanimateOnClick) ? $scope.reanimateOnClick : true;
                if (reanimateOnClick) {
                    $el.on('click', function () {
                        animate();
                    });
                }

                $scope.$watch('endVal', function (newValue, oldValue) {
                    if (newValue === null || newValue === oldValue) {
                        return;
                    }

                    if (countUp !== null) {
                        countUp.update($scope.endVal);
                    } else {
                        countUp = createCountUp($scope.startVal, $scope.endVal, $scope.decimals, $scope.duration);
                        animate();
                    }
                });
            }
        };
    }])
    /*
     *title:标题
     *back：
     *    function 执行函数
     *       -- on-back="test()" 执行的函数名
     *    'tab.test'跳转地址
     *    不填返回上一步
     *right:右侧文字/header_rgiht(css样式控制)
     *right-class:右侧样式class（字体图标）
     *on-click:右侧点击事件
     * */
    .directive("glHeader", function ($ionicHistory, $state) {
        return {
            restrict: "E",
            replace: true,
            template: '<header id="gl_header" ng-style="{height:1.28+$root.statusBarHeight+\'rem\',paddingTop:0.46+$root.statusBarHeight+\'rem\'}"> <div class="tc df"><div class="w124 lh88" ng-click="gotoBack()">  <a class="button-retrun header-back colorff"></a></div>    <div class="df1 f34 colorff lh88">{{modelTitle || title}}</div>  <div class="w124 lh88 colorff header_rgiht {{rightClass}}" ng-click="rightClick()">{{right}}</div> </div> </header>',
            scope: {
                title: "@",
                back: "@",
                onBack: "&",
                right: "@",
                rightClass: "@",
                onClick: '&',
                modelTitle: '='
            },
            link: function ($scope, element, attrs) {
                $scope.gotoBack = function () {
                    $scope.back != undefined ? $scope.back == 'function' ? $scope.onBack instanceof Function && $scope.onBack() : $state.go($scope.back) : window.history.back();
                }
                $scope.rightClick = function () {
                    if ($scope.onClick != undefined) $scope.onClick instanceof Function && $scope.onClick();
                }
            }
        };
    })
    .directive("tabHeader", function ($ionicHistory, $state) {
        return {
            restrict: "E",
            replace: true,
            //          template: '<header class="df" id="tab_header">  <div class="df1 f32 colorff lh88" ng-if="$root.role !=5 && $root.role != 6" >{{$root.information.merchantShortName}}</div>    <div class="f32 colorff lh88 w5 ellipsis" ng-if="$root.role ==5 || $root.role == 6" ng-click="showList()" ng-class="{true:"hasList",false:"noList"}[$root.showListBoo]">{{$root.merchantsChooseName}}</div>        <div class="w124 icon icon1" ng-if="$root.role !=5 && $root.role != 6" ng-click="gotoMsg()"> <em ng-class={true:"block"}[unRead]></em>  </div>    </header>',
            template: '<header class="df" id="tab_header">  <div style="padding-right: .03rem;white-space:nowrap; overflow:hidden;text-overflow:ellipsis;" class="df1 f32 colorff lh88" ng-if="$root.role !=5 && $root.role != 6" >{{$root.information.merchantShortName}}</div>    <div class="f32 colorff lh88 w5 ellipsis" ng-if="$root.role ==5 || $root.role == 6" ng-click="showList()" ng-class={true:"hasList",false:"noList"}[$root.showListBoo]>{{$root.merchantsChooseName}}</div>        <div class="w124 icon icon1" ng-if="$root.role !=5 && $root.role != 6" ng-click="gotoMsg()"> <em ng-class={true:"block"}[unRead]></em>  </div>    </header>',
            link: function ($scope, element, attrs) {}
        };
    })
    .directive('lazySrc', ['$document', '$timeout', '$ionicScrollDelegate', '$compile',
        function ($document, $timeout, $ionicScrollDelegate, $compile) {
            return {
                restrict: 'A',
                scope: {
                    lazyScrollResize: "@lazyScrollResize",
                    imageLazyBackgroundImage: "@imageLazyBackgroundImage",
                    lazySrc: "@"
                },
                link: function ($scope, $element, $attributes) {
                    if (!$attributes.imageLazyDistanceFromBottomToLoad) {
                        $attributes.imageLazyDistanceFromBottomToLoad = 0;
                    }
                    if (!$attributes.imageLazyDistanceFromRightToLoad) {
                        $attributes.imageLazyDistanceFromRightToLoad = 0;
                    }

                    var loader;
                    if ($attributes.imageLazyLoader) {
                        loader = $compile('<div class="image-loader-container"><ion-spinner class="image-loader" icon="' + $attributes.imageLazyLoader + '"></ion-spinner></div>')($scope);
                        $element.after(loader);
                    }

                    $scope.$watch('lazySrc', function (oldV, newV) {
                        if (loader)
                            loader.remove();
                        if ($attributes.imageLazyLoader) {
                            loader = $compile('<div class="image-loader-container"><ion-spinner class="image-loader" icon="' + $attributes.imageLazyLoader + '"></ion-spinner></div>')($scope);
                            $element.after(loader);
                        }
                        var deregistration = $scope.$on('lazyScrollEvent', function () {
                            if (isInView()) {
                                loadImage();
                                deregistration();
                            }
                        });
                        $timeout(function () {
                            if (isInView()) {
                                loadImage();
                                deregistration();
                            }
                        }, 500);
                    });
                    var deregistration = $scope.$on('lazyScrollEvent', function () {
                        if (isInView()) {
                            loadImage();
                            deregistration();
                        }
                    });

                    function loadImage() {
                        $element.bind("load", function (e) {
                            if ($attributes.imageLazyLoader) {
                                loader.remove();
                            }
                            if ($scope.lazyScrollResize == "true") {
                                $ionicScrollDelegate.resize();
                            }
                            $element.unbind("load");
                        });
                        if ($scope.imageLazyBackgroundImage == "true") {
                            var bgImg = new Image();
                            bgImg.onload = function () {
                                if ($attributes.imageLazyLoader) {
                                    loader.remove();
                                }
                                $element[0].style.backgroundImage = 'url(' + $attributes.lazySrc + ')'; // set style attribute on element (it will load image)
                                if ($scope.lazyScrollResize == "true") {
                                    //Call the resize to recalculate the size of the screen
                                    $ionicScrollDelegate.resize();
                                }
                            };
                            bgImg.src = $attributes.lazySrc;
                        } else {
                            $element[0].src = $attributes.lazySrc; // set src attribute on element (it will load image)
                        }
                    }

                    function isInView() {
                        var clientHeight = $document[0].documentElement.clientHeight;
                        var clientWidth = $document[0].documentElement.clientWidth;
                        var imageRect = $element[0].getBoundingClientRect();
                        return (imageRect.top >= 0 && imageRect.top <= clientHeight + parseInt($attributes.imageLazyDistanceFromBottomToLoad)) && (imageRect.left >= 0 && imageRect.left <= clientWidth + parseInt($attributes.imageLazyDistanceFromRightToLoad));
                    }

                    $element.on('$destroy', function () {
                        deregistration();
                    });
                    $timeout(function () {
                        if (isInView()) {
                            loadImage();
                            deregistration();
                        }
                    }, 500);
                }
            };
        }
    ])
    .directive('attached', ['$document', '$timeout', '$ionicScrollDelegate', '$compile', '$timeout',
        function ($document, $timeout, $ionicScrollDelegate, $compile, $timeout) {
            return {
                restrict: 'A',
                link: function ($scope, $element, $attributes) {
                    if (!$attributes.imageLazyDistanceFromBottomToLoad) {
                        $attributes.imageLazyDistanceFromBottomToLoad = 0;
                    }
                    var deregistration = $scope.$on('lazyScrollEvent', function () {
                        changeScroll();
                    });

                    function changeScroll() {
                        if ($ionicScrollDelegate.getScrollPosition().top < 10) {
                            $element.removeClass('transition_8')
                        } else {
                            $element.removeClass('transition_0')
                            $element.addClass('transition_8')
                        }
                        if (isInView()) $element.removeClass('attached-in');
                        else $element.addClass('attached-in');
                    }

                    function isInView() {
                        var clientHeight = $document[0].documentElement.clientHeight;
                        var clientWidth = $document[0].documentElement.clientWidth;
                        var imageRect = $element[0].getBoundingClientRect();
                        return (imageRect.top <= clientHeight + parseInt($attributes.imageLazyDistanceFromBottomToLoad) + 60);
                    }
                }
            };
        }
    ])
    .directive('hideHeader', function ($rootScope, $timeout) {
        return {
            restrict: 'A',
            link: function (scope, element, attributes) {

                scope.$on('$ionicView.beforeLeave', function () {
                    $timeout(function () {
                        scope.$watch(attributes.hideHeader, function (value) {
                            $rootScope.hideHeader = 'header-item-hide';
                        });
                        scope.$watch('$destroy', function () {
                            $rootScope.hideHeader = false;
                        })
                    }, 0)
                });
                scope.$on('$ionicView.beforeEnter', function () {
                    scope.$watch(attributes.hideHeader, function (value) {
                        $timeout(function () {
                            $rootScope.hideHeader = 'header-item-hide';
                        }, 1)
                    });
                });
            }
        };
    })
    .directive('ionSticky', ['$ionicPosition', '$compile', '$timeout', function ($ionicPosition, $compile, $timeout) {
        return {
            restrict: 'A',
            require: '^$ionicScroll',
            link: function ($scope, $element, $attr, $ionicScroll) {
                var scroll = angular.element($ionicScroll.element);
                var clone;
                var cloneVal = function (original, to) {
                    var my_textareas = original.getElementsByTagName('textarea');
                    var result_textareas = to.getElementsByTagName('textarea');
                    var my_selects = original.getElementsByTagName('select');
                    var result_selects = to.getElementsByTagName('select');
                    for (var i = 0, l = my_textareas.length; i < l; ++i)
                        result_textareas[i].value = my_textareas[i].value;
                    for (var i = 0, l = my_selects.length; i < l; ++i)
                        result_selects[i].value = my_selects[i].value;
                };
                // creates the sticky divider clone and adds it to DOM
                var createStickyClone = function ($element) {
                    clone = $element.clone().css({
                        position: 'absolute',
                        top: $ionicPosition.position(scroll).top + "px", // put to top
                        left: 0,
                        right: 0
                    });
                    $attr.ionStickyClass = ($attr.ionStickyClass) ? $attr.ionStickyClass : 'assertive';
                    cloneVal($element[0], clone[0]);
                    clone[0].className += ' ' + $attr.ionStickyClass;

                    clone.removeAttr('ng-repeat-start').removeAttr('ng-if');

                    scroll.parent().append(clone);

                    // compile the clone so that anything in it is in Angular lifecycle.
                    $compile(clone)($scope);
                    $scope.$apply();
                };

                var removeStickyClone = function () {
                    if (clone)
                        clone.remove();
                    clone = null;
                };

                $scope.$on('$removeClone', function () {
                    removeStickyClone();
                    if (document.querySelector('.assertive')) {
                        document.querySelector('.assertive').remove();
                    }
                });
                $scope.$on("$destroy", function () {
                    // remove the clone and unbind the scroll listener
                    removeStickyClone();
                    angular.element($ionicScroll.element).off('scroll');
                });

                var lastActive;
                var minHeight = $attr.minHeight ? $attr.minHeight : 0;
                var updateSticky = ionic.throttle(function () {
                    //console.log(performance.now());
                    var active = null;
                    var dividers = [];
                    var tmp = $element[0].getElementsByClassName("item-divider");
                    for (var i = 0; i < tmp.length; ++i) dividers.push(angular.element(tmp[i]));
                    for (var i = 0; i < dividers.length; ++i) { // can be changed to binary search
                        if ($ionicPosition.offset(dividers[i]).top - $ionicPosition.offset($element).top - minHeight < 30) { // this equals to jquery outerHeight
                            if (i === dividers.length - 1 || $ionicPosition.offset(dividers[i + 1]).top -
                                ($ionicPosition.offset($element).top + dividers[i + 1].prop('offsetHeight')) - minHeight > 0) {
                                active = dividers[i][0];
                                break;
                            }
                        }
                    }

                    if (lastActive != active) {
                        removeStickyClone();
                        lastActive = active;
                        if (active != null)
                            createStickyClone(angular.element(active));
                    }
                    //console.log(performance.now());
                }, 200);
                scroll.on('scroll', function (event) {
                    updateSticky();
                });
            }
        };
    }])
    .filter('moneyUnit', function () {
        return function (input, front, behind) {
            if (front && behind) {
                return front + parseFloat(input).toFixed(2) + behind;
            } else if (front) {
                return front + parseFloat(input).toFixed(2);
            } else if (behind) {
                return parseFloat(input).toFixed(2) + behind;
            } else {
                return parseFloat(input).toFixed(2) + "元";
            }

        };
    })
    .filter('nameHide', function () {
        return function (input) {
            if (input) {
                return input.substring(0, 1) + '**';
            }
        };
    })
    // 月份选择器
    .directive('monthPicker', function ($ionicScrollDelegate) {
        return {
            restrict: 'E',
            templateUrl: 'component/tab_bill/month-picker.html',
            scope: {
                localDate: '='
            },
            link: function ($scope) {
                var yearIndex = 0,
                    year = new Date().getFullYear() + 2,
                    localYear = new Date().getFullYear(),
                    localMonth = month = new Date().getMonth() + 1,
                    localDay = new Date().getDate();
                var monthIndex = 0,
                    month = new Date().getMonth() + 1;
                if (month < 10) {
                    month = '0' + month
                }
                if (localMonth < 10) {
                    localMonth = '0' + localMonth;
                }
                if (localDay < 10) {
                    localDay = '0' + localDay
                }
                var dayIndex = 0;
                $scope.years = []; // 年数组
                $scope.months = ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12'];
                $scope.days = [];
                var spar = {
                    28: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28'],
                    29: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29'],
                    30: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30'],
                    31: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31']
                };
                // $scope.hasDate = false; // 是否选择需要选择日期
                $scope.changeFlag = 1; // 1是开始时间，2是结束时间
                for (var i = 2000; i <= year; i++) {
                    $scope.years.push(i)
                }
                var loop1, loop2, loop3;
                var checkTag = 0,
                    checkTag2 = 0,
                    checkTag3 = 0;
                var _endDay, _endYear, _endMonth;

                $scope.goChoose = function () {
                    $scope.blockFlag = true;
                    setTimeout(function () {
                        _initScroll()
                    }, 300)
                };

                $scope.$on('initPicker', function (scope, unReset) {
                    if (!unReset) {
                        $scope.localDate = angular.extend($scope.localDate, {
                            startYear: localYear,
                            startMonth: localMonth,
                            startDay: localDay,
                            endYear: localYear,
                            endMonth: localMonth,
                            endDay: localDay
                        });
                        $scope.blockFlag = false
                        $scope.hasDate=false
                        _initScroll();
                        return;
                    }

                    _endDay = $scope.localDate.endDay;
                    _endYear = $scope.localDate.endYear;
                    _endMonth = $scope.localDate.endMonth;
                    _initScroll();
                });

                $scope.check1 = function () {
                    clearInterval(loop1);
                    if (checkTag < 0) {
                        return false;
                    }
                    checkTag = 0;
                    loop1 = setInterval(function () {
                        checkTag++;
                        if (checkTag > 2) {
                            chooseYear();
                            checkTag = -1;
                        }
                    }, 100)
                };
                $scope.check2 = function () {
                    clearInterval(loop2);
                    if (checkTag2 < 0) {
                        return false;
                    }
                    checkTag2 = 0;
                    loop2 = setInterval(function () {
                        checkTag2++;
                        if (checkTag2 > 2) {
                            chooseMonth();
                            checkTag2 = -1;
                        }
                    }, 100)
                };
                $scope.check3 = function () {
                    clearInterval(loop3);
                    if (checkTag3 < 0) {
                        return false;
                    }
                    checkTag3 = 0;
                    loop3 = setInterval(function () {
                        checkTag3++;
                        if (checkTag3 > 2) {
                            chooseDay();
                            checkTag3 = -1;
                        }
                    }, 100)
                };
                $scope.changeType = function () {
                    if ($scope.hasDate) {
                        $scope.hasDate = !$scope.hasDate;
                        $scope.blockFlag = false;
                        $scope.localDate = angular.extend($scope.localDate, {
                            startYear: '',
                            startMonth: '',
                            startDay: '',
                            endYear: '',
                            endMonth: '',
                            endDay: ''
                        });
                        return;
                    }
                    $scope.hasDate = !$scope.hasDate;
                    if ($scope.hasDate) {
                        $scope.localDate = angular.extend($scope.localDate, {
                            startYear: localYear,
                            startMonth: localMonth,
                            startDay: localDay,
                            endYear: localYear,
                            endMonth: localMonth,
                            endDay: localDay
                        });
                        $scope.days = spar[getDaysInOneMonth(localYear, localMonth)];
                        setTimeout(function () {
                            _initScroll()
                        }, 100)
                    } else {
                        $scope.localDate.startYear = $scope.localDate.endYear;
                        $scope.localDate.startMonth = $scope.localDate.endMonth;
                        $scope.localDate.startDay = $scope.localDate.endDay;
                        _initScroll()
                    }
                };
                $scope.setDate = function () {
                    if ($scope.changeFlag === 1) {
                        $scope.localDate.startYear = $scope.years[yearIndex];
                        $scope.localDate.startMonth = $scope.months[monthIndex];
                        if (!$scope.hasDate) {
                            $scope.localDate.endYear = $scope.years[yearIndex];
                            $scope.localDate.endMonth = $scope.months[monthIndex];
                            $scope.localDate.startDay = '01';
                            $scope.localDate.endDay = getDaysInOneMonth($scope.years[yearIndex], $scope.months[monthIndex]);
                        } else {
                            $scope.localDate.startDay = $scope.days[dayIndex];
                        }
                    } else {
                        $scope.localDate.endYear = $scope.years[yearIndex];
                        $scope.localDate.endMonth = $scope.months[monthIndex];
                        $scope.localDate.endDay = $scope.days[dayIndex];
                    }
                    console.log($scope.localDate, 502)
                };

                $scope.setTime = function (num, _year, _month, _day) {
                    $scope.changeFlag = num;
                    if (!_year) {
                        _year = $scope.localDate.startYear;
                        _month = $scope.localDate.startMonth;
                        _day = $scope.localDate.startDay;
                    }
                    $ionicScrollDelegate.$getByHandle('scroll1').scrollTop();
                    $ionicScrollDelegate.$getByHandle('scroll2').scrollTop();
                    $ionicScrollDelegate.$getByHandle('scroll3').scrollTop();
                    _animation(_year, _month, _day)
                };

                function chooseYear() {
                    var top = $ionicScrollDelegate.$getByHandle('scroll1').getScrollPosition().top;
                    yearIndex = (top / 44).toFixed(0);
                    $ionicScrollDelegate.$getByHandle('scroll1').scrollTo(0, yearIndex * 44);
                    _initDate();
                    $scope.setDate();
                    setTimeout(function () {
                        checkTag = 0;
                        clearInterval(loop1);
                        $scope.$apply();
                    }, 100)
                }

                function chooseMonth() {
                    var top = $ionicScrollDelegate.$getByHandle('scroll2').getScrollPosition().top;
                    monthIndex = (top / 44).toFixed(0);
                    $ionicScrollDelegate.$getByHandle('scroll2').scrollTo(0, monthIndex * 44);
                    _initDate();
                    $scope.setDate();
                    setTimeout(function () {
                        checkTag2 = 0;
                        clearInterval(loop2);
                        $scope.$apply();
                    }, 100)
                }

                function chooseDay() {
                    var top = $ionicScrollDelegate.$getByHandle('scroll3').getScrollPosition().top;
                    dayIndex = Number((top / 44).toFixed(0));
                    $ionicScrollDelegate.$getByHandle('scroll3').scrollTo(0, dayIndex * 44);
                    $scope.setDate();
                    setTimeout(function () {
                        checkTag3 = 0;
                        clearInterval(loop3);
                        $scope.$apply();
                    }, 100)
                }

                function _animation(year, month, day) {
                    $ionicScrollDelegate.$getByHandle('scroll1').scrollTop();
                    $ionicScrollDelegate.$getByHandle('scroll2').scrollTop();
                    for (var i = 0; i < $scope.years.length; i++) {
                        if ($scope.years[i] == year) {
                            yearIndex = i;
                            $ionicScrollDelegate.$getByHandle('scroll1').scrollTo(0, yearIndex * 44);
                        }
                    }
                    for (var j = 0; j < 12; j++) {
                        if ($scope.months[j] == month) {
                            monthIndex = j;
                            $ionicScrollDelegate.$getByHandle('scroll2').scrollTo(0, monthIndex * 44);
                        }
                    }
                    if (day) {
                        for (var k = 0; k < 32; k++) {
                            if ($scope.days[k] == day) {
                                dayIndex = k;
                                $ionicScrollDelegate.$getByHandle('scroll3').scrollTo(0, dayIndex * 44);
                            }
                        }
                    }
                }

                function _initDate() {
                    var sparNum = getDaysInOneMonth($scope.years[yearIndex], $scope.months[monthIndex]);
                    $scope.days = spar[sparNum];
                    if (dayIndex + 1 > sparNum) {
                        for (var k = 0; k < 32; k++) {
                            if ($scope.days[k] == sparNum) {
                                dayIndex = k;
                                $ionicScrollDelegate.$getByHandle('scroll3').scrollTo(0, dayIndex * 44);
                            }
                        }
                    }
                }

                function getDaysInOneMonth(year, month) {
                    month = parseInt(month, 10);
                    var d = new Date(year, month, 0);
                    return d.getDate();
                }

                function _initScroll() {
                    if (!$scope.blockFlag) {
                        return;
                    }
                    $scope.changeFlag = 1;

                    if ($scope.hasDate) {
                        _animation($scope.localDate.startYear, $scope.localDate.startMonth, $scope.localDate.startDay)
                        return
                    }

                    if (_endDay) {
                        $scope.localDate = angular.extend($scope.localDate, {
                            startYear: '',
                            startMonth: '',
                            startDay: '',
                            endYear: '',
                            endMonth: '',
                            endDay: ''
                        });
                        _animation(_endYear, _endMonth);
                        return;
                    }
                    _animation(localYear, month)


                }
            }
        };
    }).directive('codePicker', function ($ionicScrollDelegate) {
        return {
            restrict: 'E',
            templateUrl: 'component/tab_bill/code-picker.html',
            scope: {
                posCodeList: '=',
                qrCodeList: '='
            },
            link: function ($scope, $rootScope) {

                var posIndex = 0,
                    qrCodeIndex = 0;

                // $scope.hasDate = false; // 是否选择需要选择日期
                // $scope.changeFlag = 1; // 1是开始时间，2是结束时间

                var loop1, loop2;
                var checkTag = 0,
                    checkTag2 = 0

                $rootScope.blockFlag = false;
                $rootScope.posBlockFlag = false


                $scope.check1 = function () {
                    clearInterval(loop1);
                    if (checkTag < 0) {
                        return false;
                    }
                    checkTag = 0;
                    loop1 = setInterval(function () {
                        checkTag++;
                        if (checkTag > 2) {
                            checkTag = -1;
                            chooseQrCode()
                        }
                    }, 100)
                };
                $scope.check2 = function () {
                    clearInterval(loop2);
                    if (checkTag2 < 0) {
                        return false;
                    }
                    checkTag2 = 0;
                    loop2 = setInterval(function () {
                        checkTag2++;
                        if (checkTag2 > 2) {
                            checkTag2 = -1;
                            choosePos()
                        }
                    }, 100)
                };

                function chooseQrCode() {
                    var top = $ionicScrollDelegate.$getByHandle('scroll5').getScrollPosition().top;
                    qrCodeIndex = (top / 44).toFixed(0);
                    $scope.selectQrCode = $scope.qrCodeList[qrCodeIndex].barCode
                    $scope.$emit("selectQrCode", $scope.selectQrCode);
                    $ionicScrollDelegate.$getByHandle('scroll5').scrollTo(0, qrCodeIndex * 44);
                    setTimeout(function () {
                        checkTag = 0;
                        clearInterval(loop1);
                        $scope.$apply();
                    }, 100)
                }

                function choosePos() {
                    var top = $ionicScrollDelegate.$getByHandle('scroll6').getScrollPosition().top;
                    posIndex = (top / 44).toFixed(0);
                    $scope.selectPosCode = $scope.posCodeList[posIndex].posDeviceId
                    console.log($scope.selectPosCode)
                    $scope.$emit("selectPosCode", $scope.selectPosCode);
                    $ionicScrollDelegate.$getByHandle('scroll6').scrollTo(0, posIndex * 44);
                    setTimeout(function () {
                        checkTag2 = 0;
                        clearInterval(loop2);
                        $scope.$apply();
                    }, 100)
                }

            }
        };
    });
myapp.run(myRun).config(myConfig);
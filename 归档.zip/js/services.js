angular.module('starter.services', [])
  .filter('bankItem', function () {
    return function (input) {
      var array = input.replace(/(.{4})(?=.)/g, "$1 ");
      return array;
    }
  })
  .filter('cardHide', function () {
    return function (input) {
      if (input == null) return '';
      var array = '**** **** **** ' + input.replace(/\s/ig, '').substr(-4);
      return array;
    }
  })
  .filter('nameHide1', function () {
    return function (input) {
      if (input == null) return '';
      var array = '**' + input.replace(/\s/ig, '').substr(-1);
      return array;
    }
  })
  .filter('phoneHide', function () {
    return function (input) {
      if (input == null) return '';
      var array = input.substr(0, 3) + '****' + input.substr(7, 4);
      return array;
    }
  })
  .filter('phoneHideStart', function () {
    return function (input) {
      if (!input) return '';
      if (input.length <= 3) return input.substr(0, 1) + '**';
      return input.substr(0, 3) + '********';
    }
  })
  .filter('changeTime', function ($filter) {
    return function (input) {
      var newDate = new Date(input.replace(/-/g, "/"));
      var dateOld = (new Date().getTime() - Date.parse(newDate)) / 1000 | 0;
      var today = new Date(new Date().setHours(0, 0, 0, 0)).getTime();
      if (dateOld < 60 * 2) return '刚刚';
      else if (dateOld < 60 * 10) return '10分钟前';
      else if (Date.parse(newDate) > today) return '今天 ' + $filter('date')(newDate, 'HH:mm');
      else if (new Date().getFullYear() == input.substr(0, 4)) return $filter('date')(newDate, 'MM-dd HH:mm');
      else return input;
    }
  })
  .factory('cordovaPlug', function (toast) {
    $cordovaPlugreturn = {
      CommonPL: function (success, functionName, parameter) {
        try {
          cordova.exec(function (data) {
            success instanceof Function && success(data);
          }, $cordovaPlugreturn.CommonPLError, "CommonPL", functionName, parameter);
        } catch (e) {}
      },
      CommonPLError: function (error) {
        toast.show(error)
      }
    };
    return $cordovaPlugreturn;
  })
  .factory('toast', function (ionicToast) {
    // 静默消息
    $toast = {
      show: function (message) {
        ionicToast.show(message, 'bottom', false, 2000);
      }
    };
    return $toast;
  })

  .factory('Common', function ($http, $ionicLoading, $ionicPopup, toast, cordovaPlug, $state, $rootScope, $ionicHistory, $timeout) {
    //var app_url =debug_url=mock_url= 'https://bapp.365gl.com/',       //生产地址
    // var app_url = debug_url = mock_url = 'http://192.168.0.172:18081/', //建胜
    var app_url = debug_url = mock_url = 'https://locbapp.365gl.com/', //测试地址
    // var app_url = debug_url = mock_url = 'https://bapp-dev.365gl.com/',        //开发地址
    // var app_url =debug_url=mock_url= 'http://192.168.0.62:18081/',        //开发地址
    //config_url = './life/',
    config_url = 'http://image-cdn.365gl.com/life/',
    ClientVer = '6.1.0',
    url_overtime = 60000,
    isDebug = false; //是否开启测试
    isAleart = false;
    isError = false;
    $return = {
      app_url: app_url,
      ClientVer: ClientVer,
      config_url: config_url,
      $client:{
        IOS: !!navigator.appVersion.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), // ios终端
        ANDROID: navigator.appVersion.indexOf('Android') > -1 || navigator.appVersion.indexOf('Adr') > -1 // android终端或者uc浏览器
      },
      showLoading: function (_timer) {
        var myTimer = _timer ? 200000 : 7000;
        $ionicLoading.show({
          content: 'Loading',
          animation: 'fade-in',
          showBackdrop: true,
          template: '<div id="gl_loading" class="spinnere"><div class="bounce1"></div><div class="bounce2"></div><div class="bounce3"></div></div>',
          duration: myTimer
        });
        $timeout(function () {
          var nowTimer = new Date().getTime();
          var htmlEl = angular.element(document.querySelector('.loading-container'));
          htmlEl.on('click', function (event) {
            if (new Date().getTime() - nowTimer > _timer) {
              $return.showConfirm('退出提醒', '交易支付中，您确定退出么？', function () {
                $state.go('tab.index');
                $return.hideLoading();
              }, function () {
                $return.showLoading(1000)
              }, '确定', '继续等待');
            }
          });
        }, 0)

      },
      hideLoading: function () {
        $ionicLoading.hide();
      },
      showAlert: function (title, template, then, okText) {
        if (!isError) {
          var okText = okText || '我知道了';
          isError = true;
          var alertPopup = $ionicPopup.alert({
            template: template,
            okText: okText,
            okType: 'button-light'
          });
          alertPopup.then(function (res) {
            isError = false;
            then instanceof Function && then(res);
          });
          return function () {
            alertPopup.close()
            isError = false;
          }
        }
        setTimeout(function () {
          isError = false;
        }, 1000)
      },
      showConfirm: function (title, template, ok, cancel, okText, cancelText) {
        if (!isAleart) {
          isAleart = true;
          var confirmPopup = $ionicPopup.confirm({
            template: template,
            buttons: [{
              text: cancelText || '取消',
              type: 'button-light',
              onTap: function (e) {
                isAleart = false;
                cancel instanceof Function && cancel();
              }
            }, {
              text: okText || '确定',
              type: 'button-light',
              onTap: function (e) {
                isAleart = false;
                ok instanceof Function && ok();
              }
            }]
          });
          return function () {
            confirmPopup.close()
            isAleart = false;
          }
        }
        setTimeout(function () {
          isAleart = false;
        }, 1000)
      },
      setCache: function ($key, $value, $expire) {
        var object = {
          value: $value,
          timestamp: $expire && (parseInt($expire) + new Date().getTime()) || '0'
        };
        localStorage.setItem($key, JSON.stringify(object));
      },
      getCache: function ($key) {
        var cache = localStorage.getItem($key);
        if (cache) {
          var object = JSON.parse(localStorage.getItem($key)),
            dateString = object.timestamp,
            now = new Date().getTime().toString();
          if (dateString != '0' && now > dateString) {
            localStorage.removeItem($key);
            return null;
          }
          return object.value;
        } else return null;
      },
      clearCache: function ($key) {
        localStorage.removeItem($key);
      },
      setSessionStorage: function ($key, $value, $expire) {
        var object = {
          value: $value,
          timestamp: $expire && (parseInt($expire) + new Date().getTime()) || '0'
        };
        sessionStorage.setItem($key, JSON.stringify(object));
      },
      getSessionStorage: function ($key) {
        var cache = sessionStorage.getItem($key);
        if (cache) {
          var object = JSON.parse(sessionStorage.getItem($key)),
            dateString = object.timestamp,
            now = new Date().getTime().toString();
          if (dateString != '0' && now > dateString) {
            sessionStorage.removeItem($key);
            return null;
          }
          return object.value;
        } else return null;
      },
      clearSessionStorage: function ($key) {
        sessionStorage.removeItem($key);
      },
      logout: function () {
        localStorage.showTips = 1
        $return.clearCache('Token');
        $return.clearCache('merchantInfo');
        $return.clearCache('picUrlList');
        $return.clearCache('bannerImg');
        $return.clearCache('commentScore');
        $return.clearCache('dayResult');
        $return.clearCache('inviteSum');
        $return.clearCache('yesterdayProfit');
        $return.clearCache('inviteSumAll');
        $return.clearCache('commentScore');
        $return.clearCache('operatorScore');
        $return.clearCache('inviteConsume');
        $return.clearCache('operatorScoreOnly');
        $return.clearCache("user_bankCardName");
        $return.clearCache("user_bankCardNo");
        $return.clearCache("user_bankCardIcon");
        $return.clearCache("user_bankCardColor");
        $return.clearCache("user_addedCardInfo");
        $return.clearCache("wxpayMess");
        $return.clearCache("wxpayWallet");
        $return.clearCache("showWallet");
        $return.clearCache("missMessage");
        $return.clearCache("showWallet1");
        $return.clearCache('canUseScan');
        $return.clearCache('RSa');
        $return.clearCache('bill_details');
        $return.clearCache('bill_details_cancel');
        cordovaPlug.CommonPL(function (data) {}, "loginout", []);
        $ionicHistory.clearCache();
        $ionicHistory.clearHistory();
        // $timeout(function(){
        //     //$state.go("tab.mine_toLogin");
        //     window.location.href="#/tab/mine_toLogin";
        // },500)
      },
      //获取设备id
      checkDevice: function () {
        if (isDebug) {
          var data = {
            "DeviceId": "testtesttttt",
            "ClientId": "test",
            "deviceName": "test",
            "deviceVersion": "7.0.0",
            "deviceAppVersion": "6.2.0"
          };
          app_url = debug_url;
          $return.setCache('getDeviceIdAndClientId', data);
          return;
        }
        if (!$return.getCache('getDeviceIdAndClientId')) {
          cordovaPlug.CommonPL(function (data) {
            if (data.status == 1) {
              $return.setCache('getDeviceIdAndClientId', data.data);
            } else {
              toast.show("插件调用失败！");
            }
          }, "getDeviceIdAndClientId", [])
        }
      },
      //获取定位
      checkLocation: function (success) {
        $return.showLoading()
        console.log("调用了定位地图");
        if (isDebug) {
          $rootScope.myCity = {
            "cityId": "77",
            "city": "深圳市",
            "address": "广东省深圳市南山区高新南一道9-南门",
            "latitude": "22.543544",
            "longitude": "113.959062",
            "streetName": "高新9道"
          }
        }
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            $return.hideLoading()
            $rootScope.myCity = data.data;
            success instanceof Function && success(data.data);
          } else {
            $return.hideLoading()
            toast.show("获取定位失败！");
          }
        }, "location", [])
      },

      //获取签名
      checkSign: function (_string, mysuccess) {
        if (!$return.isnetwork()) {
          $return.showAlert('温馨提示', "网络连接错误，请检查网络连接");
          $return.hideLoading();
          return;
        }
        if (isDebug) {
          $http({
            method: 'get',
            url: app_url + "merchantAPI/getSign?text=" + _string,
          }).then(function success(sign) {
            var data = {
              "RSA": sign.data.data
            };
            mysuccess instanceof Function && mysuccess(data);
          }, function error() { //debug获取RSA失败，进入本地json调试模式
            var _data = {
              "RSA": ''
            };
            app_url = mock_url;
            mysuccess instanceof Function && mysuccess(_data);
          })
          return;
        }
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            mysuccess instanceof Function && mysuccess(data.data);
          } else {
            toast.show("插件调用失败！");
          }
        }, "getRSA", [_string])
      },
      //MD5加密算法
      checkMd5: function (_string, success) {
        if (isDebug) {
          var data = {
            'MD5': hex_md5(_string.toString())
          }
          if (success) {
            success instanceof Function && success(data);
          } else {
            return data.MD5;
          }
          return;
        }
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            if (success) {
              success instanceof Function && success(data.data);
            } else {
              return data.data.MD5;
            }
          } else {
            toast.show("插件调用失败！");
          }
        }, "getMD5", [_string])
      },
      checkscan: function (success) {
        console.log("成功调用扫一扫");
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            success instanceof Function && success(data.data);
          } else {
            toast.show("插件调用失败！");
          }
        }, "scan", [])
      },
      //MD5+RSA登录专用
      loginEncrypt: function (_string, _md5, success) {
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            success instanceof Function && success(data.data);
          } else {
            toast.show("插件调用失败！");
          }
        }, "loginEncrypt", [_string, _md5])
      },
      //分享
      glShare: function (_title, _des, _picUrl, _appUrl, success) {
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            success instanceof Function && success(data.data);
          } else {
            toast.show("插件调用失败！");
          }
        }, "glShare", [_title, _des, _picUrl, _appUrl])
      },
      exchangeRedeem: function (_merchantNo, _redeemOperatorId, _redeemOperatorName, _token) {
        cordovaPlug.CommonPL(function (data) {
          if (data.status == 1) {
            success instanceof Function && success(data.data);
          } else {
            toast.show("插件调用失败！");
          }
        }, "exchangeRedeem", [_merchantNo, _redeemOperatorId, _redeemOperatorName, _token])
      },
      //判断用户是否登录
      isLogin: function () {
        if ($return.getCache('Token') == null) {
          $state.go("tab.mine_toLogin");
          return false;
        } else return true;
      },
      //判断用户是否有开启网络
      isnetwork: function () {

        if (navigator.onLine) return true;
        else return false;
      },
      post_login: function (url, data, success, error, loading) {
        if (!$return.isnetwork()) {
          $return.showAlert('温馨提示', "网络连接错误，请检查网络连接");
          return;
        }
        var myDevice = $return.getCache('getDeviceIdAndClientId'),
          myTime = Math.floor(new Date().getTime() / 1000);
        if (!myDevice) {
          $return.checkDevice();
          return;
        }
        $return.showLoading();
        console.time('请求时间：');
        if (isDebug) {
          var myMD5 = hex_md5("GL_SALT_MD5_KEY" + data.password.toString());
          console.log(myMD5)
          $http({
            method: 'get',
            url: app_url + "merchantAPI/getSign?text=" + myDevice.DeviceId.toString() + myDevice.ClientId.toString() + ClientVer.toString() + myTime.toString() + data.username.toString() + myMD5,
          }).then(function success(sign) {
            var _data = {};
            _data.RSA = sign.data.data;
            _data.MD5 = myMD5;
            newHttp(_data);
          }, function error() { //debug获取RSA失败，进入本地json调试模式
            var _data = {};
            _data.RSA = '';
            _data.MD5 = '';
            app_url = mock_url;
            newHttp(_data);
          })
          return;
        }
        $return.loginEncrypt(myDevice.DeviceId.toString() + myDevice.ClientId.toString() + ClientVer.toString() + myTime.toString() + data.username.toString(),
          "GL_SALT_MD5_KEY" + data.password.toString(),
          function (dataAll) {
            newHttp(dataAll)
          });

        function newHttp(_data) {
          data.password = _data.MD5;
          $http({
            method: 'post',
            url: app_url + url,
            data: data,
            headers: {
              "GL_DEVICE_ID": myDevice.DeviceId,
              "GL_CLIENT_ID": myDevice.ClientId,
              "GL_CLIENT_VER": ClientVer,
              "GL_CLIENT_APP_VER": myDevice.deviceAppVersion,
              "GL_TIMESTAMP": myTime,
              "GL_REQ_SIGN": _data.RSA
            },
            timeout: url_overtime
          }).then(function successCallback(data) {
            console.timeEnd('请求时间：');
            data = data.data;
            $return.setCache('RSa', {
              "GL_DEVICE_ID": myDevice.DeviceId,
              "GL_CLIENT_ID": myDevice.ClientId,
              "GL_CLIENT_VER": ClientVer,
              "GL_CLIENT_APP_VER": myDevice.deviceAppVersion,
              "GL_TIMESTAMP": myTime,
              "GL_REQ_SIGN": _data.RSA
            })
            if (data.result == "000000") success instanceof Function && success(data);
            else $return.showAlert('温馨提示', data.description);
            $return.hideLoading();
          }, function errorCallback(data) {
            $return.hideLoading();
            data && data.description ? $return.showAlert('温馨提示', data.description) : $return.showAlert('温馨提示', "网络连接错误，请稍后再试！");
            error instanceof Function && error(data);
          });
        }
      },
      sendMessage: function (phoneNo, businessType, success, error) {
        var myDevice = $return.getCache('getDeviceIdAndClientId'),
          myTime = Math.floor(new Date().getTime() / 1000),
          myToken = '';
        if (!myDevice) return;
        console.time('请求时间：');
        if ($return.getCache('Token') != null) myToken = $return.getCache('Token');
        $return.checkSign(myToken + myDevice.DeviceId.toString() + myDevice.ClientId.toString() + ClientVer.toString() + myTime.toString(),
          function (_data) {
            newHttp(_data);
          });

        function newHttp(_data) {
          $http({
            method: 'post',
            url: app_url + 'merchantAPI/sms/sendSms',
            data: {
              "phoneNo": phoneNo,
              "businessType": businessType
            },
            headers: {
              "GL_TOKEN": myToken,
              "GL_DEVICE_ID": myDevice.DeviceId,
              "GL_CLIENT_ID": myDevice.ClientId,
              "GL_CLIENT_VER": ClientVer,
              "GL_CLIENT_APP_VER": myDevice.deviceAppVersion,
              "GL_TIMESTAMP": myTime,
              "GL_REQ_SIGN": _data.RSA
            },
            timeout: url_overtime
          }).then(function successCallback(data) {
            console.timeEnd('请求时间：');
            data = data.data;
            if (data.result == "000000") success instanceof Function && success(data);
            else if (data.result == "000005") $state.go("tab.mine_toLogin", {}, {
              reload: true
            });
            else if (data.result == '200001') $return.showAlert("温馨提示", "该手机号码已绑定，请重新输入");
            else $return.showAlert('温馨提示', data.description);
          }, function errorCallback(data) {
            data && data.description ? $return.showAlert('温馨提示', data.description) : '';
            error instanceof Function && error(data);
          });
        }

      },
      get: function (url, data, success, error, loading) {
        if (loading != undefined) $return.showLoading();
        var myDevice = $return.getCache('getDeviceIdAndClientId'),
          myTime = Math.floor(new Date().getTime() / 1000),
          myToken = '';
        if (!myDevice) return;
        console.time('请求耗时：');
        data = data instanceof Object && data || {};
        if ($return.getCache('Token') != null) myToken = $return.getCache('Token').token;
        $return.checkSign(myToken + myDevice.DeviceId.toString() + myDevice.ClientId.toString() + ClientVer.toString() + myTime.toString(),
          function (_data) {
            newHttp(_data);
          });

        function newHttp(_data) {
          console.log("(GET) 正在调用 [" + url + "],参数为：" + angular.toJson(data));
          $http({
            method: 'get',
            url: app_url + url,
            params: data,
            headers: {
              "GL_TOKEN": myToken,
              "GL_DEVICE_ID": myDevice.DeviceId,
              "GL_CLIENT_ID": myDevice.ClientId,
              "GL_CLIENT_VER": ClientVer,
              "GL_CLIENT_APP_VER": myDevice.deviceAppVersion,
              "GL_TIMESTAMP": myTime,
              "GL_REQ_SIGN": _data.RSA
            },
            timeout: url_overtime
          }).then(function successCallback(data) {
            console.timeEnd("请求耗时：");
            data = data.data;
            if (data.result == "000000") success instanceof Function && success(data);
            else if (data.result == "b_forced_login") {
              $return.logout();
              $return.showAlert('', data.description, function () {
                $state.go("tab.mine_toLogin", {}, {
                  reload: true
                });
              })
            } else if (data.result == "000001") {
              $return.logout();
              $return.showAlert('温馨提醒', '登录失效，请重新登录！', function () {
                $state.go("tab.mine_toLogin", {}, {
                  reload: true
                });
              })
            } else if (data.result == "000007") {
              $return.logout();
              $return.showAlert('温馨提醒', '该商户已经和您解除关联，请重新登录！', function () {
                $state.go("tab.mine_toLogin", {}, {
                  reload: true
                });
              })
            } else $return.showAlert('温馨提示', data.description);
            if (loading != undefined) $return.hideLoading();
          }, function errorCallback(data) {
            $return.hideLoading();
            data && data.description ? $return.showAlert('温馨提示', data.description) : $return.showAlert('温馨提示', "网络连接错误，请稍后再试！");;
            error instanceof Function && error(data);
          });
        }
      },
      post: function (url, data, success, error, loading, mySuccess, handle) {
        if (loading != undefined && loading != null) $return.showLoading();
        var myDevice = $return.getCache('getDeviceIdAndClientId'),
          myTime = Math.floor(new Date().getTime() / 1000),
          myToken = '';
        if (!myDevice) return;
        console.time('请求耗时：');
        data = data instanceof Object && data || {};
        if ($return.getCache('Token') != null) myToken = $return.getCache('Token').token;
        $return.checkSign(myToken + myDevice.DeviceId.toString() + myDevice.ClientId.toString() + ClientVer.toString() + myTime.toString(),
          function (_data) {
            newHttp(_data);
          });

        function newHttp(_data) {
          console.log("(POST) 正在调用 [" + url + "],参数为：" + angular.toJson(data));
          $http({
            method: 'post',
            url: app_url + url,
            data: data,
            headers: {
              "GL_TOKEN": myToken,
              "GL_DEVICE_ID": myDevice.DeviceId,
              "GL_CLIENT_ID": myDevice.ClientId,
              "GL_CLIENT_VER": ClientVer,
              "GL_CLIENT_APP_VER": myDevice.deviceAppVersion,
              "GL_TIMESTAMP": myTime,
              "GL_REQ_SIGN": _data.RSA
            },
            timeout: url_overtime
          }).then(function successCallback(data) {
            console.timeEnd("请求耗时：");
            data = data.data;
            if (loading != undefined) $return.hideLoading();
            if (mySuccess != undefined) mySuccess instanceof Function && mySuccess(data);
            else if (data.result == "000000") success instanceof Function && success(data);
            else if (data.result == "000001") {
              $return.logout();
              $return.showAlert('温馨提醒', '登录失效，请重新登录！', function () {
                $state.go("tab.mine_toLogin", {}, {
                  reload: true
                });
              })
            } else if (data.result == "000007") {
              $return.logout();
              $return.showAlert('温馨提醒', '该商户已经和您解除关联，请重新登录！', function () {
                $state.go("tab.mine_toLogin", {}, {
                  reload: true
                });
              })
            } else {
              $return.showAlert('温馨提示', data.description);
              if (handle) handle();
            }

          }, function errorCallback(data) {
            $return.hideLoading();
            data && data.description ? $return.showAlert('温馨提示', data.description) : $return.showAlert('温馨提示', "网络连接错误，请稍后再试！");;
            error instanceof Function && error(data);
          });
        }

      },
      listToDate: function (obj, list, date) {
        var item, obj = obj;
        date = date ? date : 'date'
        for (var i = 0; i < list.length; i++) {
          item = list[i]
          if (!obj[item[date].split(" ")[0]]) {
            obj[item[date].split(" ")[0]] = {
              time: item[date],
              list: [item]
            }
          } else {
            obj[item[date].split(" ")[0]].list.push(item)
          }
        }
        return obj;
      }

    }
    return $return;
  })
  .factory('actionSheetItem', function ($document, $compile, $rootScope, $timeout, $http, $templateCache, $state, cordovaPlug) {
    var body = $document.find('body'),
      container

    function close(type) {
      if (type) {
        container.removeClass('active')
        container.remove()
        return;
      }
      container.removeClass('active')
      $timeout(function () {
        container.remove()
      }, 250)
    }

    function show(bak) {
      $timeout(function () {
        container.addClass('active')
        if (bak) bak(container)
      }, 50)
    }
    /*
     * 举报
     * confirmButton  确认文字
     * confirm 成功回调函数
     * cancel 取消回调函数
     * items 选项列表
     * */
    function showChoose(option) {
      var items = option.items,
        chooseItem = [],
        confirmButton = option.confirmButton ? option.confirmButton : '确认';
      container = angular.element('<div id="tab_store_action-sheet-container"></div>')
      body.append(container);

      var $scope = $rootScope.$new();
      $scope.choose = function () {
        container.removeClass('active')
        $timeout(function () {
          container.remove()
        }, 250)
        if (option.confirm) option.confirm(chooseItem)
      }
      $scope.select = function (i, e) {
        if (angular.element(e.target).hasClass('selected')) {
          angular.element(e.target).removeClass('selected')
          chooseItem.splice(chooseItem.indexOf(i), 1)
        } else {
          angular.element(e.target).addClass('selected')
          chooseItem.push(i)
        }
      }
      $scope.cancel = function (i, e) {
        close()
        if (option.cancel) option.cancel(chooseItem)
      }

      var html = '<div><div class="bg" ng-click="cancel()"></div><div class="box"><div class="items-box">'
      for (var i = 0; i < items.length; i++) {
        html += '<span ng-click="select(' + i + ',$event)">' + items[i] + '</span>'
      }
      html += '</div><div class="options"><a class="confirm" href="javascript:void(0)" ng-click="choose()">' + confirmButton + '</a></div></div></div>'
      html = $compile(html)($scope);
      container.append(html)
      show()
    }

    //显示电话号码 tel 电话号码
    function showTel(tel) {
      container = angular.element('<div id="tab_store_action-sheet-container"></div>')
      body.append(container);
      var $scope = $rootScope.$new();
      $scope.cancel = function (i, e) {
        close()
      }
      $scope.call = function (i, e) {
        cordovaPlug.CommonPL(function () {
          //隐藏拨打弹框
        }, "telephone", [tel])
        close()
      }
      var html = '<div><div class="bg" ng-click="cancel()"></div><div class="box tel-box"><div class="items-box">'
      html += '<span ng-click="call()">' + tel + '</span>'
      html += '</div><div class="options">' +
        '<a class="cancel" href="javascript:void(0)" ng-click="cancel()">取消</a></div></div></div>'
      html = $compile(html)($scope);
      container.append(html)
      show()
    }

    /*
     * scope 当前scope
     * type  1.选择月份 2.选择周 3.选择日期
     * startDate  开始时间
     * endDate  结束时间
     * currentDate  当前时间
     * */

    function chooseTimeList(option) {
      var years = [],
        month = [],
        s_y = parseInt(option.startDate.split('-')[0]),
        e_y = parseInt(option.endDate.split('-')[0]),
        c_y = parseInt(option.currentDate.split('-')[0]),
        c_m = parseInt(option.currentDate.split('-')[1]),
        c_d = parseInt(option.currentDate.split('-')[2]),
        c_w;
      for (var i = s_y; i < e_y + 1; i++) {
        years.push(i)
      }
      var fullMonth = []
      for (var i = 1; i < 13; i++) {
        fullMonth.push(i > 9 ? i : "0" + i);
      }
      var nowDate = new Date()
      var nowYear = nowDate.getFullYear(),
        nowMonth = nowDate.getMonth() > 9 ? nowDate.getMonth() : '0' + nowDate.getMonth(),
        nowDay = nowDate.getDate()
      var $scope = option.scope;
      $scope.type = option.type;
      // $scope.currentDate = option.currentDate;
      $scope.currentDate = new Date().format(-1);
      $scope.currentYear = c_y //当前年份
      $scope.currentMonth = c_m - 1 > 9 ? c_m - 1 : '0' + (c_m - 1) //当前月份
      $scope.years = years
      $scope.months = fullMonth
      $scope.monthDays = fullMonth
      $scope.days = []
      for (var i = 0; i < DayNumOfMonth(c_y, c_m); i++) {
        $scope.days.push(i + 1 > 9 ? i + 1 : "0" + (i + 1))
      }
      if ($scope.currentYear == nowYear) {
        $scope.months = $scope.months.slice(0, parseInt(nowMonth) + 1);
        $scope.monthDays = $scope.monthDays.slice(0, parseInt(nowMonth) + 1);
        $scope.days = []
        for (var i = 0; i < DayNumOfMonth(nowYear, parseInt(nowMonth)); i++) {
          $scope.days.push(i + 1 > 9 ? i + 1 : "0" + (i + 1))
        }
        if (parseInt($scope.currentMonth) == nowMonth) {
          $scope.days = $scope.days.slice(0, nowDay);
        }
      }
      setWeek($scope.currentYear)
      $scope.currentDay = c_d > 9 ? c_d : '0' + c_d //当前天
      $rootScope.$on('getWeeksList', function (e, type, index) {
        //选择年--周
        if (type == "years" && $scope.type == 2) {
          $scope.currentYear = $scope[type][index]
          var weekIndex;
          if ($scope.currentYear == nowYear) {
            setWeek($scope.currentYear)
            // weekIndex =$scope.weeks.indexOf($scope.currentWeek)
            weekIndex = 1
          }
          // else if($scope.currentYear == c_y){
          //         $scope.weeks = getWeeks($scope.currentYear+'-12-31');
          //     $scope.currentWeek=c_w
          //     weekIndex =$scope.weeks.indexOf($scope.currentWeek)
          // }
          else {
            weekIndex = 1
            $scope.weeks = getWeeks($scope.currentYear + '-12-30');
            $scope.currentWeek = $scope.weeks[1]
          }

          setTimeout(function () {
            var week = document.querySelectorAll('.action-sheet-choose-date .week')
            for (var i = 0; i < week.length; i++) {
              item = angular.element(week[i])
              item.find('li').css({
                fontSize: '15px',
                color: '#999'
              })
              item.css('top', "-" + (5 + (weekIndex - 1) * 50) + 'px')
              item.find('li').eq(weekIndex).css({
                fontSize: '25px',
                color: '#2658A6'
              })
            }
          }, 50)
        }
        //选择年
        if (type == "years" && $scope.type != 2) {
          $scope.currentYear = $scope[type][index], mon = fullMonth
          if ($scope.type == 1) {
            $scope.months = $scope.currentYear == nowYear ? mon.slice(0, nowMonth + 1) : mon
          } else if ($scope.type == 3) {
            $scope.monthDays = $scope.currentYear == nowYear ? mon.slice(0, nowMonth + 1) : mon;
            setDays()
          }
          $scope.currentMonth = "01";
          var month = document.querySelectorAll('.action-sheet-choose-date .month')
          for (var i = 0; i < month.length; i++) {
            item = angular.element(month[i])
            item.find('li').css({
              fontSize: '15px',
              color: '#999'
            })
            item.css('top', "-" + (5 + (1 - 1) * 50) + 'px')
            item.find('li').eq(1).css({
              fontSize: '25px',
              color: '#2658A6'
            })
          }
        }
        //选择月份
        if (type == "monthDays") {
          $scope.currentMonth = fullMonth[index] - 1 > 9 ? fullMonth[index] - 1 : '0' + (fullMonth[index] - 1)
          setDays()
        }
        if (type == "months") {
          $scope.currentMonth = fullMonth[index] - 1 > 9 ? fullMonth[index] - 1 : '0' + (fullMonth[index] - 1)
        }
        if (type == "days") {
          $scope.currentDay = $scope[type][index]
        }
        if (type == "weeks") {
          $scope.currentWeek = $scope[type][index]
        }
        $scope.$apply()
      })
      $scope.changeType = function (type) {
        $scope.type = type;
      }
      showAction({
        scope: $scope,
        top: option.top,
        isTransition: 'no-transition',
        success: function (info) {
          var time, month = parseInt($scope.currentMonth) + 1 > 9 ? parseInt($scope.currentMonth) + 1 : '0' + (parseInt($scope.currentMonth) + 1),
            start, end;
          if ($scope.type == 1) { //月
            start = time = $scope.currentYear + '-' + month + '-01';
            end = $scope.currentYear + '-' + month + '-' + DayNumOfMonth($scope.currentYear, parseInt($scope.currentMonth) + 1);
          } else if ($scope.type == 2) { //周
            start = time = $scope.currentYear + '-' + $scope.currentWeek.split('-')[0].replace('.', '-');
            end = $scope.currentYear + '-' + $scope.currentWeek.split('-')[1].replace('.', '-');
          } else { //日
            start = end = time = $scope.currentYear + '-' + month + '-' + $scope.currentDay;
          }
          if (option.success) option.success({
            type: $scope.type, //类型
            year: $scope.currentYear, //年份
            month: month, //月份
            start: start,
            end: end,
            day: $scope.currentDay, //日期，
            week: $scope.currentWeek, //周期
            time: time
          })
        },
        cancel: function (info) {
          if (option.cancel) option.cancel()
        },
        showBefore: function (cont) {
          initStyle()
        },
        templateUrl: './component/account_list/choose-time.html',
      })

      function setDays() {
        $scope.days = [];
        var dayLength = DayNumOfMonth($scope.currentYear, parseInt($scope.currentMonth) + 1)
        for (var i = 0; i < dayLength; i++) {
          $scope.days.push(i + 1 > 9 ? i + 1 : '0' + (i + 1))
        }
        if (parseInt($scope.currentMonth) == nowMonth && $scope.currentYear == nowYear) {
          $scope.days = $scope.days.slice(0, nowDay);
        }
        $scope.currentDay = $scope.days[1]
        var day = document.querySelectorAll('.action-sheet-choose-date .day')
        for (var i = 0; i < day.length; i++) {
          item = angular.element(day[i])
          item.find('li').css({
            fontSize: '15px',
            color: '#999'
          })
          item.css('top', '-5px')
          item.find('li').eq(1).css({
            fontSize: '25px',
            color: '#2658A6'
          })
        }
      }
      //初始化样式
      function initStyle() {
        var yearIndex = $scope.years.indexOf($scope.currentYear),
          monthIndex = parseInt($scope.currentMonth),
          item;
        var weekIndex = $scope.weeks.indexOf($scope.currentWeek)
        var dayIndex = $scope.days.indexOf($scope.currentDay)
        var year = document.querySelectorAll('.action-sheet-choose-date .year')

        for (var i = 0; i < year.length; i++) {
          item = angular.element(year[i])
          item.css('top', (yearIndex == 0 ? 45 : -(5 + (yearIndex - 1) * 50)) + 'px')
          item.find('li').eq(yearIndex).css({
            fontSize: '25px',
            color: '#2658A6'
          })
        }
        var month = document.querySelectorAll('.action-sheet-choose-date .month')
        for (var i = 0; i < month.length; i++) {
          item = angular.element(month[i])
          item.css('top', (monthIndex == 0 ? 45 : -(5 + (monthIndex - 1) * 50)) + 'px')
          item.find('li').eq(monthIndex).css({
            fontSize: '25px',
            color: '#2658A6'
          })
        }
        var week = document.querySelectorAll('.action-sheet-choose-date .week')
        for (var i = 0; i < week.length; i++) {
          item = angular.element(week[i])
          item.css('top', (weekIndex == 0 ? 45 : -(5 + (weekIndex - 1) * 50)) + 'px')
          item.find('li').eq(weekIndex).css({
            fontSize: '25px',
            color: '#2658A6'
          })
        }
        var day = document.querySelectorAll('.action-sheet-choose-date .day')
        for (var i = 0; i < day.length; i++) {
          item = angular.element(day[i])
          item.css('top', (dayIndex == 0 ? 45 : -(5 + (dayIndex - 1) * 50)) + 'px')
          item.find('li').eq(dayIndex).css({
            fontSize: '25px',
            color: '#2658A6'
          })
        }
      }

      function setWeek(year) {
        $scope.currentYear = year
        if (nowYear == year) {
          var nowDates = nowDate.getFullYear() + '-' + (nowDate.getMonth() + 1 > 9 ? nowDate.getMonth() + 1 : "0" +
            (nowDate.getMonth() + 1)) + '-' + (nowDate.getDate() > 9 ? nowDate.getDate() : '0' + nowDate.getDate());
          var week_index = theWeek(nowDates)
          $scope.weeks = getWeeks($scope.currentYear + '-12-30', week_index);
          // $scope.currentWeek=getTime(1,nowDates)+'-'+getTime(-5,nowDates)
          $scope.currentWeek = $scope.weeks[week_index];
        } else {
          $scope.weeks = getWeeks($scope.currentYear + '-12-30');
          var week_index = theWeek(option.currentDate)
          $scope.currentWeek = c_w = $scope.weeks[week_index] //当前月份
        }

      }
      return {
        close: function () {
          close(isTransitions)
        }
      }
    }

    //某月天数
    function DayNumOfMonth(Year, Month) {
      Month--;
      var d = new Date(Year, Month, 1);
      d.setDate(d.getDate() + 32 - d.getDate());
      return (32 - d.getDate());
    }
    //得到某年的周
    function getWeeks(date, length) {
      var weeks = theWeek(date),
        length = length ? weeks - length : 0
      var weeksDate = []
      for (var i = length; i < weeks + 1; i++) {
        weeksDate.push(getTime(i * 7, date) + '-' + getTime(i * 7 - 6, date));
      }
      return weeksDate.reverse();
    }

    function getTime(n, data) {
      var now;
      if (data) now = new Date(data);
      else now = new Date();
      var year = now.getFullYear();
      //因为月份是从0开始的,所以获取这个月的月份数要加1才行
      var month = now.getMonth() + 1;
      var date = now.getDate();
      var day = now.getDay();
      //判断是否为周日,如果不是的话,就让今天的day-1(例如星期二就是2-1)
      if (day !== 0) {
        n = n + (day - 1);
      } else {
        n = n + day;
      }
      if (day) {
        //这个判断是为了解决跨年的问题
        if (month > 1) {
          month = month;
        }
        //这个判断是为了解决跨年的问题,月份是从0开始的
        else {
          year = year - 1;
          month = 12;
        }
      }
      now.setDate(now.getDate() - n);
      year = now.getFullYear();
      month = now.getMonth() + 1;
      date = now.getDate();

      //s=year+"年"+(month<10?('0'+month):month)+"月"+(date<10?('0'+date):date)+"日";
      s = (month < 10 ? ('0' + month) : month) + "." + (date < 10 ? ('0' + date) : date);
      return s;
    }

    function theWeek(data) {
      var totalDays = 0,
        now
      if (data) now = new Date(data);
      else now = new Date();
      var years = now.getFullYear()
      if (years < 1000)
        years += 1900
      var days = new Array(12);
      days[0] = 31;
      days[2] = 31;
      days[3] = 30;
      days[4] = 31;
      days[5] = 30;
      days[6] = 31;
      days[7] = 31;
      days[8] = 30;
      days[9] = 31;
      days[10] = 30;
      days[11] = 31;

      //判断是否为闰年，针对2月的天数进行计算
      if (Math.round(now.getYear() / 4) == now.getYear() / 4) {
        days[1] = 29
      } else {
        days[1] = 28
      }

      if (now.getMonth() == 0) {
        totalDays = totalDays + now.getDate();
      } else {
        var curMonth = now.getMonth();
        for (var count = 1; count <= curMonth; count++) {
          totalDays = totalDays + days[count - 1];
        }
        totalDays = totalDays + now.getDate();
      }
      //得到第几周
      var week = Math.ceil(totalDays / 7);
      return week;
    }

    /*
     * 底部弹框
     * cancel  取消
     * success  成功
     * scope 作用域
     * top 顶部距离
     * templateUrl / template  模板
     * showBefore  显示之前
     * isTransition 是否显示动画
     * */
    function showAction(option) {
      container = angular.element('<div id="tab_store_action-sheet-container" style="height: auto;' +
        'bottom: 0"></div>'), isTransitions = option.isTransition ? option.isTransition : false;
      body.append(container);
      var $scope = {};
      $scope = option.scope ? option.scope : $rootScope.$new();
      $scope.fail = function () {
        close(isTransitions)
        $timeout(function () {
          if (option.cancel) option.cancel()
        }, 200)
      }
      $scope.doSuccess = function () {
        close(isTransitions)
        $timeout(function () {
          if (option.success) option.success()
        }, 200)
      }
      if (option.template) {
        var page = $compile("<div class='box action-box'>" + option.template + "</div>")($scope);
        container.append(page)
        $timeout(function () {
          if (option.showBefore) option.showBefore(page)
        }, 50)
        show(container)
        return
      }
      $http.get(option.templateUrl, {
          cache: $templateCache
        })
        .then(function (response) {
          var page = $compile("<div class='bgff' style='height:" + option.top + "' ng-click='fail()'></div><div style='top:" + option.top + "; position: fixed; width: 100%; height: 100%;'><div class='bg' ng-click='fail()'>" +
            "</div><div class='box action-box " + option.isTransition + "'>" + response.data + "</div></div>")($scope);
          container.append(page)
          $timeout(function () {
            if (option.showBefore) option.showBefore(page)
          }, 50)
          show($scope.showBefore)

        });
    }

    /*
     * startDate  初始日期
     * endDate 结束日期
     * currentDate 结束日期
     * scope  当前作用域
     * cancel  取消
     * success  成功
     * */
    function chooseDate(option) {
      var years = [],
        month = [],
        s_y = parseInt(option.startDate.split('-')[0]),
        e_y = parseInt(option.endDate.split('-')[0]),
        c_y = parseInt(option.currentDate.split('-')[0]),
        c_m = parseInt(option.currentDate.split('-')[1])
      for (var i = s_y; i < e_y + 1; i++) {
        years.push(i)
      }
      var $scope = {}
      $scope = option.scope
      $scope.years = years
      $scope.currentYear = c_y
      $scope.currentMonth = c_m
      $scope.currentDate = option.currentDate
      showAction({
        scope: $scope,
        success: function (info) {
          if (option.success) option.success({
            year: years[$scope.currentYear],
            month: $scope.currentMonth + 1
          })
        },
        cancel: function (info) {
          if (option.cancel) option.cancel({
            year: years[$scope.currentYear],
            month: $scope.currentMonth + 1
          })
        },
        showBefore: function (cont) {
          var yearIndex = $scope.years.indexOf(c_y),
            monthIndex = c_m
          angular.element(document.querySelectorAll('.action-sheet-choose-date .year'))
            .css('top', "-" + (5 + (yearIndex - 1) * 50) + 'px').find('li').eq(yearIndex)
            .css({
              fontSize: '25px',
              color: '#2658A6'
            })
          angular.element(document.querySelectorAll('.action-sheet-choose-date .month'))
            .css('top', "-" + (5 + (monthIndex - 2) * 50) + 'px').find('li').eq(monthIndex - 1)
            .css({
              fontSize: '25px',
              color: '#2658A6'
            })
        },
        templateUrl: './component/account_list/choose-date.html',
      })
    }

    function getCity(index) {
      var province = [];
      var p = $return.getCache('allCitiesProvinces');
      p.forEach(function (item) {
        if (item.parentAreaId == index + 2) {
          province.push(item.pickerViewText)
        }
      })
      return province;
    }

    function getAreaId(cityName) {
      var areaId = '';
      $return.getCache("allCitiesProvinces").forEach(function (item) {
        if (item.areaName == cityName) {
          areaId = item.areaId;
        }
      })
      return areaId;
    }
    //选择银行卡*******
    function chooseBankCard(option) {
      var $scope = {},
        y_index = ''; //y_index当前城市的areaId

      $scope = option.scope;

      $scope.years = option.shengfen; //省份

      $scope.months = option.chengshi; //城市
      //所有地区
      // $scope.years = getCache("industry_lifeAPI_allAreas")[0];
      $scope.currentYear = $scope.years.indexOf(option.c_shengfen);
      $scope.currentMonth = $scope.months.indexOf(option.c_chengshi);
      $scope.show_city = option.show_city ? option.show_city : $scope.years[$scope.currentYear];
      $scope.show_province = option.show_province ? option.show_province : $scope.months[$scope.currentMonth];

      $rootScope.$on('getWeeksList', function (e, name, index) {
        //省份改变触发事件
        if (name == "shengfen") {
          $scope.months = getCity(index);
          console.log($scope.years[index]);
          angular.element(document.querySelectorAll('.action-sheet-choose-date .year'))
            .find('li').css({
              fontSize: '15px',
              color: '#999'
            })
          angular.element(document.querySelectorAll('.action-sheet-choose-date .year'))
            .find('li').eq(index)
            .css({
              fontSize: '18px',
              color: '#2658A6'
            })
          angular.element(document.querySelectorAll('.action-sheet-choose-date .month'))
            .css('top', '45px').find('li').css({
              fontSize: '15px',
              color: '#999'
            });
          angular.element(document.querySelectorAll('.action-sheet-choose-date .month'))
            .find('li').eq(0).css({
              fontSize: '18px',
              color: '#2658A6'
            })
          $scope.$apply();
        }
        if (name == "chengshi") {
          console.log($scope.months[index]);
          y_index = getAreaId($scope.months[index])

          angular.element(document.querySelectorAll('.action-sheet-choose-date .month'))
            .find('li').css({
              fontSize: '15px',
              color: '#999'
            })
          angular.element(document.querySelectorAll('.action-sheet-choose-date .month'))
            .find('li').eq(index)
            .css({
              fontSize: '18px',
              color: '#2658A6'
            })
          $scope.$apply();
        }
      })
      showAction({
        scope: $scope,
        success: function (info) {
          if (option.success) option.success({
            0: $scope.years[$scope.currentYear],
            1: $scope.months[$scope.currentMonth],
            2: y_index ? y_index : getAreaId($scope.months[$scope.currentMonth])
          })
        },
        cancel: function (info) {

        },
        showBefore: function (cont) {
          var yearIndex = $scope.currentYear,
            monthIndex = $scope.currentMonth
          angular.element(document.querySelectorAll('.action-sheet-choose-date .year'))
            .css('top', (yearIndex == 0 ? 45 : -(5 + (yearIndex - 1) * 50)) + 'px').find('li').eq(yearIndex)
            .css({
              fontSize: '18px',
              color: '#2658A6'
            })
          angular.element(document.querySelectorAll('.action-sheet-choose-date .month'))
            .css('top', (monthIndex == 0 ? 45 : -(5 + (monthIndex - 1) * 50)) + 'px').find('li').eq(monthIndex)
            .css({
              fontSize: '18px',
              color: '#2658A6'
            })
          angular.element(document.querySelectorAll('.action-sheet-choose-date .box-s p'))[0]
            .textContent = $scope.show_city + "(" + $scope.show_province + ")"
          // $scope.$apply();
        },
        templateUrl: 'picker.html'
      })
    }
    //chooseBankCard() end

    //显示支付完成页面
    function successPay(_num) {
      container = angular.element('<div id="tab_store_action-sheet-container"></div>')
      body.append(container);
      var $scope = $rootScope.$new();
      $scope.cancel = function (i, e) {
        close()
      }
      $scope.call = function (i, e) {
        close();
        $state.go('tab.index');
      }
      var html = '<div><div class="bg" ng-click="call()"></div><div class="box cjc_paybg"><div class="cjc_pay_tip"><div class="color33 f32 tc">支付成功，您己获得<span class="cjc_pay_red">' + _num + '</span>乐豆</div><div class="tc color66 f26 cjc_pay_moretip">乐豆可在任何合作商店消费相当于' + _num + '元现金</div></div><div class="cjc_pay_btn" ng-click="call()">返回首页</div></div></div>'
      html = $compile(html)($scope);
      container.append(html)
      show()
    }
    //显示银行卡更换
    function changeBank(data, success) {
      container = angular.element('<div id="tab_store_action-sheet-container"></div>')
      body.append(container);
      var $scope = $rootScope.$new();
      $scope.cancel = function (i, e) {
        close()
      }
      $scope.serverSideChange = function (e) {
        success instanceof Function && success(e);
        close();
      }
      $scope.data = data;
      var html = '<div><div class="bg" ng-click="cancel()"></div><div class="box bankBox p0-24">'
      html += '<div class="cjc_bank_title bor-bot">选择优先支付方式</div><div class="cjc_bank_tip">优先使用所选支付方式付款，如付款失败将尝试使用其他支付方式完成付款</div>';
      html += '<div class="banklist"><ion-radio ng-repeat="item in data"  class="cjc_banklist f32 color33 bor-bot"  ng-value="item.value" ng-click="serverSideChange(item)"> <img ng-src="{{item.bankImg}}" alt=""><span>{{item.bankName}}</span><span>{{item.cardType =="C" && " 信用卡" || " 储蓄卡"}}</span> <span>({{item.cardNo.substr(-4,4)}})</span></ion-radio></div><div class="cjc_height"></div></div>'
      html = $compile(html)($scope);
      container.append(html)
      show()
    }
    //显示选择银行卡
    function selectBank(data, success) {
      container = angular.element('<div id="action-sheet-container"></div>')
      body.append(container);
      var $scope = $rootScope.$new();
      $scope.cancel = function (i, e) {
        close()
      }
      $scope.serverSideChange = function (e) {
        success instanceof Function && success(e);
        close();
      }
      $scope.data = data;
      var html = '<div><div class="bg" ng-click="cancel()"></div><div class="box bankBox p0-24">'
      html += '<div class="cjc_bank_title bor-bot">选择优先支付方式</div><div class="cjc_bank_tip">优先使用所选支付方式付款，如付款失败将尝试使用其他支付方式完成付款</div>';
      html += '<div class="banklist"><ion-radio ng-repeat="item in data track by $index"  class="cjc_banklist f32 color33 bor-bot"  ng-value="item.value" ng-click="serverSideChange(item)"> <img ng-src="{{item.bankImg}}" alt=""><span>{{item.bankName}}</span><span>{{item.cardType =="C" && " 信用卡" || " 储蓄卡"}}</span> <span>({{item.cardNo.substr(-4,4)}})</span></ion-radio></div><div class="cjc_height"></div></div>'
      html = $compile(html)($scope);
      container.append(html)
      show()
    }
    //暂停使用二维码弹框
    function showMadal(instructions, stopfunction) {
      container = angular.element('<div id="tab_store_action-sheet-container"></div>')
      body.append(container);
      var $scope = $rootScope.$new();
      $scope.cancel = function (i, e) {
        close()
      }
      $scope.stop = function (i, e) {
        stopfunction instanceof Function && stopfunction();
        close()
      }
      $scope.call = function (i, e) {
        instructions instanceof Function && instructions();
        close()
      }
      var html = '<div><div class="bg" ng-click="cancel()"></div><div class="box tel-box"><div class="items-box" ng-click="call()">'
      html += '<span style="color:#333;">使用说明</span></div><div class="items-box" ng-click="stop()"><span>暂停使用</span></div>'
      html += '<div class="options" ng-click="cancel()">' +
        '<a class="cancel" href="javascript:void(0)">取消</a></div></div></div>'
      html = $compile(html)($scope);
      container.append(html)
      show()
    }
    //显示未实名认证的
    function showAuthentication() {
      container = angular.element('<div id="tab_store_action-sheet-container"></div>')
      body.append(container);
      var $scope = $rootScope.$new();
      $scope.cancel = function (i, e) {
        close()
      }
      $scope.gotoCertification = function (i, e) {
        $state.go('tab.my_certification')
        close()
      }
      var html = '<div class="bg" ng-click="cancel()"></div>'
      html += '<div class="cjc_showalert f28 box"><div class="cjc_alert_padding"><img src="img/index/true.png" alt="" /><div class="color33">恭喜您己注册成功，完善您的资料并进行实名认证才可以正常交易。</div></div><div class="df"><div class="cjc_right" ng-click="cancel()">先看看，暂不认证</div><div class="df1" ng-click="gotoCertification()">马上认证</div></div>'
      html = $compile(html)($scope);
      container.append(html)
      show();
    }
    /*
     * 仿madal弹框
     * scope 作用域
     * templateUrl 模板地址
     * template  模板文本
     * success  插入好回调函数，参数：container(插入的节点对象)
     * */
    function showPage(option) {
      var html = angular.element('<div class="box page-box"></div>')
      container = angular.element('<div id="tab_store_action-sheet-container"></div>')
      body.append(container);
      container.append(html);
      option.scope.cancel = function (i, e) {
        close()
        option.scope.closeModal()
      }
      if (option.template) {
        var page = $compile(option.template)(option.scope);
        html.append(page)
        show(option.success)
        return
      }
      $http.get(option.templateUrl, {
          cache: $templateCache
        })
        .then(function (response) {
          var page = $compile(response.data)(option.scope);
          html.append(page)
          show(option.success)

        });
    }


    return {
      showChoose: showChoose,
      showTel: showTel,
      showPage: showPage,
      showMadal: showMadal,
      showAuthentication: showAuthentication,
      changeBank: changeBank,
      showAction: showAction,
      chooseBankCard: chooseBankCard,
      chooseDate: chooseDate,
      chooseTimeList: chooseTimeList,
      successPay: successPay
    }
  })
